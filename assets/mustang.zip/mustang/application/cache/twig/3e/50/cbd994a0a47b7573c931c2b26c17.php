<?php

/* login.html */
class __TwigTemplate_3e50cbd994a0a47b7573c931c2b26c17 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("site.html");

        $this->blocks = array(
            'data' => array($this, 'block_data'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "site.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_data($context, array $blocks = array())
    {
        // line 4
        echo "<div class=\"container\" id=\"login\">
    ";
        // line 5
        echo form_open("validate", "class=\"form-signin\"");
        echo "
        <h2 class=\"form-signin-heading\">请登录</h2>
        <p id=\"msg\"></p>
        <div class=\"block\">
            <input type=\"text\" class=\"input-block-level\" name=\"username\" autocomplete=\"off\">
            <label class=\"tip\">用户名</label>
        </div>
        <div class=\"block\">
            <input type=\"password\" class=\"input-block-level\" name=\"pwd\">
            <label class=\"tip\">密码</label>
        </div>
        ";
        // line 16
        if (isset($context["has_captcha"])) { $_has_captcha_ = $context["has_captcha"]; } else { $_has_captcha_ = null; }
        if ($_has_captcha_) {
            // line 17
            echo "        <p class=\"help-block\" id=\"p-captcha\">
            <img src=\"";
            // line 18
            echo twig_escape_filter($this->env, site_url(), "html", null, true);
            echo "/captcha/?t=";
            echo twig_escape_filter($this->env, time(), "html", null, true);
            echo "\" id=\"image-captcha\"/><span class=\"btn btn-link\" id=\"span-captcha\" >看不清，换一张</span>
        </p>
        <div class=\"block\">
            <input type=\"text\" class=\"input-block-level\" name=\"captcha\" autocomplete=\"off\">
            <label class=\"tip\">验证码</label>
        </div>
        ";
        }
        // line 25
        echo "
        <button class=\"btn btn-large btn-primary\" type=\"submit\">登录</button>
        <input type=\"hidden\" name=\"baseurl\" value=\"";
        // line 27
        echo twig_escape_filter($this->env, site_url(), "html", null, true);
        echo "\" />
    </form>
</div>
";
    }

    public function getTemplateName()
    {
        return "login.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  70 => 27,  66 => 25,  54 => 18,  51 => 17,  48 => 16,  34 => 5,  31 => 4,  28 => 3,);
    }
}
