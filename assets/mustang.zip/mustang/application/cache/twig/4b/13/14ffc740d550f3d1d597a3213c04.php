<?php

/* site.html */
class __TwigTemplate_4b1314ffc740d550f3d1d597a3213c04 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("base.html");

        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'content' => array($this, 'block_content'),
            'header' => array($this, 'block_header'),
            'menu' => array($this, 'block_menu'),
            'data' => array($this, 'block_data'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_head($context, array $blocks = array())
    {
        // line 3
        echo "    <meta charset=\"utf-8\">
    <title>";
        // line 4
        if (isset($context["title"])) { $_title_ = $context["title"]; } else { $_title_ = null; }
        echo twig_escape_filter($this->env, $_title_, "html", null, true);
        echo " - iPad电子云菜单系统</title>
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <link rel=\"icon\" href=\"";
        // line 7
        echo twig_escape_filter($this->env, base_url(), "html", null, true);
        echo "assets/img/favicon.ico\" type=\"image/x-icon\" />
    <link rel=\"shortcut icon\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, base_url(), "html", null, true);
        echo "assets/img/favicon.png\">
    <!-- Le styles -->
    <link href=\"";
        // line 10
        echo twig_escape_filter($this->env, base_url(), "html", null, true);
        echo "assets/bootstrap/css/bootstrap.min.css\" rel=\"stylesheet\">
    <link href=\"";
        // line 11
        echo twig_escape_filter($this->env, base_url(), "html", null, true);
        echo "assets/css/site.css?t=20140108\" rel=\"stylesheet\">
    <!--[if lt IE 9]>
        <script src=\"";
        // line 13
        echo twig_escape_filter($this->env, base_url(), "html", null, true);
        echo "assets/js/html5shiv.js\"></script>
    <![endif]-->
    <script src=\"";
        // line 15
        echo twig_escape_filter($this->env, base_url(), "html", null, true);
        echo "assets/js/jquery.min.js\"></script>
    <script src=\"";
        // line 16
        echo twig_escape_filter($this->env, base_url(), "html", null, true);
        echo "assets/bootstrap/js/bootstrap.min.js\"></script>
    <script src=\"";
        // line 17
        echo twig_escape_filter($this->env, base_url(), "html", null, true);
        echo "assets/js/jquery.countdown.min.js\"></script>
    <script src=\"";
        // line 18
        echo twig_escape_filter($this->env, base_url(), "html", null, true);
        echo "assets/js/md5.js\"></script>
    <script src=\"";
        // line 19
        echo twig_escape_filter($this->env, base_url(), "html", null, true);
        echo "assets/js/site.min.js?t=20140108\"></script>
";
    }

    // line 22
    public function block_content($context, array $blocks = array())
    {
        // line 23
        echo "    <div class=\"navbar navbar-inverse navbar-fixed-top\">
        <div class=\"navbar-inner\">
            <div class=\"container\">
                <div class=\"nav-collapse collapse\">
                    <ul class=\"nav pull-right\">
                        ";
        // line 28
        $context["user"] = session_value("user");
        // line 29
        echo "                        ";
        if (isset($context["user"])) { $_user_ = $context["user"]; } else { $_user_ = null; }
        if ((!$_user_)) {
            // line 30
            echo "                        <li><a href=\"";
            echo twig_escape_filter($this->env, site_url(), "html", null, true);
            echo "/login/\"><i class=\"icon-user icon-white\"></i> 登录</a></li>
                        ";
        } else {
            // line 32
            echo "                        <li><a href=\"";
            echo twig_escape_filter($this->env, site_url(), "html", null, true);
            echo "/user\">您好, ";
            if (isset($context["user"])) { $_user_ = $context["user"]; } else { $_user_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_user_, "name"), "html", null, true);
            echo "</a></li>
                        ";
            // line 33
            if (isset($context["user"])) { $_user_ = $context["user"]; } else { $_user_ = null; }
            if (($this->getAttribute($_user_, "role") == "buyer")) {
                // line 34
                echo "                        <li><a href=\"";
                echo twig_escape_filter($this->env, site_url(), "html", null, true);
                echo "/user/buy\">我的交易</a></li>
                        ";
            } elseif (($this->getAttribute($_user_, "role") == "sell")) {
                // line 36
                echo "                        <li><a href=\"";
                echo twig_escape_filter($this->env, site_url(), "html", null, true);
                echo "/user/sell\">我的交易</a></li>
                        ";
            }
            // line 38
            echo "                        ";
            if (isset($context["user"])) { $_user_ = $context["user"]; } else { $_user_ = null; }
            if (twig_in_filter($this->getAttribute($_user_, "role"), array(0 => "admin", 1 => "super", 2 => "leader", 3 => "appraiser", 4 => "waiter"))) {
                // line 39
                echo "                        <li><a href=\"";
                echo twig_escape_filter($this->env, site_url(), "html", null, true);
                echo "/admin/\">管理</a></li>
                        ";
            }
            // line 41
            echo "                        <li><a href=\"";
            echo twig_escape_filter($this->env, site_url(), "html", null, true);
            echo "/logout/\" title=\"退出\" alt=\"退出\"><i class=\"icon-off icon-white\"></i> &nbsp;</a></li>
                        ";
        }
        // line 43
        echo "                    </ul>
                </div>
            </div>
        </div>
    </div>

    ";
        // line 49
        $this->displayBlock('header', $context, $blocks);
        // line 56
        echo "
    ";
        // line 57
        $this->displayBlock('menu', $context, $blocks);
        // line 77
        echo "
    ";
        // line 78
        $this->displayBlock('data', $context, $blocks);
        // line 80
        echo "
";
    }

    // line 49
    public function block_header($context, array $blocks = array())
    {
        // line 50
        echo "    <div id=\"logo\" class=\"container container-fluid\">
        <div class=\"row-fluid\">
            <input type=\"hidden\" id=\"baseurl\" value=\"";
        // line 52
        echo twig_escape_filter($this->env, site_url(), "html", null, true);
        echo "\" />
        </div>
    </div>
    ";
    }

    // line 57
    public function block_menu($context, array $blocks = array())
    {
        // line 58
        echo "    ";
        if (isset($context["user"])) { $_user_ = $context["user"]; } else { $_user_ = null; }
        if ($_user_) {
            // line 59
            echo "    <div id=\"menu\" class=\"container nav nav-stacked\">
        <div class=\"navbar-inner\">
            <ul class=\"nav\">
                ";
            // line 62
            $context["route"] = get_route();
            // line 63
            echo "                <li ";
            if (isset($context["route"])) { $_route_ = $context["route"]; } else { $_route_ = null; }
            if (($this->getAttribute($_route_, "class") == "home")) {
                echo " class=\"active\" ";
            }
            echo "><a href=\"";
            echo twig_escape_filter($this->env, base_url(), "html", null, true);
            echo "\">首页</a></li>
                <li class=\"divider-vertical\"></li>
                <li ";
            // line 65
            if (isset($context["route"])) { $_route_ = $context["route"]; } else { $_route_ = null; }
            if (($this->getAttribute($_route_, "class") == "sale")) {
                echo " class=\"active\" ";
            }
            echo "><a href=\"";
            echo twig_escape_filter($this->env, site_url(), "html", null, true);
            echo "/sale/\">我要卖车</a></li>
                <li class=\"divider-vertical\"></li>
                <li ";
            // line 67
            if (isset($context["route"])) { $_route_ = $context["route"]; } else { $_route_ = null; }
            if (($this->getAttribute($_route_, "class") == "buy")) {
                echo " class=\"active\" ";
            }
            echo "><a href=\"";
            echo twig_escape_filter($this->env, site_url(), "html", null, true);
            echo "/buy/\">我要买车</a></li>
                <li class=\"divider-vertical\"></li>
                <li ";
            // line 69
            if (isset($context["route"])) { $_route_ = $context["route"]; } else { $_route_ = null; }
            if ((($this->getAttribute($_route_, "class") == "article") && ($this->getAttribute($_route_, "method") == "activity"))) {
                echo " class=\"active\" ";
            }
            echo "><a href=\"";
            echo twig_escape_filter($this->env, site_url(), "html", null, true);
            echo "/activity/\">特色服务</a></li>
                <li class=\"divider-vertical\"></li>
                <li ";
            // line 71
            if (isset($context["route"])) { $_route_ = $context["route"]; } else { $_route_ = null; }
            if ((($this->getAttribute($_route_, "class") == "article") && ($this->getAttribute($_route_, "method") == "news"))) {
                echo " class=\"active\" ";
            }
            echo "><a href=\"";
            echo twig_escape_filter($this->env, site_url(), "html", null, true);
            echo "/news/\">最新动态</a></li>
            </ul>
        </div>
    </div>
    ";
        }
        // line 76
        echo "    ";
    }

    // line 78
    public function block_data($context, array $blocks = array())
    {
        // line 79
        echo "    ";
    }

    // line 83
    public function block_footer($context, array $blocks = array())
    {
        // line 84
        echo "<footer class=\"footer\">
    <div class=\"container\">
        <p>
        &copy;";
        // line 87
        echo twig_escape_filter($this->env, date("Y"), "html", null, true);
        echo " iPad电子云菜谱后台系统
        </p>
    </div>
</footer>
";
    }

    public function getTemplateName()
    {
        return "site.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  279 => 87,  274 => 84,  271 => 83,  267 => 79,  264 => 78,  260 => 76,  247 => 71,  237 => 69,  227 => 67,  217 => 65,  206 => 63,  204 => 62,  199 => 59,  195 => 58,  192 => 57,  184 => 52,  180 => 50,  177 => 49,  172 => 80,  170 => 78,  167 => 77,  165 => 57,  162 => 56,  160 => 49,  152 => 43,  146 => 41,  140 => 39,  136 => 38,  130 => 36,  124 => 34,  121 => 33,  113 => 32,  107 => 30,  103 => 29,  101 => 28,  94 => 23,  91 => 22,  85 => 19,  81 => 18,  77 => 17,  73 => 16,  69 => 15,  64 => 13,  59 => 11,  55 => 10,  50 => 8,  46 => 7,  39 => 4,  36 => 3,  33 => 2,);
    }
}
