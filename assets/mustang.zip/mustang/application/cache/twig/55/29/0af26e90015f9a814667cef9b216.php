<?php

/* base.html */
class __TwigTemplate_55290af26e90015f9a814667cef9b216 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"utf-8\">
    <head>
    ";
        // line 4
        $this->displayBlock('head', $context, $blocks);
        // line 7
        echo "    </head>
    <body>
        <div id=\"content\">";
        // line 9
        $this->displayBlock('content', $context, $blocks);
        echo "</div>
        ";
        // line 10
        $this->displayBlock('footer', $context, $blocks);
        // line 13
        echo "    </body>
</html>
";
    }

    // line 4
    public function block_head($context, array $blocks = array())
    {
        // line 5
        echo "        <title>";
        $this->displayBlock('title', $context, $blocks);
        echo " - iPad电子云菜谱后台系统</title>
    ";
    }

    public function block_title($context, array $blocks = array())
    {
    }

    // line 9
    public function block_content($context, array $blocks = array())
    {
    }

    // line 10
    public function block_footer($context, array $blocks = array())
    {
        // line 11
        echo "        &copy; Copyright ";
        echo twig_escape_filter($this->env, date("Y"), "html", null, true);
        echo " by <a href=\"";
        echo twig_escape_filter($this->env, base_url(), "html", null, true);
        echo "\">iPad电子云菜谱后台系统</a>.
        ";
    }

    public function getTemplateName()
    {
        return "base.html";
    }

    public function getDebugInfo()
    {
        return array (  68 => 11,  65 => 10,  60 => 9,  49 => 5,  46 => 4,  40 => 13,  38 => 10,  34 => 9,  30 => 7,  23 => 1,  333 => 138,  322 => 130,  299 => 109,  296 => 108,  292 => 104,  289 => 103,  275 => 97,  265 => 95,  255 => 93,  245 => 91,  234 => 89,  232 => 88,  227 => 85,  224 => 84,  216 => 79,  187 => 55,  182 => 52,  179 => 51,  174 => 105,  172 => 103,  169 => 102,  167 => 84,  164 => 83,  162 => 51,  154 => 45,  148 => 43,  142 => 41,  138 => 40,  132 => 38,  126 => 36,  123 => 35,  115 => 34,  109 => 32,  105 => 31,  103 => 30,  96 => 25,  93 => 24,  87 => 21,  83 => 20,  79 => 19,  75 => 18,  71 => 17,  66 => 15,  57 => 12,  52 => 10,  48 => 9,  39 => 4,  36 => 3,  33 => 2,  80 => 34,  73 => 29,  61 => 13,  58 => 21,  55 => 20,  41 => 9,  35 => 6,  31 => 4,  28 => 4,);
    }
}
