<?php

/* error_index.html */
class __TwigTemplate_cc293f5f0b20596344a7886d4a04f198 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("site.html");

        $this->blocks = array(
            'data' => array($this, 'block_data'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "site.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_data($context, array $blocks = array())
    {
        // line 3
        echo "<div id=\"error-404\" class=\"container container-fluid\">
    <div class=\"row-fluid\">
        <div class=\"span5\">
        <!--Body content-->
        <img class=\"img-rounded\" src=\"";
        // line 7
        echo twig_escape_filter($this->env, base_url(), "html", null, true);
        echo "/assets/img/cars.png\" alt=\"页面不在，车在\" title=\"页面不在，车在\"/>
        </div>
        <div class=\"span5\">
            <h1>404</h1>
            <span>页面不在，车在，返回<a href=\"";
        // line 11
        echo twig_escape_filter($this->env, site_url(), "html", null, true);
        echo "\">首页</a>选您钟意的爱车吧~~</span>
        </div>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "error_index.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  44 => 11,  37 => 7,  31 => 3,  28 => 2,);
    }
}
