<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
 
$config['template'] = APPPATH . 'views';
$config['cache'] = APPPATH . 'cache/twig';
