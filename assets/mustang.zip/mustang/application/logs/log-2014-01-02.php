<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-01-02 03:57:49 --> Config Class Initialized
DEBUG - 2014-01-02 03:57:49 --> Hooks Class Initialized
DEBUG - 2014-01-02 03:57:49 --> Utf8 Class Initialized
DEBUG - 2014-01-02 03:57:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 03:57:49 --> URI Class Initialized
DEBUG - 2014-01-02 03:57:49 --> Router Class Initialized
DEBUG - 2014-01-02 03:57:49 --> Output Class Initialized
DEBUG - 2014-01-02 03:57:49 --> Security Class Initialized
DEBUG - 2014-01-02 03:57:49 --> Input Class Initialized
DEBUG - 2014-01-02 03:57:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 03:57:49 --> Language Class Initialized
DEBUG - 2014-01-02 03:57:49 --> Loader Class Initialized
DEBUG - 2014-01-02 03:57:49 --> Helper loaded: url_helper
DEBUG - 2014-01-02 03:57:49 --> Helper loaded: common_helper
DEBUG - 2014-01-02 03:57:49 --> Database Driver Class Initialized
DEBUG - 2014-01-02 03:57:49 --> Controller Class Initialized
DEBUG - 2014-01-02 03:57:49 --> Session Class Initialized
DEBUG - 2014-01-02 03:57:49 --> Helper loaded: string_helper
DEBUG - 2014-01-02 03:57:49 --> Encrypt Class Initialized
DEBUG - 2014-01-02 03:57:49 --> Session routines successfully run
DEBUG - 2014-01-02 03:57:49 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 03:57:49 --> Helper loaded: form_helper
DEBUG - 2014-01-02 03:57:49 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 03:57:49 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 03:57:49 --> lsession class already loaded. Second attempt ignored.
DEBUG - 2014-01-02 03:57:49 --> Final output sent to browser
DEBUG - 2014-01-02 03:57:49 --> Total execution time: 0.1078
DEBUG - 2014-01-02 03:57:50 --> Config Class Initialized
DEBUG - 2014-01-02 03:57:50 --> Hooks Class Initialized
DEBUG - 2014-01-02 03:57:50 --> Utf8 Class Initialized
DEBUG - 2014-01-02 03:57:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 03:57:50 --> URI Class Initialized
DEBUG - 2014-01-02 03:57:50 --> Router Class Initialized
DEBUG - 2014-01-02 03:57:50 --> Output Class Initialized
DEBUG - 2014-01-02 03:57:50 --> Security Class Initialized
DEBUG - 2014-01-02 03:57:50 --> Config Class Initialized
DEBUG - 2014-01-02 03:57:50 --> Hooks Class Initialized
DEBUG - 2014-01-02 03:57:50 --> Utf8 Class Initialized
DEBUG - 2014-01-02 03:57:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 03:57:50 --> URI Class Initialized
DEBUG - 2014-01-02 03:57:50 --> Router Class Initialized
DEBUG - 2014-01-02 03:57:50 --> Output Class Initialized
DEBUG - 2014-01-02 03:57:50 --> Security Class Initialized
DEBUG - 2014-01-02 03:57:50 --> Input Class Initialized
DEBUG - 2014-01-02 03:57:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 03:57:50 --> Input Class Initialized
DEBUG - 2014-01-02 03:57:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 03:57:50 --> Language Class Initialized
DEBUG - 2014-01-02 03:57:50 --> Loader Class Initialized
DEBUG - 2014-01-02 03:57:50 --> Language Class Initialized
DEBUG - 2014-01-02 03:57:50 --> Loader Class Initialized
DEBUG - 2014-01-02 03:57:50 --> Helper loaded: url_helper
DEBUG - 2014-01-02 03:57:50 --> Helper loaded: common_helper
DEBUG - 2014-01-02 03:57:50 --> Helper loaded: url_helper
DEBUG - 2014-01-02 03:57:50 --> Helper loaded: common_helper
DEBUG - 2014-01-02 03:57:50 --> Database Driver Class Initialized
DEBUG - 2014-01-02 03:57:50 --> Database Driver Class Initialized
DEBUG - 2014-01-02 03:57:50 --> Controller Class Initialized
DEBUG - 2014-01-02 03:57:50 --> Session Class Initialized
DEBUG - 2014-01-02 03:57:50 --> Helper loaded: string_helper
DEBUG - 2014-01-02 03:57:50 --> Encrypt Class Initialized
DEBUG - 2014-01-02 03:57:50 --> Session routines successfully run
DEBUG - 2014-01-02 03:57:50 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 03:57:50 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 03:57:50 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 03:57:50 --> Model Class Initialized
DEBUG - 2014-01-02 03:57:50 --> Model Class Initialized
DEBUG - 2014-01-02 03:57:50 --> DB Transaction Failure
ERROR - 2014-01-02 03:57:50 --> Query error: Table 'crebas.##article' doesn't exist
DEBUG - 2014-01-02 03:57:50 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-02 03:57:50 --> Controller Class Initialized
DEBUG - 2014-01-02 03:57:50 --> Session Class Initialized
DEBUG - 2014-01-02 03:57:50 --> Helper loaded: string_helper
DEBUG - 2014-01-02 03:57:50 --> Encrypt Class Initialized
DEBUG - 2014-01-02 03:57:50 --> Session routines successfully run
DEBUG - 2014-01-02 03:57:50 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 03:57:50 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 03:57:50 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 03:57:50 --> Model Class Initialized
DEBUG - 2014-01-02 03:57:50 --> Model Class Initialized
DEBUG - 2014-01-02 03:57:50 --> DB Transaction Failure
ERROR - 2014-01-02 03:57:50 --> Query error: Table 'crebas.##article' doesn't exist
DEBUG - 2014-01-02 03:57:50 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-02 03:57:59 --> Config Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Hooks Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Utf8 Class Initialized
DEBUG - 2014-01-02 03:57:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 03:57:59 --> URI Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Router Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Output Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Security Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Input Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 03:57:59 --> Language Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Loader Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Helper loaded: url_helper
DEBUG - 2014-01-02 03:57:59 --> Helper loaded: common_helper
DEBUG - 2014-01-02 03:57:59 --> Database Driver Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Controller Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Session Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Helper loaded: string_helper
DEBUG - 2014-01-02 03:57:59 --> Encrypt Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Session routines successfully run
DEBUG - 2014-01-02 03:57:59 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 03:57:59 --> Helper loaded: form_helper
DEBUG - 2014-01-02 03:57:59 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 03:57:59 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 03:57:59 --> lsession class already loaded. Second attempt ignored.
DEBUG - 2014-01-02 03:57:59 --> Final output sent to browser
DEBUG - 2014-01-02 03:57:59 --> Total execution time: 0.0684
DEBUG - 2014-01-02 03:57:59 --> Config Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Hooks Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Utf8 Class Initialized
DEBUG - 2014-01-02 03:57:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 03:57:59 --> Config Class Initialized
DEBUG - 2014-01-02 03:57:59 --> URI Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Router Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Hooks Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Utf8 Class Initialized
DEBUG - 2014-01-02 03:57:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 03:57:59 --> URI Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Router Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Output Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Security Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Input Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Output Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Security Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Input Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 03:57:59 --> Language Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 03:57:59 --> Language Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Loader Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Helper loaded: url_helper
DEBUG - 2014-01-02 03:57:59 --> Loader Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Helper loaded: url_helper
DEBUG - 2014-01-02 03:57:59 --> Helper loaded: common_helper
DEBUG - 2014-01-02 03:57:59 --> Helper loaded: common_helper
DEBUG - 2014-01-02 03:57:59 --> Database Driver Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Database Driver Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Controller Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Session Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Helper loaded: string_helper
DEBUG - 2014-01-02 03:57:59 --> Encrypt Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Session routines successfully run
DEBUG - 2014-01-02 03:57:59 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 03:57:59 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 03:57:59 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 03:57:59 --> Model Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Model Class Initialized
DEBUG - 2014-01-02 03:57:59 --> DB Transaction Failure
ERROR - 2014-01-02 03:57:59 --> Query error: Table 'crebas.##article' doesn't exist
DEBUG - 2014-01-02 03:57:59 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-02 03:57:59 --> Controller Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Session Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Helper loaded: string_helper
DEBUG - 2014-01-02 03:57:59 --> Encrypt Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Session routines successfully run
DEBUG - 2014-01-02 03:57:59 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 03:57:59 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 03:57:59 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 03:57:59 --> Model Class Initialized
DEBUG - 2014-01-02 03:57:59 --> Model Class Initialized
DEBUG - 2014-01-02 03:57:59 --> DB Transaction Failure
ERROR - 2014-01-02 03:57:59 --> Query error: Table 'crebas.##article' doesn't exist
DEBUG - 2014-01-02 03:57:59 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-02 03:58:26 --> Config Class Initialized
DEBUG - 2014-01-02 03:58:26 --> Hooks Class Initialized
DEBUG - 2014-01-02 03:58:26 --> Utf8 Class Initialized
DEBUG - 2014-01-02 03:58:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 03:58:26 --> URI Class Initialized
DEBUG - 2014-01-02 03:58:26 --> Router Class Initialized
DEBUG - 2014-01-02 03:58:26 --> Output Class Initialized
DEBUG - 2014-01-02 03:58:26 --> Security Class Initialized
DEBUG - 2014-01-02 03:58:26 --> Input Class Initialized
DEBUG - 2014-01-02 03:58:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 03:58:26 --> Language Class Initialized
DEBUG - 2014-01-02 03:58:26 --> Loader Class Initialized
DEBUG - 2014-01-02 03:58:26 --> Helper loaded: url_helper
DEBUG - 2014-01-02 03:58:26 --> Helper loaded: common_helper
DEBUG - 2014-01-02 03:58:26 --> Database Driver Class Initialized
DEBUG - 2014-01-02 03:58:26 --> Controller Class Initialized
DEBUG - 2014-01-02 03:58:26 --> Session Class Initialized
DEBUG - 2014-01-02 03:58:26 --> Helper loaded: string_helper
DEBUG - 2014-01-02 03:58:26 --> Encrypt Class Initialized
DEBUG - 2014-01-02 03:58:26 --> Session routines successfully run
DEBUG - 2014-01-02 03:58:26 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 03:58:26 --> Helper loaded: form_helper
DEBUG - 2014-01-02 03:58:26 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 03:58:26 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 03:58:26 --> lsession class already loaded. Second attempt ignored.
DEBUG - 2014-01-02 03:58:26 --> Final output sent to browser
DEBUG - 2014-01-02 03:58:26 --> Total execution time: 0.1825
DEBUG - 2014-01-02 03:58:27 --> Config Class Initialized
DEBUG - 2014-01-02 03:58:27 --> Hooks Class Initialized
DEBUG - 2014-01-02 03:58:27 --> Utf8 Class Initialized
DEBUG - 2014-01-02 03:58:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 03:58:27 --> URI Class Initialized
DEBUG - 2014-01-02 03:58:27 --> Config Class Initialized
DEBUG - 2014-01-02 03:58:27 --> Hooks Class Initialized
DEBUG - 2014-01-02 03:58:27 --> Utf8 Class Initialized
DEBUG - 2014-01-02 03:58:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 03:58:27 --> URI Class Initialized
DEBUG - 2014-01-02 03:58:27 --> Router Class Initialized
DEBUG - 2014-01-02 03:58:27 --> Output Class Initialized
DEBUG - 2014-01-02 03:58:27 --> Router Class Initialized
DEBUG - 2014-01-02 03:58:27 --> Output Class Initialized
DEBUG - 2014-01-02 03:58:27 --> Security Class Initialized
DEBUG - 2014-01-02 03:58:27 --> Input Class Initialized
DEBUG - 2014-01-02 03:58:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 03:58:27 --> Security Class Initialized
DEBUG - 2014-01-02 03:58:27 --> Input Class Initialized
DEBUG - 2014-01-02 03:58:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 03:58:27 --> Language Class Initialized
DEBUG - 2014-01-02 03:58:27 --> Language Class Initialized
DEBUG - 2014-01-02 03:58:27 --> Loader Class Initialized
DEBUG - 2014-01-02 03:58:27 --> Loader Class Initialized
DEBUG - 2014-01-02 03:58:27 --> Helper loaded: url_helper
DEBUG - 2014-01-02 03:58:27 --> Helper loaded: common_helper
DEBUG - 2014-01-02 03:58:27 --> Helper loaded: url_helper
DEBUG - 2014-01-02 03:58:27 --> Helper loaded: common_helper
DEBUG - 2014-01-02 03:58:27 --> Database Driver Class Initialized
DEBUG - 2014-01-02 03:58:27 --> Database Driver Class Initialized
DEBUG - 2014-01-02 03:58:27 --> Controller Class Initialized
DEBUG - 2014-01-02 03:58:27 --> Session Class Initialized
DEBUG - 2014-01-02 03:58:27 --> Helper loaded: string_helper
DEBUG - 2014-01-02 03:58:27 --> Encrypt Class Initialized
DEBUG - 2014-01-02 03:58:27 --> Session routines successfully run
DEBUG - 2014-01-02 03:58:27 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 03:58:27 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 03:58:27 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 03:58:27 --> Model Class Initialized
DEBUG - 2014-01-02 03:58:27 --> Model Class Initialized
DEBUG - 2014-01-02 03:58:27 --> DB Transaction Failure
ERROR - 2014-01-02 03:58:27 --> Query error: Table 'crebas.##article' doesn't exist
DEBUG - 2014-01-02 03:58:27 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-02 03:58:27 --> Controller Class Initialized
DEBUG - 2014-01-02 03:58:27 --> Session Class Initialized
DEBUG - 2014-01-02 03:58:27 --> Helper loaded: string_helper
DEBUG - 2014-01-02 03:58:27 --> Encrypt Class Initialized
DEBUG - 2014-01-02 03:58:27 --> Session routines successfully run
DEBUG - 2014-01-02 03:58:27 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 03:58:27 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 03:58:27 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 03:58:27 --> Model Class Initialized
DEBUG - 2014-01-02 03:58:27 --> Model Class Initialized
DEBUG - 2014-01-02 03:58:27 --> DB Transaction Failure
ERROR - 2014-01-02 03:58:27 --> Query error: Table 'crebas.##article' doesn't exist
DEBUG - 2014-01-02 03:58:27 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-02 04:00:38 --> Config Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Hooks Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Utf8 Class Initialized
DEBUG - 2014-01-02 04:00:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 04:00:38 --> URI Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Router Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Output Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Security Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Input Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 04:00:38 --> Language Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Loader Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Helper loaded: url_helper
DEBUG - 2014-01-02 04:00:38 --> Helper loaded: common_helper
DEBUG - 2014-01-02 04:00:38 --> Database Driver Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Controller Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Session Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Helper loaded: string_helper
DEBUG - 2014-01-02 04:00:38 --> Encrypt Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Session routines successfully run
DEBUG - 2014-01-02 04:00:38 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 04:00:38 --> Helper loaded: form_helper
DEBUG - 2014-01-02 04:00:38 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 04:00:38 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 04:00:38 --> lsession class already loaded. Second attempt ignored.
DEBUG - 2014-01-02 04:00:38 --> Final output sent to browser
DEBUG - 2014-01-02 04:00:38 --> Total execution time: 0.1623
DEBUG - 2014-01-02 04:00:38 --> Config Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Hooks Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Utf8 Class Initialized
DEBUG - 2014-01-02 04:00:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 04:00:38 --> URI Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Config Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Router Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Output Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Security Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Hooks Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Utf8 Class Initialized
DEBUG - 2014-01-02 04:00:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 04:00:38 --> URI Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Router Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Input Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 04:00:38 --> Language Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Loader Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Helper loaded: url_helper
DEBUG - 2014-01-02 04:00:38 --> Helper loaded: common_helper
DEBUG - 2014-01-02 04:00:38 --> Output Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Security Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Input Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 04:00:38 --> Language Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Loader Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Helper loaded: url_helper
DEBUG - 2014-01-02 04:00:38 --> Helper loaded: common_helper
DEBUG - 2014-01-02 04:00:38 --> Database Driver Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Database Driver Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Controller Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Session Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Helper loaded: string_helper
DEBUG - 2014-01-02 04:00:38 --> Encrypt Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Session routines successfully run
DEBUG - 2014-01-02 04:00:38 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 04:00:38 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 04:00:38 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 04:00:38 --> Model Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Model Class Initialized
DEBUG - 2014-01-02 04:00:38 --> DB Transaction Failure
ERROR - 2014-01-02 04:00:38 --> Query error: Table 'crebas.##article' doesn't exist
DEBUG - 2014-01-02 04:00:38 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-02 04:00:38 --> Controller Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Session Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Helper loaded: string_helper
DEBUG - 2014-01-02 04:00:38 --> Encrypt Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Session routines successfully run
DEBUG - 2014-01-02 04:00:38 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 04:00:38 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 04:00:38 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 04:00:38 --> Model Class Initialized
DEBUG - 2014-01-02 04:00:38 --> Model Class Initialized
DEBUG - 2014-01-02 04:00:38 --> DB Transaction Failure
ERROR - 2014-01-02 04:00:38 --> Query error: Table 'crebas.##article' doesn't exist
DEBUG - 2014-01-02 04:00:38 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-02 04:01:45 --> Config Class Initialized
DEBUG - 2014-01-02 04:01:45 --> Hooks Class Initialized
DEBUG - 2014-01-02 04:01:45 --> Utf8 Class Initialized
DEBUG - 2014-01-02 04:01:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 04:01:45 --> URI Class Initialized
DEBUG - 2014-01-02 04:01:45 --> Router Class Initialized
DEBUG - 2014-01-02 04:01:45 --> Output Class Initialized
DEBUG - 2014-01-02 04:01:45 --> Security Class Initialized
DEBUG - 2014-01-02 04:01:45 --> Input Class Initialized
DEBUG - 2014-01-02 04:01:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 04:01:45 --> Language Class Initialized
DEBUG - 2014-01-02 04:01:45 --> Loader Class Initialized
DEBUG - 2014-01-02 04:01:45 --> Helper loaded: url_helper
DEBUG - 2014-01-02 04:01:45 --> Helper loaded: common_helper
DEBUG - 2014-01-02 04:01:45 --> Database Driver Class Initialized
DEBUG - 2014-01-02 04:01:45 --> Controller Class Initialized
DEBUG - 2014-01-02 04:01:45 --> Session Class Initialized
DEBUG - 2014-01-02 04:01:45 --> Helper loaded: string_helper
DEBUG - 2014-01-02 04:01:45 --> Encrypt Class Initialized
DEBUG - 2014-01-02 04:01:45 --> Session routines successfully run
DEBUG - 2014-01-02 04:01:45 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 04:01:45 --> Helper loaded: form_helper
DEBUG - 2014-01-02 04:01:45 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 04:01:45 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 04:01:45 --> lsession class already loaded. Second attempt ignored.
DEBUG - 2014-01-02 04:01:45 --> Final output sent to browser
DEBUG - 2014-01-02 04:01:45 --> Total execution time: 0.1420
DEBUG - 2014-01-02 04:02:15 --> Config Class Initialized
DEBUG - 2014-01-02 04:02:15 --> Hooks Class Initialized
DEBUG - 2014-01-02 04:02:15 --> Utf8 Class Initialized
DEBUG - 2014-01-02 04:02:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 04:02:15 --> URI Class Initialized
DEBUG - 2014-01-02 04:02:15 --> Router Class Initialized
DEBUG - 2014-01-02 04:02:15 --> Output Class Initialized
DEBUG - 2014-01-02 04:02:15 --> Security Class Initialized
DEBUG - 2014-01-02 04:02:15 --> Input Class Initialized
DEBUG - 2014-01-02 04:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 04:02:15 --> Language Class Initialized
DEBUG - 2014-01-02 04:02:15 --> Loader Class Initialized
DEBUG - 2014-01-02 04:02:15 --> Helper loaded: url_helper
DEBUG - 2014-01-02 04:02:15 --> Helper loaded: common_helper
DEBUG - 2014-01-02 04:02:15 --> Database Driver Class Initialized
DEBUG - 2014-01-02 04:02:15 --> Controller Class Initialized
DEBUG - 2014-01-02 04:02:15 --> Session Class Initialized
DEBUG - 2014-01-02 04:02:15 --> Helper loaded: string_helper
DEBUG - 2014-01-02 04:02:15 --> Encrypt Class Initialized
DEBUG - 2014-01-02 04:02:15 --> Session routines successfully run
DEBUG - 2014-01-02 04:02:15 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 04:02:15 --> Helper loaded: form_helper
DEBUG - 2014-01-02 04:02:15 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 04:02:15 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 04:02:15 --> lsession class already loaded. Second attempt ignored.
DEBUG - 2014-01-02 04:02:15 --> Final output sent to browser
DEBUG - 2014-01-02 04:02:15 --> Total execution time: 0.1533
DEBUG - 2014-01-02 04:02:22 --> Config Class Initialized
DEBUG - 2014-01-02 04:02:22 --> Hooks Class Initialized
DEBUG - 2014-01-02 04:02:22 --> Utf8 Class Initialized
DEBUG - 2014-01-02 04:02:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 04:02:22 --> URI Class Initialized
DEBUG - 2014-01-02 04:02:22 --> Router Class Initialized
DEBUG - 2014-01-02 04:02:22 --> Output Class Initialized
DEBUG - 2014-01-02 04:02:22 --> Security Class Initialized
DEBUG - 2014-01-02 04:02:22 --> Input Class Initialized
DEBUG - 2014-01-02 04:02:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 04:02:22 --> Language Class Initialized
DEBUG - 2014-01-02 04:02:22 --> Loader Class Initialized
DEBUG - 2014-01-02 04:02:22 --> Helper loaded: url_helper
DEBUG - 2014-01-02 04:02:22 --> Helper loaded: common_helper
DEBUG - 2014-01-02 04:02:22 --> Database Driver Class Initialized
DEBUG - 2014-01-02 04:02:22 --> Controller Class Initialized
DEBUG - 2014-01-02 04:02:22 --> Session Class Initialized
DEBUG - 2014-01-02 04:02:22 --> Helper loaded: string_helper
DEBUG - 2014-01-02 04:02:22 --> Encrypt Class Initialized
DEBUG - 2014-01-02 04:02:22 --> Session routines successfully run
DEBUG - 2014-01-02 04:02:22 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 04:02:22 --> Helper loaded: form_helper
DEBUG - 2014-01-02 04:02:22 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 04:02:22 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 04:02:22 --> lsession class already loaded. Second attempt ignored.
DEBUG - 2014-01-02 04:02:22 --> Final output sent to browser
DEBUG - 2014-01-02 04:02:22 --> Total execution time: 0.1496
DEBUG - 2014-01-02 04:05:33 --> Config Class Initialized
DEBUG - 2014-01-02 04:05:33 --> Hooks Class Initialized
DEBUG - 2014-01-02 04:05:33 --> Utf8 Class Initialized
DEBUG - 2014-01-02 04:05:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 04:05:33 --> URI Class Initialized
DEBUG - 2014-01-02 04:05:33 --> Router Class Initialized
DEBUG - 2014-01-02 04:05:33 --> Output Class Initialized
DEBUG - 2014-01-02 04:05:33 --> Security Class Initialized
DEBUG - 2014-01-02 04:05:33 --> Input Class Initialized
DEBUG - 2014-01-02 04:05:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 04:05:33 --> Language Class Initialized
DEBUG - 2014-01-02 04:05:33 --> Loader Class Initialized
DEBUG - 2014-01-02 04:05:33 --> Helper loaded: url_helper
DEBUG - 2014-01-02 04:05:33 --> Helper loaded: common_helper
DEBUG - 2014-01-02 04:05:33 --> Database Driver Class Initialized
DEBUG - 2014-01-02 04:05:33 --> Controller Class Initialized
DEBUG - 2014-01-02 04:05:33 --> Session Class Initialized
DEBUG - 2014-01-02 04:05:33 --> Helper loaded: string_helper
DEBUG - 2014-01-02 04:05:33 --> Encrypt Class Initialized
DEBUG - 2014-01-02 04:05:33 --> Session routines successfully run
DEBUG - 2014-01-02 04:05:33 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 04:05:33 --> Helper loaded: form_helper
DEBUG - 2014-01-02 04:05:33 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 04:05:33 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 04:05:33 --> lsession class already loaded. Second attempt ignored.
DEBUG - 2014-01-02 04:05:33 --> Final output sent to browser
DEBUG - 2014-01-02 04:05:33 --> Total execution time: 0.1562
DEBUG - 2014-01-02 04:08:06 --> Config Class Initialized
DEBUG - 2014-01-02 04:08:06 --> Hooks Class Initialized
DEBUG - 2014-01-02 04:08:06 --> Utf8 Class Initialized
DEBUG - 2014-01-02 04:08:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 04:08:06 --> URI Class Initialized
DEBUG - 2014-01-02 04:08:06 --> Router Class Initialized
DEBUG - 2014-01-02 04:08:06 --> Output Class Initialized
DEBUG - 2014-01-02 04:08:06 --> Security Class Initialized
DEBUG - 2014-01-02 04:08:06 --> Input Class Initialized
DEBUG - 2014-01-02 04:08:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 04:08:06 --> Language Class Initialized
DEBUG - 2014-01-02 04:08:06 --> Loader Class Initialized
DEBUG - 2014-01-02 04:08:06 --> Helper loaded: url_helper
DEBUG - 2014-01-02 04:08:06 --> Helper loaded: common_helper
DEBUG - 2014-01-02 04:08:06 --> Database Driver Class Initialized
DEBUG - 2014-01-02 04:08:06 --> Controller Class Initialized
DEBUG - 2014-01-02 04:08:06 --> Session Class Initialized
DEBUG - 2014-01-02 04:08:06 --> Helper loaded: string_helper
DEBUG - 2014-01-02 04:08:06 --> Encrypt Class Initialized
DEBUG - 2014-01-02 04:08:06 --> Session routines successfully run
DEBUG - 2014-01-02 04:08:06 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 04:08:06 --> Helper loaded: form_helper
DEBUG - 2014-01-02 04:08:06 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 04:08:06 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 04:08:06 --> lsession class already loaded. Second attempt ignored.
DEBUG - 2014-01-02 04:08:06 --> Final output sent to browser
DEBUG - 2014-01-02 04:08:06 --> Total execution time: 0.1375
DEBUG - 2014-01-02 04:08:07 --> Config Class Initialized
DEBUG - 2014-01-02 04:08:07 --> Hooks Class Initialized
DEBUG - 2014-01-02 04:08:07 --> Utf8 Class Initialized
DEBUG - 2014-01-02 04:08:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 04:08:07 --> URI Class Initialized
DEBUG - 2014-01-02 04:08:07 --> Router Class Initialized
DEBUG - 2014-01-02 04:08:07 --> Output Class Initialized
DEBUG - 2014-01-02 04:08:07 --> Security Class Initialized
DEBUG - 2014-01-02 04:08:07 --> Input Class Initialized
DEBUG - 2014-01-02 04:08:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 04:08:07 --> Language Class Initialized
DEBUG - 2014-01-02 04:08:07 --> Loader Class Initialized
DEBUG - 2014-01-02 04:08:07 --> Helper loaded: url_helper
DEBUG - 2014-01-02 04:08:07 --> Helper loaded: common_helper
DEBUG - 2014-01-02 04:08:07 --> Database Driver Class Initialized
DEBUG - 2014-01-02 04:08:07 --> Controller Class Initialized
DEBUG - 2014-01-02 04:08:07 --> Session Class Initialized
DEBUG - 2014-01-02 04:08:07 --> Helper loaded: string_helper
DEBUG - 2014-01-02 04:08:07 --> Encrypt Class Initialized
DEBUG - 2014-01-02 04:08:07 --> Session routines successfully run
DEBUG - 2014-01-02 04:08:07 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 04:08:07 --> Helper loaded: form_helper
DEBUG - 2014-01-02 04:08:07 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 04:08:07 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 04:08:08 --> lsession class already loaded. Second attempt ignored.
DEBUG - 2014-01-02 04:08:08 --> Final output sent to browser
DEBUG - 2014-01-02 04:08:08 --> Total execution time: 0.0668
DEBUG - 2014-01-02 04:08:13 --> Config Class Initialized
DEBUG - 2014-01-02 04:08:13 --> Hooks Class Initialized
DEBUG - 2014-01-02 04:08:13 --> Utf8 Class Initialized
DEBUG - 2014-01-02 04:08:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 04:08:13 --> URI Class Initialized
DEBUG - 2014-01-02 04:08:13 --> Router Class Initialized
DEBUG - 2014-01-02 04:08:13 --> Output Class Initialized
DEBUG - 2014-01-02 04:08:13 --> Security Class Initialized
DEBUG - 2014-01-02 04:08:13 --> Input Class Initialized
DEBUG - 2014-01-02 04:08:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 04:08:13 --> Language Class Initialized
DEBUG - 2014-01-02 04:08:13 --> Loader Class Initialized
DEBUG - 2014-01-02 04:08:13 --> Helper loaded: url_helper
DEBUG - 2014-01-02 04:08:13 --> Helper loaded: common_helper
DEBUG - 2014-01-02 04:08:13 --> Database Driver Class Initialized
DEBUG - 2014-01-02 04:08:13 --> Controller Class Initialized
DEBUG - 2014-01-02 04:08:13 --> Session Class Initialized
DEBUG - 2014-01-02 04:08:13 --> Helper loaded: string_helper
DEBUG - 2014-01-02 04:08:13 --> Encrypt Class Initialized
DEBUG - 2014-01-02 04:08:13 --> Session routines successfully run
DEBUG - 2014-01-02 04:08:13 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 04:08:13 --> Helper loaded: form_helper
DEBUG - 2014-01-02 04:08:13 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 04:08:13 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 04:08:13 --> lsession class already loaded. Second attempt ignored.
DEBUG - 2014-01-02 04:08:13 --> Final output sent to browser
DEBUG - 2014-01-02 04:08:13 --> Total execution time: 0.1479
DEBUG - 2014-01-02 04:09:02 --> Config Class Initialized
DEBUG - 2014-01-02 04:09:02 --> Hooks Class Initialized
DEBUG - 2014-01-02 04:09:02 --> Utf8 Class Initialized
DEBUG - 2014-01-02 04:09:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 04:09:02 --> URI Class Initialized
DEBUG - 2014-01-02 04:09:02 --> Router Class Initialized
DEBUG - 2014-01-02 04:09:02 --> Output Class Initialized
DEBUG - 2014-01-02 04:09:02 --> Security Class Initialized
DEBUG - 2014-01-02 04:09:02 --> Input Class Initialized
DEBUG - 2014-01-02 04:09:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 04:09:02 --> Language Class Initialized
DEBUG - 2014-01-02 04:09:02 --> Loader Class Initialized
DEBUG - 2014-01-02 04:09:02 --> Helper loaded: url_helper
DEBUG - 2014-01-02 04:09:02 --> Helper loaded: common_helper
DEBUG - 2014-01-02 04:09:02 --> Database Driver Class Initialized
DEBUG - 2014-01-02 04:09:02 --> Controller Class Initialized
DEBUG - 2014-01-02 04:09:02 --> Session Class Initialized
DEBUG - 2014-01-02 04:09:02 --> Helper loaded: string_helper
DEBUG - 2014-01-02 04:09:02 --> Encrypt Class Initialized
DEBUG - 2014-01-02 04:09:02 --> Session routines successfully run
DEBUG - 2014-01-02 04:09:02 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 04:09:02 --> Helper loaded: form_helper
DEBUG - 2014-01-02 04:09:02 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 04:09:02 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 04:09:03 --> lsession class already loaded. Second attempt ignored.
DEBUG - 2014-01-02 04:09:03 --> Final output sent to browser
DEBUG - 2014-01-02 04:09:03 --> Total execution time: 0.1522
DEBUG - 2014-01-02 04:09:25 --> Config Class Initialized
DEBUG - 2014-01-02 04:09:25 --> Hooks Class Initialized
DEBUG - 2014-01-02 04:09:25 --> Utf8 Class Initialized
DEBUG - 2014-01-02 04:09:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 04:09:25 --> URI Class Initialized
DEBUG - 2014-01-02 04:09:25 --> Router Class Initialized
DEBUG - 2014-01-02 04:09:25 --> Output Class Initialized
DEBUG - 2014-01-02 04:09:25 --> Security Class Initialized
DEBUG - 2014-01-02 04:09:25 --> Input Class Initialized
DEBUG - 2014-01-02 04:09:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 04:09:25 --> Language Class Initialized
DEBUG - 2014-01-02 04:09:25 --> Loader Class Initialized
DEBUG - 2014-01-02 04:09:25 --> Helper loaded: url_helper
DEBUG - 2014-01-02 04:09:25 --> Helper loaded: common_helper
DEBUG - 2014-01-02 04:09:25 --> Database Driver Class Initialized
DEBUG - 2014-01-02 04:09:25 --> Controller Class Initialized
DEBUG - 2014-01-02 04:09:25 --> Session Class Initialized
DEBUG - 2014-01-02 04:09:25 --> Helper loaded: string_helper
DEBUG - 2014-01-02 04:09:25 --> Encrypt Class Initialized
DEBUG - 2014-01-02 04:09:25 --> Session routines successfully run
DEBUG - 2014-01-02 04:09:25 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 04:09:25 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 04:09:25 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 04:09:25 --> DB Transaction Failure
ERROR - 2014-01-02 04:09:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
DEBUG - 2014-01-02 04:09:25 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-02 04:09:27 --> Config Class Initialized
DEBUG - 2014-01-02 04:09:27 --> Hooks Class Initialized
DEBUG - 2014-01-02 04:09:27 --> Utf8 Class Initialized
DEBUG - 2014-01-02 04:09:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 04:09:27 --> URI Class Initialized
DEBUG - 2014-01-02 04:09:27 --> Router Class Initialized
DEBUG - 2014-01-02 04:09:27 --> Output Class Initialized
DEBUG - 2014-01-02 04:09:27 --> Security Class Initialized
DEBUG - 2014-01-02 04:09:27 --> Input Class Initialized
DEBUG - 2014-01-02 04:09:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 04:09:27 --> Language Class Initialized
DEBUG - 2014-01-02 04:09:27 --> Loader Class Initialized
DEBUG - 2014-01-02 04:09:27 --> Helper loaded: url_helper
DEBUG - 2014-01-02 04:09:27 --> Helper loaded: common_helper
DEBUG - 2014-01-02 04:09:27 --> Database Driver Class Initialized
DEBUG - 2014-01-02 04:09:27 --> Controller Class Initialized
DEBUG - 2014-01-02 04:09:27 --> Session Class Initialized
DEBUG - 2014-01-02 04:09:27 --> Helper loaded: string_helper
DEBUG - 2014-01-02 04:09:27 --> Encrypt Class Initialized
DEBUG - 2014-01-02 04:09:27 --> Session routines successfully run
DEBUG - 2014-01-02 04:09:27 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 04:09:27 --> Helper loaded: form_helper
DEBUG - 2014-01-02 04:09:27 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 04:09:27 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 04:09:27 --> lsession class already loaded. Second attempt ignored.
DEBUG - 2014-01-02 04:09:27 --> Final output sent to browser
DEBUG - 2014-01-02 04:09:27 --> Total execution time: 0.0673
DEBUG - 2014-01-02 04:11:23 --> Config Class Initialized
DEBUG - 2014-01-02 04:11:23 --> Hooks Class Initialized
DEBUG - 2014-01-02 04:11:23 --> Utf8 Class Initialized
DEBUG - 2014-01-02 04:11:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 04:11:23 --> URI Class Initialized
DEBUG - 2014-01-02 04:11:23 --> Router Class Initialized
DEBUG - 2014-01-02 04:11:23 --> Output Class Initialized
DEBUG - 2014-01-02 04:11:23 --> Security Class Initialized
DEBUG - 2014-01-02 04:11:23 --> Input Class Initialized
DEBUG - 2014-01-02 04:11:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 04:11:23 --> Language Class Initialized
DEBUG - 2014-01-02 04:11:23 --> Loader Class Initialized
DEBUG - 2014-01-02 04:11:23 --> Helper loaded: url_helper
DEBUG - 2014-01-02 04:11:23 --> Helper loaded: common_helper
DEBUG - 2014-01-02 04:11:23 --> Database Driver Class Initialized
DEBUG - 2014-01-02 04:11:23 --> Controller Class Initialized
DEBUG - 2014-01-02 04:11:23 --> Session Class Initialized
DEBUG - 2014-01-02 04:11:23 --> Helper loaded: string_helper
DEBUG - 2014-01-02 04:11:23 --> Encrypt Class Initialized
DEBUG - 2014-01-02 04:11:23 --> Session routines successfully run
DEBUG - 2014-01-02 04:11:23 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 04:11:23 --> Helper loaded: form_helper
DEBUG - 2014-01-02 04:11:23 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 04:11:23 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 04:11:23 --> lsession class already loaded. Second attempt ignored.
DEBUG - 2014-01-02 04:11:23 --> Final output sent to browser
DEBUG - 2014-01-02 04:11:23 --> Total execution time: 0.1633
DEBUG - 2014-01-02 04:11:43 --> Config Class Initialized
DEBUG - 2014-01-02 04:11:43 --> Hooks Class Initialized
DEBUG - 2014-01-02 04:11:43 --> Utf8 Class Initialized
DEBUG - 2014-01-02 04:11:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 04:11:43 --> URI Class Initialized
DEBUG - 2014-01-02 04:11:43 --> Router Class Initialized
DEBUG - 2014-01-02 04:11:43 --> Output Class Initialized
DEBUG - 2014-01-02 04:11:43 --> Security Class Initialized
DEBUG - 2014-01-02 04:11:43 --> Input Class Initialized
DEBUG - 2014-01-02 04:11:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 04:11:43 --> Language Class Initialized
DEBUG - 2014-01-02 04:11:43 --> Loader Class Initialized
DEBUG - 2014-01-02 04:11:43 --> Helper loaded: url_helper
DEBUG - 2014-01-02 04:11:43 --> Helper loaded: common_helper
DEBUG - 2014-01-02 04:11:43 --> Database Driver Class Initialized
DEBUG - 2014-01-02 04:11:43 --> Controller Class Initialized
DEBUG - 2014-01-02 04:11:43 --> Session Class Initialized
DEBUG - 2014-01-02 04:11:43 --> Helper loaded: string_helper
DEBUG - 2014-01-02 04:11:43 --> Encrypt Class Initialized
DEBUG - 2014-01-02 04:11:43 --> Session routines successfully run
DEBUG - 2014-01-02 04:11:43 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 04:11:43 --> Helper loaded: form_helper
DEBUG - 2014-01-02 04:11:43 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 04:11:43 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 04:11:43 --> lsession class already loaded. Second attempt ignored.
DEBUG - 2014-01-02 04:11:43 --> Final output sent to browser
DEBUG - 2014-01-02 04:11:43 --> Total execution time: 0.1016
DEBUG - 2014-01-02 04:12:03 --> Config Class Initialized
DEBUG - 2014-01-02 04:12:03 --> Hooks Class Initialized
DEBUG - 2014-01-02 04:12:03 --> Utf8 Class Initialized
DEBUG - 2014-01-02 04:12:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 04:12:03 --> URI Class Initialized
DEBUG - 2014-01-02 04:12:03 --> Router Class Initialized
DEBUG - 2014-01-02 04:12:03 --> Output Class Initialized
DEBUG - 2014-01-02 04:12:03 --> Security Class Initialized
DEBUG - 2014-01-02 04:12:03 --> Input Class Initialized
DEBUG - 2014-01-02 04:12:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 04:12:03 --> Language Class Initialized
DEBUG - 2014-01-02 04:12:03 --> Loader Class Initialized
DEBUG - 2014-01-02 04:12:03 --> Helper loaded: url_helper
DEBUG - 2014-01-02 04:12:03 --> Helper loaded: common_helper
DEBUG - 2014-01-02 04:12:03 --> Database Driver Class Initialized
DEBUG - 2014-01-02 04:12:03 --> Controller Class Initialized
DEBUG - 2014-01-02 04:12:03 --> Session Class Initialized
DEBUG - 2014-01-02 04:12:03 --> Helper loaded: string_helper
DEBUG - 2014-01-02 04:12:03 --> Encrypt Class Initialized
DEBUG - 2014-01-02 04:12:03 --> Session routines successfully run
DEBUG - 2014-01-02 04:12:03 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 04:12:03 --> Helper loaded: form_helper
DEBUG - 2014-01-02 04:12:03 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 04:12:03 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 04:12:03 --> lsession class already loaded. Second attempt ignored.
DEBUG - 2014-01-02 04:12:03 --> Final output sent to browser
DEBUG - 2014-01-02 04:12:03 --> Total execution time: 0.0993
DEBUG - 2014-01-02 04:12:04 --> Config Class Initialized
DEBUG - 2014-01-02 04:12:04 --> Hooks Class Initialized
DEBUG - 2014-01-02 04:12:04 --> Utf8 Class Initialized
DEBUG - 2014-01-02 04:12:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 04:12:04 --> URI Class Initialized
DEBUG - 2014-01-02 04:12:04 --> Router Class Initialized
DEBUG - 2014-01-02 04:12:04 --> Output Class Initialized
DEBUG - 2014-01-02 04:12:04 --> Security Class Initialized
DEBUG - 2014-01-02 04:12:04 --> Input Class Initialized
DEBUG - 2014-01-02 04:12:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 04:12:04 --> Language Class Initialized
DEBUG - 2014-01-02 04:12:04 --> Loader Class Initialized
DEBUG - 2014-01-02 04:12:04 --> Helper loaded: url_helper
DEBUG - 2014-01-02 04:12:04 --> Helper loaded: common_helper
DEBUG - 2014-01-02 04:12:04 --> Database Driver Class Initialized
DEBUG - 2014-01-02 04:12:04 --> Controller Class Initialized
DEBUG - 2014-01-02 04:12:04 --> Session Class Initialized
DEBUG - 2014-01-02 04:12:04 --> Helper loaded: string_helper
DEBUG - 2014-01-02 04:12:04 --> Encrypt Class Initialized
DEBUG - 2014-01-02 04:12:04 --> Session routines successfully run
DEBUG - 2014-01-02 04:12:04 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 04:12:04 --> Helper loaded: form_helper
DEBUG - 2014-01-02 04:12:04 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 04:12:04 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 04:12:04 --> lsession class already loaded. Second attempt ignored.
DEBUG - 2014-01-02 04:12:04 --> Final output sent to browser
DEBUG - 2014-01-02 04:12:04 --> Total execution time: 0.0697
DEBUG - 2014-01-02 04:12:21 --> Config Class Initialized
DEBUG - 2014-01-02 04:12:21 --> Hooks Class Initialized
DEBUG - 2014-01-02 04:12:21 --> Utf8 Class Initialized
DEBUG - 2014-01-02 04:12:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 04:12:21 --> URI Class Initialized
DEBUG - 2014-01-02 04:12:21 --> Router Class Initialized
DEBUG - 2014-01-02 04:12:21 --> Output Class Initialized
DEBUG - 2014-01-02 04:12:21 --> Security Class Initialized
DEBUG - 2014-01-02 04:12:21 --> Input Class Initialized
DEBUG - 2014-01-02 04:12:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 04:12:21 --> Language Class Initialized
DEBUG - 2014-01-02 04:12:21 --> Loader Class Initialized
DEBUG - 2014-01-02 04:12:21 --> Helper loaded: url_helper
DEBUG - 2014-01-02 04:12:21 --> Helper loaded: common_helper
DEBUG - 2014-01-02 04:12:21 --> Database Driver Class Initialized
DEBUG - 2014-01-02 04:12:21 --> Controller Class Initialized
DEBUG - 2014-01-02 04:12:21 --> Session Class Initialized
DEBUG - 2014-01-02 04:12:21 --> Helper loaded: string_helper
DEBUG - 2014-01-02 04:12:21 --> Encrypt Class Initialized
DEBUG - 2014-01-02 04:12:21 --> Session routines successfully run
DEBUG - 2014-01-02 04:12:21 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 04:12:21 --> Helper loaded: form_helper
DEBUG - 2014-01-02 04:12:21 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 04:12:21 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 04:12:21 --> lsession class already loaded. Second attempt ignored.
DEBUG - 2014-01-02 04:12:21 --> Final output sent to browser
DEBUG - 2014-01-02 04:12:21 --> Total execution time: 0.1001
DEBUG - 2014-01-02 04:27:57 --> Config Class Initialized
DEBUG - 2014-01-02 04:27:57 --> Hooks Class Initialized
DEBUG - 2014-01-02 04:27:57 --> Utf8 Class Initialized
DEBUG - 2014-01-02 04:27:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 04:27:57 --> URI Class Initialized
DEBUG - 2014-01-02 04:27:57 --> Router Class Initialized
DEBUG - 2014-01-02 04:27:57 --> Output Class Initialized
DEBUG - 2014-01-02 04:27:57 --> Security Class Initialized
DEBUG - 2014-01-02 04:27:57 --> Input Class Initialized
DEBUG - 2014-01-02 04:27:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 04:27:57 --> Language Class Initialized
DEBUG - 2014-01-02 04:27:57 --> Loader Class Initialized
DEBUG - 2014-01-02 04:27:57 --> Helper loaded: url_helper
DEBUG - 2014-01-02 04:27:57 --> Helper loaded: common_helper
DEBUG - 2014-01-02 04:27:57 --> Database Driver Class Initialized
DEBUG - 2014-01-02 04:27:57 --> Controller Class Initialized
DEBUG - 2014-01-02 04:27:57 --> Session Class Initialized
DEBUG - 2014-01-02 04:27:57 --> Helper loaded: string_helper
DEBUG - 2014-01-02 04:27:57 --> Encrypt Class Initialized
DEBUG - 2014-01-02 04:27:57 --> Session routines successfully run
DEBUG - 2014-01-02 04:27:57 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 04:27:57 --> Helper loaded: form_helper
DEBUG - 2014-01-02 04:27:57 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 04:27:57 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 04:27:58 --> lsession class already loaded. Second attempt ignored.
DEBUG - 2014-01-02 04:27:58 --> Final output sent to browser
DEBUG - 2014-01-02 04:27:58 --> Total execution time: 0.0984
DEBUG - 2014-01-02 04:28:29 --> Config Class Initialized
DEBUG - 2014-01-02 04:28:29 --> Hooks Class Initialized
DEBUG - 2014-01-02 04:28:29 --> Utf8 Class Initialized
DEBUG - 2014-01-02 04:28:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 04:28:29 --> URI Class Initialized
DEBUG - 2014-01-02 04:28:29 --> Router Class Initialized
DEBUG - 2014-01-02 04:28:29 --> Output Class Initialized
DEBUG - 2014-01-02 04:28:29 --> Security Class Initialized
DEBUG - 2014-01-02 04:28:29 --> Input Class Initialized
DEBUG - 2014-01-02 04:28:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 04:28:29 --> Language Class Initialized
DEBUG - 2014-01-02 04:28:29 --> Loader Class Initialized
DEBUG - 2014-01-02 04:28:29 --> Helper loaded: url_helper
DEBUG - 2014-01-02 04:28:29 --> Helper loaded: common_helper
DEBUG - 2014-01-02 04:28:29 --> Database Driver Class Initialized
DEBUG - 2014-01-02 04:28:29 --> Controller Class Initialized
DEBUG - 2014-01-02 04:28:29 --> Session Class Initialized
DEBUG - 2014-01-02 04:28:29 --> Helper loaded: string_helper
DEBUG - 2014-01-02 04:28:29 --> Encrypt Class Initialized
DEBUG - 2014-01-02 04:28:29 --> Session routines successfully run
DEBUG - 2014-01-02 04:28:29 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 04:28:29 --> Helper loaded: form_helper
DEBUG - 2014-01-02 04:28:29 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 04:28:29 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 04:28:29 --> lsession class already loaded. Second attempt ignored.
DEBUG - 2014-01-02 04:28:29 --> Final output sent to browser
DEBUG - 2014-01-02 04:28:29 --> Total execution time: 0.1138
DEBUG - 2014-01-02 04:28:36 --> Config Class Initialized
DEBUG - 2014-01-02 04:28:36 --> Hooks Class Initialized
DEBUG - 2014-01-02 04:28:36 --> Utf8 Class Initialized
DEBUG - 2014-01-02 04:28:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 04:28:36 --> URI Class Initialized
DEBUG - 2014-01-02 04:28:36 --> Router Class Initialized
DEBUG - 2014-01-02 04:28:36 --> Output Class Initialized
DEBUG - 2014-01-02 04:28:36 --> Security Class Initialized
DEBUG - 2014-01-02 04:28:36 --> Input Class Initialized
DEBUG - 2014-01-02 04:28:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 04:28:36 --> Language Class Initialized
DEBUG - 2014-01-02 04:28:36 --> Loader Class Initialized
DEBUG - 2014-01-02 04:28:36 --> Helper loaded: url_helper
DEBUG - 2014-01-02 04:28:36 --> Helper loaded: common_helper
DEBUG - 2014-01-02 04:28:36 --> Database Driver Class Initialized
DEBUG - 2014-01-02 04:28:36 --> Controller Class Initialized
DEBUG - 2014-01-02 04:28:36 --> Session Class Initialized
DEBUG - 2014-01-02 04:28:36 --> Helper loaded: string_helper
DEBUG - 2014-01-02 04:28:36 --> Encrypt Class Initialized
DEBUG - 2014-01-02 04:28:36 --> Session routines successfully run
DEBUG - 2014-01-02 04:28:36 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 04:28:36 --> Model Class Initialized
DEBUG - 2014-01-02 04:28:36 --> Model Class Initialized
DEBUG - 2014-01-02 04:28:36 --> Final output sent to browser
DEBUG - 2014-01-02 04:28:36 --> Total execution time: 0.0393
DEBUG - 2014-01-02 04:28:36 --> Config Class Initialized
DEBUG - 2014-01-02 04:28:36 --> Hooks Class Initialized
DEBUG - 2014-01-02 04:28:36 --> Utf8 Class Initialized
DEBUG - 2014-01-02 04:28:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 04:28:36 --> URI Class Initialized
DEBUG - 2014-01-02 04:28:36 --> Router Class Initialized
DEBUG - 2014-01-02 04:28:36 --> Output Class Initialized
DEBUG - 2014-01-02 04:28:36 --> Security Class Initialized
DEBUG - 2014-01-02 04:28:36 --> Input Class Initialized
DEBUG - 2014-01-02 04:28:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 04:28:36 --> Language Class Initialized
DEBUG - 2014-01-02 04:28:36 --> Loader Class Initialized
DEBUG - 2014-01-02 04:28:36 --> Helper loaded: url_helper
DEBUG - 2014-01-02 04:28:36 --> Helper loaded: common_helper
DEBUG - 2014-01-02 04:28:36 --> Database Driver Class Initialized
DEBUG - 2014-01-02 04:28:36 --> Controller Class Initialized
DEBUG - 2014-01-02 04:28:36 --> Session Class Initialized
DEBUG - 2014-01-02 04:28:36 --> Helper loaded: string_helper
DEBUG - 2014-01-02 04:28:36 --> Encrypt Class Initialized
DEBUG - 2014-01-02 04:28:36 --> Session routines successfully run
DEBUG - 2014-01-02 04:28:36 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 04:28:36 --> Final output sent to browser
DEBUG - 2014-01-02 04:28:36 --> Total execution time: 0.0596
DEBUG - 2014-01-02 04:28:53 --> Config Class Initialized
DEBUG - 2014-01-02 04:28:53 --> Hooks Class Initialized
DEBUG - 2014-01-02 04:28:53 --> Utf8 Class Initialized
DEBUG - 2014-01-02 04:28:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 04:28:53 --> URI Class Initialized
DEBUG - 2014-01-02 04:28:53 --> Router Class Initialized
DEBUG - 2014-01-02 04:28:53 --> Output Class Initialized
DEBUG - 2014-01-02 04:28:53 --> Security Class Initialized
DEBUG - 2014-01-02 04:28:53 --> Input Class Initialized
DEBUG - 2014-01-02 04:28:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 04:28:53 --> Language Class Initialized
DEBUG - 2014-01-02 04:28:53 --> Loader Class Initialized
DEBUG - 2014-01-02 04:28:53 --> Helper loaded: url_helper
DEBUG - 2014-01-02 04:28:53 --> Helper loaded: common_helper
DEBUG - 2014-01-02 04:28:53 --> Database Driver Class Initialized
DEBUG - 2014-01-02 04:28:53 --> Controller Class Initialized
DEBUG - 2014-01-02 04:28:53 --> Session Class Initialized
DEBUG - 2014-01-02 04:28:53 --> Helper loaded: string_helper
DEBUG - 2014-01-02 04:28:53 --> Encrypt Class Initialized
DEBUG - 2014-01-02 04:28:53 --> Session routines successfully run
DEBUG - 2014-01-02 04:28:53 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 04:28:53 --> Final output sent to browser
DEBUG - 2014-01-02 04:28:53 --> Total execution time: 0.0362
DEBUG - 2014-01-02 05:00:16 --> Config Class Initialized
DEBUG - 2014-01-02 05:00:16 --> Hooks Class Initialized
DEBUG - 2014-01-02 05:00:16 --> Utf8 Class Initialized
DEBUG - 2014-01-02 05:00:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 05:00:16 --> URI Class Initialized
DEBUG - 2014-01-02 05:00:16 --> Router Class Initialized
DEBUG - 2014-01-02 05:00:16 --> Output Class Initialized
DEBUG - 2014-01-02 05:00:16 --> Security Class Initialized
DEBUG - 2014-01-02 05:00:16 --> Input Class Initialized
DEBUG - 2014-01-02 05:00:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 05:00:16 --> Language Class Initialized
DEBUG - 2014-01-02 05:00:16 --> Loader Class Initialized
DEBUG - 2014-01-02 05:00:16 --> Helper loaded: url_helper
DEBUG - 2014-01-02 05:00:16 --> Helper loaded: common_helper
DEBUG - 2014-01-02 05:00:16 --> Database Driver Class Initialized
DEBUG - 2014-01-02 05:00:16 --> Controller Class Initialized
DEBUG - 2014-01-02 05:00:16 --> Session Class Initialized
DEBUG - 2014-01-02 05:00:16 --> Helper loaded: string_helper
DEBUG - 2014-01-02 05:00:16 --> Encrypt Class Initialized
DEBUG - 2014-01-02 05:00:16 --> A session cookie was not found.
DEBUG - 2014-01-02 05:00:16 --> Session routines successfully run
DEBUG - 2014-01-02 05:00:16 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 05:00:16 --> Helper loaded: form_helper
DEBUG - 2014-01-02 05:00:16 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 05:00:16 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 05:00:16 --> lsession class already loaded. Second attempt ignored.
DEBUG - 2014-01-02 05:00:16 --> Final output sent to browser
DEBUG - 2014-01-02 05:00:16 --> Total execution time: 0.0697
DEBUG - 2014-01-02 05:00:16 --> Config Class Initialized
DEBUG - 2014-01-02 05:00:16 --> Hooks Class Initialized
DEBUG - 2014-01-02 05:00:16 --> Utf8 Class Initialized
DEBUG - 2014-01-02 05:00:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 05:00:16 --> URI Class Initialized
DEBUG - 2014-01-02 05:00:16 --> Router Class Initialized
DEBUG - 2014-01-02 05:00:16 --> Output Class Initialized
DEBUG - 2014-01-02 05:00:16 --> Security Class Initialized
DEBUG - 2014-01-02 05:00:16 --> Input Class Initialized
DEBUG - 2014-01-02 05:00:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 05:00:16 --> Language Class Initialized
DEBUG - 2014-01-02 05:00:16 --> Loader Class Initialized
DEBUG - 2014-01-02 05:00:16 --> Helper loaded: url_helper
DEBUG - 2014-01-02 05:00:16 --> Helper loaded: common_helper
DEBUG - 2014-01-02 05:00:16 --> Database Driver Class Initialized
DEBUG - 2014-01-02 05:00:16 --> Controller Class Initialized
DEBUG - 2014-01-02 05:00:16 --> Session Class Initialized
DEBUG - 2014-01-02 05:00:16 --> Helper loaded: string_helper
DEBUG - 2014-01-02 05:00:16 --> Encrypt Class Initialized
DEBUG - 2014-01-02 05:00:16 --> Session routines successfully run
DEBUG - 2014-01-02 05:00:16 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 05:00:16 --> Final output sent to browser
DEBUG - 2014-01-02 05:00:16 --> Total execution time: 0.0422
DEBUG - 2014-01-02 05:00:28 --> Config Class Initialized
DEBUG - 2014-01-02 05:00:28 --> Hooks Class Initialized
DEBUG - 2014-01-02 05:00:28 --> Utf8 Class Initialized
DEBUG - 2014-01-02 05:00:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 05:00:28 --> URI Class Initialized
DEBUG - 2014-01-02 05:00:28 --> Router Class Initialized
DEBUG - 2014-01-02 05:00:28 --> Output Class Initialized
DEBUG - 2014-01-02 05:00:28 --> Security Class Initialized
DEBUG - 2014-01-02 05:00:28 --> Input Class Initialized
DEBUG - 2014-01-02 05:00:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 05:00:28 --> Language Class Initialized
DEBUG - 2014-01-02 05:00:28 --> Loader Class Initialized
DEBUG - 2014-01-02 05:00:28 --> Helper loaded: url_helper
DEBUG - 2014-01-02 05:00:28 --> Helper loaded: common_helper
DEBUG - 2014-01-02 05:00:28 --> Database Driver Class Initialized
DEBUG - 2014-01-02 05:00:28 --> Controller Class Initialized
DEBUG - 2014-01-02 05:00:28 --> Session Class Initialized
DEBUG - 2014-01-02 05:00:28 --> Helper loaded: string_helper
DEBUG - 2014-01-02 05:00:28 --> Encrypt Class Initialized
DEBUG - 2014-01-02 05:00:28 --> Session routines successfully run
DEBUG - 2014-01-02 05:00:28 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 05:00:28 --> Model Class Initialized
DEBUG - 2014-01-02 05:00:28 --> Model Class Initialized
DEBUG - 2014-01-02 05:00:28 --> Final output sent to browser
DEBUG - 2014-01-02 05:00:28 --> Total execution time: 0.0449
DEBUG - 2014-01-02 05:00:28 --> Config Class Initialized
DEBUG - 2014-01-02 05:00:28 --> Hooks Class Initialized
DEBUG - 2014-01-02 05:00:28 --> Utf8 Class Initialized
DEBUG - 2014-01-02 05:00:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 05:00:28 --> URI Class Initialized
DEBUG - 2014-01-02 05:00:28 --> Router Class Initialized
DEBUG - 2014-01-02 05:00:28 --> Output Class Initialized
DEBUG - 2014-01-02 05:00:28 --> Security Class Initialized
DEBUG - 2014-01-02 05:00:28 --> Input Class Initialized
DEBUG - 2014-01-02 05:00:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 05:00:28 --> Language Class Initialized
DEBUG - 2014-01-02 05:00:28 --> Loader Class Initialized
DEBUG - 2014-01-02 05:00:28 --> Helper loaded: url_helper
DEBUG - 2014-01-02 05:00:28 --> Helper loaded: common_helper
DEBUG - 2014-01-02 05:00:28 --> Database Driver Class Initialized
DEBUG - 2014-01-02 05:00:28 --> Controller Class Initialized
DEBUG - 2014-01-02 05:00:28 --> Session Class Initialized
DEBUG - 2014-01-02 05:00:28 --> Helper loaded: string_helper
DEBUG - 2014-01-02 05:00:28 --> Encrypt Class Initialized
DEBUG - 2014-01-02 05:00:28 --> Session routines successfully run
DEBUG - 2014-01-02 05:00:28 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 05:00:28 --> Final output sent to browser
DEBUG - 2014-01-02 05:00:28 --> Total execution time: 0.0453
DEBUG - 2014-01-02 05:17:01 --> Config Class Initialized
DEBUG - 2014-01-02 05:17:01 --> Hooks Class Initialized
DEBUG - 2014-01-02 05:17:01 --> Utf8 Class Initialized
DEBUG - 2014-01-02 05:17:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 05:17:01 --> URI Class Initialized
DEBUG - 2014-01-02 05:17:01 --> Router Class Initialized
DEBUG - 2014-01-02 05:17:01 --> Output Class Initialized
DEBUG - 2014-01-02 05:17:01 --> Security Class Initialized
DEBUG - 2014-01-02 05:17:01 --> Input Class Initialized
DEBUG - 2014-01-02 05:17:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 05:17:01 --> Language Class Initialized
DEBUG - 2014-01-02 05:17:01 --> Loader Class Initialized
DEBUG - 2014-01-02 05:17:01 --> Helper loaded: url_helper
DEBUG - 2014-01-02 05:17:01 --> Helper loaded: common_helper
DEBUG - 2014-01-02 05:17:01 --> Database Driver Class Initialized
DEBUG - 2014-01-02 05:17:01 --> Controller Class Initialized
DEBUG - 2014-01-02 05:17:01 --> Session Class Initialized
DEBUG - 2014-01-02 05:17:01 --> Helper loaded: string_helper
DEBUG - 2014-01-02 05:17:01 --> Encrypt Class Initialized
DEBUG - 2014-01-02 05:17:01 --> Session routines successfully run
DEBUG - 2014-01-02 05:17:01 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 05:17:01 --> Helper loaded: form_helper
DEBUG - 2014-01-02 05:17:01 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 05:17:01 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 05:17:01 --> lsession class already loaded. Second attempt ignored.
DEBUG - 2014-01-02 05:17:01 --> Final output sent to browser
DEBUG - 2014-01-02 05:17:01 --> Total execution time: 0.0760
DEBUG - 2014-01-02 05:17:01 --> Config Class Initialized
DEBUG - 2014-01-02 05:17:01 --> Hooks Class Initialized
DEBUG - 2014-01-02 05:17:01 --> Utf8 Class Initialized
DEBUG - 2014-01-02 05:17:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 05:17:01 --> URI Class Initialized
DEBUG - 2014-01-02 05:17:01 --> Router Class Initialized
DEBUG - 2014-01-02 05:17:01 --> Output Class Initialized
DEBUG - 2014-01-02 05:17:01 --> Security Class Initialized
DEBUG - 2014-01-02 05:17:01 --> Input Class Initialized
DEBUG - 2014-01-02 05:17:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 05:17:01 --> Language Class Initialized
DEBUG - 2014-01-02 05:17:01 --> Loader Class Initialized
DEBUG - 2014-01-02 05:17:01 --> Helper loaded: url_helper
DEBUG - 2014-01-02 05:17:01 --> Helper loaded: common_helper
DEBUG - 2014-01-02 05:17:02 --> Database Driver Class Initialized
DEBUG - 2014-01-02 05:17:02 --> Controller Class Initialized
DEBUG - 2014-01-02 05:17:02 --> Session Class Initialized
DEBUG - 2014-01-02 05:17:02 --> Helper loaded: string_helper
DEBUG - 2014-01-02 05:17:02 --> Encrypt Class Initialized
DEBUG - 2014-01-02 05:17:02 --> Session routines successfully run
DEBUG - 2014-01-02 05:17:02 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 05:17:02 --> Final output sent to browser
DEBUG - 2014-01-02 05:17:02 --> Total execution time: 0.0317
DEBUG - 2014-01-02 05:17:17 --> Config Class Initialized
DEBUG - 2014-01-02 05:17:17 --> Hooks Class Initialized
DEBUG - 2014-01-02 05:17:17 --> Utf8 Class Initialized
DEBUG - 2014-01-02 05:17:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 05:17:17 --> URI Class Initialized
DEBUG - 2014-01-02 05:17:17 --> Router Class Initialized
DEBUG - 2014-01-02 05:17:17 --> Output Class Initialized
DEBUG - 2014-01-02 05:17:17 --> Security Class Initialized
DEBUG - 2014-01-02 05:17:17 --> Input Class Initialized
DEBUG - 2014-01-02 05:17:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 05:17:17 --> Language Class Initialized
DEBUG - 2014-01-02 05:17:17 --> Loader Class Initialized
DEBUG - 2014-01-02 05:17:17 --> Helper loaded: url_helper
DEBUG - 2014-01-02 05:17:17 --> Helper loaded: common_helper
DEBUG - 2014-01-02 05:17:17 --> Database Driver Class Initialized
DEBUG - 2014-01-02 05:17:17 --> Controller Class Initialized
DEBUG - 2014-01-02 05:17:17 --> Session Class Initialized
DEBUG - 2014-01-02 05:17:17 --> Helper loaded: string_helper
DEBUG - 2014-01-02 05:17:17 --> Encrypt Class Initialized
DEBUG - 2014-01-02 05:17:17 --> Session routines successfully run
DEBUG - 2014-01-02 05:17:17 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 05:17:58 --> Config Class Initialized
DEBUG - 2014-01-02 05:17:58 --> Hooks Class Initialized
DEBUG - 2014-01-02 05:17:58 --> Utf8 Class Initialized
DEBUG - 2014-01-02 05:17:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 05:17:58 --> URI Class Initialized
DEBUG - 2014-01-02 05:17:58 --> Router Class Initialized
DEBUG - 2014-01-02 05:17:58 --> Output Class Initialized
DEBUG - 2014-01-02 05:17:58 --> Security Class Initialized
DEBUG - 2014-01-02 05:17:58 --> Input Class Initialized
DEBUG - 2014-01-02 05:17:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 05:17:58 --> Language Class Initialized
DEBUG - 2014-01-02 05:17:58 --> Loader Class Initialized
DEBUG - 2014-01-02 05:17:58 --> Helper loaded: url_helper
DEBUG - 2014-01-02 05:17:58 --> Helper loaded: common_helper
DEBUG - 2014-01-02 05:17:58 --> Database Driver Class Initialized
DEBUG - 2014-01-02 05:17:58 --> Controller Class Initialized
DEBUG - 2014-01-02 05:17:58 --> Session Class Initialized
DEBUG - 2014-01-02 05:17:58 --> Helper loaded: string_helper
DEBUG - 2014-01-02 05:17:58 --> Encrypt Class Initialized
DEBUG - 2014-01-02 05:17:58 --> Session routines successfully run
DEBUG - 2014-01-02 05:17:58 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 05:17:58 --> Final output sent to browser
DEBUG - 2014-01-02 05:17:58 --> Total execution time: 0.0473
DEBUG - 2014-01-02 05:18:01 --> Config Class Initialized
DEBUG - 2014-01-02 05:18:01 --> Hooks Class Initialized
DEBUG - 2014-01-02 05:18:01 --> Utf8 Class Initialized
DEBUG - 2014-01-02 05:18:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 05:18:01 --> URI Class Initialized
DEBUG - 2014-01-02 05:18:01 --> Router Class Initialized
DEBUG - 2014-01-02 05:18:01 --> Output Class Initialized
DEBUG - 2014-01-02 05:18:01 --> Security Class Initialized
DEBUG - 2014-01-02 05:18:01 --> Input Class Initialized
DEBUG - 2014-01-02 05:18:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 05:18:01 --> Language Class Initialized
DEBUG - 2014-01-02 05:18:01 --> Loader Class Initialized
DEBUG - 2014-01-02 05:18:01 --> Helper loaded: url_helper
DEBUG - 2014-01-02 05:18:01 --> Helper loaded: common_helper
DEBUG - 2014-01-02 05:18:01 --> Database Driver Class Initialized
DEBUG - 2014-01-02 05:18:01 --> Controller Class Initialized
DEBUG - 2014-01-02 05:18:01 --> Session Class Initialized
DEBUG - 2014-01-02 05:18:01 --> Helper loaded: string_helper
DEBUG - 2014-01-02 05:18:01 --> Encrypt Class Initialized
DEBUG - 2014-01-02 05:18:01 --> Session routines successfully run
DEBUG - 2014-01-02 05:18:01 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 05:18:01 --> Model Class Initialized
DEBUG - 2014-01-02 05:18:01 --> Model Class Initialized
DEBUG - 2014-01-02 05:18:01 --> Final output sent to browser
DEBUG - 2014-01-02 05:18:01 --> Total execution time: 0.0454
DEBUG - 2014-01-02 05:18:01 --> Config Class Initialized
DEBUG - 2014-01-02 05:18:01 --> Hooks Class Initialized
DEBUG - 2014-01-02 05:18:01 --> Utf8 Class Initialized
DEBUG - 2014-01-02 05:18:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 05:18:01 --> URI Class Initialized
DEBUG - 2014-01-02 05:18:01 --> Router Class Initialized
DEBUG - 2014-01-02 05:18:01 --> Output Class Initialized
DEBUG - 2014-01-02 05:18:01 --> Security Class Initialized
DEBUG - 2014-01-02 05:18:01 --> Input Class Initialized
DEBUG - 2014-01-02 05:18:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 05:18:01 --> Language Class Initialized
DEBUG - 2014-01-02 05:18:02 --> Loader Class Initialized
DEBUG - 2014-01-02 05:18:02 --> Helper loaded: url_helper
DEBUG - 2014-01-02 05:18:02 --> Helper loaded: common_helper
DEBUG - 2014-01-02 05:18:02 --> Database Driver Class Initialized
DEBUG - 2014-01-02 05:18:02 --> Controller Class Initialized
DEBUG - 2014-01-02 05:18:02 --> Session Class Initialized
DEBUG - 2014-01-02 05:18:02 --> Helper loaded: string_helper
DEBUG - 2014-01-02 05:18:02 --> Encrypt Class Initialized
DEBUG - 2014-01-02 05:18:02 --> Session routines successfully run
DEBUG - 2014-01-02 05:18:02 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 05:18:02 --> Final output sent to browser
DEBUG - 2014-01-02 05:18:02 --> Total execution time: 0.0366
DEBUG - 2014-01-02 05:18:41 --> Config Class Initialized
DEBUG - 2014-01-02 05:18:41 --> Hooks Class Initialized
DEBUG - 2014-01-02 05:18:41 --> Utf8 Class Initialized
DEBUG - 2014-01-02 05:18:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 05:18:41 --> URI Class Initialized
DEBUG - 2014-01-02 05:18:41 --> Router Class Initialized
DEBUG - 2014-01-02 05:18:41 --> Output Class Initialized
DEBUG - 2014-01-02 05:18:41 --> Security Class Initialized
DEBUG - 2014-01-02 05:18:41 --> Input Class Initialized
DEBUG - 2014-01-02 05:18:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 05:18:41 --> Language Class Initialized
DEBUG - 2014-01-02 05:18:41 --> Loader Class Initialized
DEBUG - 2014-01-02 05:18:41 --> Helper loaded: url_helper
DEBUG - 2014-01-02 05:18:41 --> Helper loaded: common_helper
DEBUG - 2014-01-02 05:18:41 --> Database Driver Class Initialized
DEBUG - 2014-01-02 05:18:41 --> Controller Class Initialized
DEBUG - 2014-01-02 05:18:41 --> Session Class Initialized
DEBUG - 2014-01-02 05:18:41 --> Helper loaded: string_helper
DEBUG - 2014-01-02 05:18:41 --> Encrypt Class Initialized
DEBUG - 2014-01-02 05:18:41 --> Session routines successfully run
DEBUG - 2014-01-02 05:18:41 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 05:18:41 --> Model Class Initialized
DEBUG - 2014-01-02 05:18:41 --> Model Class Initialized
ERROR - 2014-01-02 05:18:41 --> Severity: Notice  --> Undefined property: stdClass::$id /var/www/mustang/application/models/muser.php 32
DEBUG - 2014-01-02 05:18:41 --> DB Transaction Failure
ERROR - 2014-01-02 05:18:41 --> Query error: Table 'crebas.##user' doesn't exist
DEBUG - 2014-01-02 05:18:41 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-02 05:18:44 --> Config Class Initialized
DEBUG - 2014-01-02 05:18:44 --> Hooks Class Initialized
DEBUG - 2014-01-02 05:18:44 --> Utf8 Class Initialized
DEBUG - 2014-01-02 05:18:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 05:18:44 --> URI Class Initialized
DEBUG - 2014-01-02 05:18:44 --> Router Class Initialized
DEBUG - 2014-01-02 05:18:44 --> Output Class Initialized
DEBUG - 2014-01-02 05:18:44 --> Security Class Initialized
DEBUG - 2014-01-02 05:18:44 --> Input Class Initialized
DEBUG - 2014-01-02 05:18:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 05:18:44 --> Language Class Initialized
DEBUG - 2014-01-02 05:18:44 --> Loader Class Initialized
DEBUG - 2014-01-02 05:18:44 --> Helper loaded: url_helper
DEBUG - 2014-01-02 05:18:44 --> Helper loaded: common_helper
DEBUG - 2014-01-02 05:18:44 --> Database Driver Class Initialized
DEBUG - 2014-01-02 05:18:44 --> Controller Class Initialized
DEBUG - 2014-01-02 05:18:44 --> Session Class Initialized
DEBUG - 2014-01-02 05:18:44 --> Helper loaded: string_helper
DEBUG - 2014-01-02 05:18:44 --> Encrypt Class Initialized
DEBUG - 2014-01-02 05:18:44 --> Session routines successfully run
DEBUG - 2014-01-02 05:18:44 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 05:18:44 --> Model Class Initialized
DEBUG - 2014-01-02 05:18:44 --> Model Class Initialized
ERROR - 2014-01-02 05:18:44 --> Severity: Notice  --> Undefined property: stdClass::$id /var/www/mustang/application/models/muser.php 32
DEBUG - 2014-01-02 05:18:44 --> DB Transaction Failure
ERROR - 2014-01-02 05:18:44 --> Query error: Table 'crebas.##user' doesn't exist
DEBUG - 2014-01-02 05:18:44 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-02 05:19:45 --> Config Class Initialized
DEBUG - 2014-01-02 05:19:45 --> Hooks Class Initialized
DEBUG - 2014-01-02 05:19:45 --> Utf8 Class Initialized
DEBUG - 2014-01-02 05:19:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 05:19:45 --> URI Class Initialized
DEBUG - 2014-01-02 05:19:45 --> Router Class Initialized
DEBUG - 2014-01-02 05:19:45 --> Output Class Initialized
DEBUG - 2014-01-02 05:19:45 --> Security Class Initialized
DEBUG - 2014-01-02 05:19:45 --> Input Class Initialized
DEBUG - 2014-01-02 05:19:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 05:19:45 --> Language Class Initialized
DEBUG - 2014-01-02 05:19:45 --> Loader Class Initialized
DEBUG - 2014-01-02 05:19:45 --> Helper loaded: url_helper
DEBUG - 2014-01-02 05:19:45 --> Helper loaded: common_helper
DEBUG - 2014-01-02 05:19:45 --> Database Driver Class Initialized
DEBUG - 2014-01-02 05:19:45 --> Controller Class Initialized
DEBUG - 2014-01-02 05:19:45 --> Session Class Initialized
DEBUG - 2014-01-02 05:19:45 --> Helper loaded: string_helper
DEBUG - 2014-01-02 05:19:45 --> Encrypt Class Initialized
DEBUG - 2014-01-02 05:19:45 --> Session routines successfully run
DEBUG - 2014-01-02 05:19:45 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 05:19:45 --> Model Class Initialized
DEBUG - 2014-01-02 05:19:45 --> Model Class Initialized
DEBUG - 2014-01-02 05:19:45 --> DB Transaction Failure
ERROR - 2014-01-02 05:19:45 --> Query error: Table 'crebas.##user' doesn't exist
DEBUG - 2014-01-02 05:19:45 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-02 05:24:34 --> Config Class Initialized
DEBUG - 2014-01-02 05:24:34 --> Hooks Class Initialized
DEBUG - 2014-01-02 05:24:34 --> Utf8 Class Initialized
DEBUG - 2014-01-02 05:24:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 05:24:34 --> URI Class Initialized
DEBUG - 2014-01-02 05:24:34 --> Router Class Initialized
DEBUG - 2014-01-02 05:24:34 --> Output Class Initialized
DEBUG - 2014-01-02 05:24:34 --> Security Class Initialized
DEBUG - 2014-01-02 05:24:34 --> Input Class Initialized
DEBUG - 2014-01-02 05:24:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 05:24:34 --> Language Class Initialized
DEBUG - 2014-01-02 05:24:34 --> Loader Class Initialized
DEBUG - 2014-01-02 05:24:34 --> Helper loaded: url_helper
DEBUG - 2014-01-02 05:24:34 --> Helper loaded: common_helper
DEBUG - 2014-01-02 05:24:34 --> Database Driver Class Initialized
DEBUG - 2014-01-02 05:24:34 --> Controller Class Initialized
DEBUG - 2014-01-02 05:24:34 --> Session Class Initialized
DEBUG - 2014-01-02 05:24:34 --> Helper loaded: string_helper
DEBUG - 2014-01-02 05:24:34 --> Encrypt Class Initialized
DEBUG - 2014-01-02 05:24:34 --> Session routines successfully run
DEBUG - 2014-01-02 05:24:34 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 05:24:34 --> Model Class Initialized
DEBUG - 2014-01-02 05:24:34 --> Model Class Initialized
ERROR - 2014-01-02 05:24:34 --> Severity: Notice  --> Trying to get property of non-object /var/www/mustang/application/models/muser.php 111
DEBUG - 2014-01-02 05:24:34 --> DB Transaction Failure
ERROR - 2014-01-02 05:24:34 --> Query error: Unknown column 'id' in 'where clause'
DEBUG - 2014-01-02 05:24:34 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-02 05:25:41 --> Config Class Initialized
DEBUG - 2014-01-02 05:25:41 --> Hooks Class Initialized
DEBUG - 2014-01-02 05:25:41 --> Utf8 Class Initialized
DEBUG - 2014-01-02 05:25:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 05:25:41 --> URI Class Initialized
DEBUG - 2014-01-02 05:25:41 --> Router Class Initialized
DEBUG - 2014-01-02 05:25:41 --> Output Class Initialized
DEBUG - 2014-01-02 05:25:41 --> Security Class Initialized
DEBUG - 2014-01-02 05:25:41 --> Input Class Initialized
DEBUG - 2014-01-02 05:25:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 05:25:41 --> Language Class Initialized
DEBUG - 2014-01-02 05:25:41 --> Loader Class Initialized
DEBUG - 2014-01-02 05:25:41 --> Helper loaded: url_helper
DEBUG - 2014-01-02 05:25:41 --> Helper loaded: common_helper
DEBUG - 2014-01-02 05:25:41 --> Database Driver Class Initialized
DEBUG - 2014-01-02 05:25:41 --> Controller Class Initialized
DEBUG - 2014-01-02 05:25:41 --> Session Class Initialized
DEBUG - 2014-01-02 05:25:41 --> Helper loaded: string_helper
DEBUG - 2014-01-02 05:25:41 --> Encrypt Class Initialized
DEBUG - 2014-01-02 05:25:41 --> Session routines successfully run
DEBUG - 2014-01-02 05:25:41 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 05:25:41 --> Helper loaded: form_helper
DEBUG - 2014-01-02 05:25:41 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 05:25:41 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 05:25:41 --> lsession class already loaded. Second attempt ignored.
DEBUG - 2014-01-02 05:25:41 --> Final output sent to browser
DEBUG - 2014-01-02 05:25:41 --> Total execution time: 0.0696
DEBUG - 2014-01-02 05:25:41 --> Config Class Initialized
DEBUG - 2014-01-02 05:25:41 --> Hooks Class Initialized
DEBUG - 2014-01-02 05:25:41 --> Utf8 Class Initialized
DEBUG - 2014-01-02 05:25:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 05:25:41 --> URI Class Initialized
DEBUG - 2014-01-02 05:25:41 --> Router Class Initialized
DEBUG - 2014-01-02 05:25:41 --> Output Class Initialized
DEBUG - 2014-01-02 05:25:41 --> Security Class Initialized
DEBUG - 2014-01-02 05:25:41 --> Input Class Initialized
DEBUG - 2014-01-02 05:25:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 05:25:41 --> Language Class Initialized
DEBUG - 2014-01-02 05:25:41 --> Loader Class Initialized
DEBUG - 2014-01-02 05:25:41 --> Helper loaded: url_helper
DEBUG - 2014-01-02 05:25:41 --> Helper loaded: common_helper
DEBUG - 2014-01-02 05:25:41 --> Database Driver Class Initialized
DEBUG - 2014-01-02 05:25:41 --> Controller Class Initialized
DEBUG - 2014-01-02 05:25:41 --> Session Class Initialized
DEBUG - 2014-01-02 05:25:41 --> Helper loaded: string_helper
DEBUG - 2014-01-02 05:25:41 --> Encrypt Class Initialized
DEBUG - 2014-01-02 05:25:41 --> Session routines successfully run
DEBUG - 2014-01-02 05:25:41 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 05:25:41 --> Final output sent to browser
DEBUG - 2014-01-02 05:25:41 --> Total execution time: 0.0465
DEBUG - 2014-01-02 05:25:48 --> Config Class Initialized
DEBUG - 2014-01-02 05:25:48 --> Hooks Class Initialized
DEBUG - 2014-01-02 05:25:48 --> Utf8 Class Initialized
DEBUG - 2014-01-02 05:25:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 05:25:48 --> URI Class Initialized
DEBUG - 2014-01-02 05:25:48 --> Router Class Initialized
DEBUG - 2014-01-02 05:25:48 --> Output Class Initialized
DEBUG - 2014-01-02 05:25:48 --> Security Class Initialized
DEBUG - 2014-01-02 05:25:48 --> Input Class Initialized
DEBUG - 2014-01-02 05:25:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 05:25:48 --> Language Class Initialized
DEBUG - 2014-01-02 05:25:48 --> Loader Class Initialized
DEBUG - 2014-01-02 05:25:48 --> Helper loaded: url_helper
DEBUG - 2014-01-02 05:25:48 --> Helper loaded: common_helper
DEBUG - 2014-01-02 05:25:48 --> Database Driver Class Initialized
DEBUG - 2014-01-02 05:25:48 --> Controller Class Initialized
DEBUG - 2014-01-02 05:25:48 --> Session Class Initialized
DEBUG - 2014-01-02 05:25:48 --> Helper loaded: string_helper
DEBUG - 2014-01-02 05:25:48 --> Encrypt Class Initialized
DEBUG - 2014-01-02 05:25:48 --> Session routines successfully run
DEBUG - 2014-01-02 05:25:48 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 05:25:48 --> Final output sent to browser
DEBUG - 2014-01-02 05:25:48 --> Total execution time: 0.0405
DEBUG - 2014-01-02 05:25:48 --> Config Class Initialized
DEBUG - 2014-01-02 05:25:48 --> Hooks Class Initialized
DEBUG - 2014-01-02 05:25:48 --> Utf8 Class Initialized
DEBUG - 2014-01-02 05:25:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 05:25:48 --> URI Class Initialized
DEBUG - 2014-01-02 05:25:48 --> Router Class Initialized
DEBUG - 2014-01-02 05:25:48 --> Output Class Initialized
DEBUG - 2014-01-02 05:25:48 --> Security Class Initialized
DEBUG - 2014-01-02 05:25:48 --> Input Class Initialized
DEBUG - 2014-01-02 05:25:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 05:25:48 --> Language Class Initialized
DEBUG - 2014-01-02 05:25:48 --> Loader Class Initialized
DEBUG - 2014-01-02 05:25:48 --> Helper loaded: url_helper
DEBUG - 2014-01-02 05:25:48 --> Helper loaded: common_helper
DEBUG - 2014-01-02 05:25:48 --> Database Driver Class Initialized
DEBUG - 2014-01-02 05:25:48 --> Controller Class Initialized
DEBUG - 2014-01-02 05:25:48 --> Session Class Initialized
DEBUG - 2014-01-02 05:25:48 --> Helper loaded: string_helper
DEBUG - 2014-01-02 05:25:48 --> Encrypt Class Initialized
DEBUG - 2014-01-02 05:25:48 --> Session routines successfully run
DEBUG - 2014-01-02 05:25:48 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 05:25:48 --> Final output sent to browser
DEBUG - 2014-01-02 05:25:48 --> Total execution time: 0.0399
DEBUG - 2014-01-02 05:25:56 --> Config Class Initialized
DEBUG - 2014-01-02 05:25:56 --> Hooks Class Initialized
DEBUG - 2014-01-02 05:25:56 --> Utf8 Class Initialized
DEBUG - 2014-01-02 05:25:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 05:25:56 --> URI Class Initialized
DEBUG - 2014-01-02 05:25:56 --> Router Class Initialized
DEBUG - 2014-01-02 05:25:56 --> Output Class Initialized
DEBUG - 2014-01-02 05:25:56 --> Security Class Initialized
DEBUG - 2014-01-02 05:25:56 --> Input Class Initialized
DEBUG - 2014-01-02 05:25:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 05:25:56 --> Language Class Initialized
DEBUG - 2014-01-02 05:25:56 --> Loader Class Initialized
DEBUG - 2014-01-02 05:25:56 --> Helper loaded: url_helper
DEBUG - 2014-01-02 05:25:56 --> Helper loaded: common_helper
DEBUG - 2014-01-02 05:25:56 --> Database Driver Class Initialized
DEBUG - 2014-01-02 05:25:56 --> Controller Class Initialized
DEBUG - 2014-01-02 05:25:56 --> Session Class Initialized
DEBUG - 2014-01-02 05:25:56 --> Helper loaded: string_helper
DEBUG - 2014-01-02 05:25:56 --> Encrypt Class Initialized
DEBUG - 2014-01-02 05:25:56 --> Session routines successfully run
DEBUG - 2014-01-02 05:25:56 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 05:25:56 --> Final output sent to browser
DEBUG - 2014-01-02 05:25:56 --> Total execution time: 0.0382
DEBUG - 2014-01-02 05:25:56 --> Config Class Initialized
DEBUG - 2014-01-02 05:25:56 --> Hooks Class Initialized
DEBUG - 2014-01-02 05:25:56 --> Utf8 Class Initialized
DEBUG - 2014-01-02 05:25:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 05:25:56 --> URI Class Initialized
DEBUG - 2014-01-02 05:25:56 --> Router Class Initialized
DEBUG - 2014-01-02 05:25:56 --> Output Class Initialized
DEBUG - 2014-01-02 05:25:56 --> Security Class Initialized
DEBUG - 2014-01-02 05:25:56 --> Input Class Initialized
DEBUG - 2014-01-02 05:25:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 05:25:56 --> Language Class Initialized
DEBUG - 2014-01-02 05:25:56 --> Loader Class Initialized
DEBUG - 2014-01-02 05:25:56 --> Helper loaded: url_helper
DEBUG - 2014-01-02 05:25:56 --> Helper loaded: common_helper
DEBUG - 2014-01-02 05:25:56 --> Database Driver Class Initialized
DEBUG - 2014-01-02 05:25:56 --> Controller Class Initialized
DEBUG - 2014-01-02 05:25:56 --> Session Class Initialized
DEBUG - 2014-01-02 05:25:56 --> Helper loaded: string_helper
DEBUG - 2014-01-02 05:25:56 --> Encrypt Class Initialized
DEBUG - 2014-01-02 05:25:56 --> Session routines successfully run
DEBUG - 2014-01-02 05:25:56 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 05:25:56 --> Final output sent to browser
DEBUG - 2014-01-02 05:25:56 --> Total execution time: 0.0403
DEBUG - 2014-01-02 05:26:06 --> Config Class Initialized
DEBUG - 2014-01-02 05:26:06 --> Hooks Class Initialized
DEBUG - 2014-01-02 05:26:06 --> Utf8 Class Initialized
DEBUG - 2014-01-02 05:26:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 05:26:06 --> URI Class Initialized
DEBUG - 2014-01-02 05:26:06 --> Router Class Initialized
DEBUG - 2014-01-02 05:26:06 --> Output Class Initialized
DEBUG - 2014-01-02 05:26:06 --> Security Class Initialized
DEBUG - 2014-01-02 05:26:06 --> Input Class Initialized
DEBUG - 2014-01-02 05:26:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 05:26:06 --> Language Class Initialized
DEBUG - 2014-01-02 05:26:06 --> Loader Class Initialized
DEBUG - 2014-01-02 05:26:06 --> Helper loaded: url_helper
DEBUG - 2014-01-02 05:26:06 --> Helper loaded: common_helper
DEBUG - 2014-01-02 05:26:06 --> Database Driver Class Initialized
DEBUG - 2014-01-02 05:26:06 --> Controller Class Initialized
DEBUG - 2014-01-02 05:26:06 --> Session Class Initialized
DEBUG - 2014-01-02 05:26:06 --> Helper loaded: string_helper
DEBUG - 2014-01-02 05:26:06 --> Encrypt Class Initialized
DEBUG - 2014-01-02 05:26:06 --> Session routines successfully run
DEBUG - 2014-01-02 05:26:06 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 05:26:06 --> Model Class Initialized
DEBUG - 2014-01-02 05:26:06 --> Model Class Initialized
DEBUG - 2014-01-02 05:26:06 --> DB Transaction Failure
ERROR - 2014-01-02 05:26:06 --> Query error: Unknown column 'id' in 'where clause'
DEBUG - 2014-01-02 05:26:06 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-02 05:26:50 --> Config Class Initialized
DEBUG - 2014-01-02 05:26:50 --> Hooks Class Initialized
DEBUG - 2014-01-02 05:26:50 --> Utf8 Class Initialized
DEBUG - 2014-01-02 05:26:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 05:26:50 --> URI Class Initialized
DEBUG - 2014-01-02 05:26:50 --> Router Class Initialized
DEBUG - 2014-01-02 05:26:50 --> Output Class Initialized
DEBUG - 2014-01-02 05:26:50 --> Security Class Initialized
DEBUG - 2014-01-02 05:26:50 --> Input Class Initialized
DEBUG - 2014-01-02 05:26:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 05:26:50 --> Language Class Initialized
DEBUG - 2014-01-02 05:26:50 --> Loader Class Initialized
DEBUG - 2014-01-02 05:26:50 --> Helper loaded: url_helper
DEBUG - 2014-01-02 05:26:50 --> Helper loaded: common_helper
DEBUG - 2014-01-02 05:26:51 --> Database Driver Class Initialized
DEBUG - 2014-01-02 05:26:51 --> Controller Class Initialized
DEBUG - 2014-01-02 05:26:51 --> Session Class Initialized
DEBUG - 2014-01-02 05:26:51 --> Helper loaded: string_helper
DEBUG - 2014-01-02 05:26:51 --> Encrypt Class Initialized
DEBUG - 2014-01-02 05:26:51 --> Session routines successfully run
DEBUG - 2014-01-02 05:26:51 --> Config file loaded: application/config/acl.php
ERROR - 2014-01-02 05:26:51 --> Severity: Notice  --> Undefined property: stdClass::$role /var/www/mustang/application/hooks/acl.php 37
ERROR - 2014-01-02 05:26:51 --> 404 Page Not Found --> 错误的用户类型，该错误已经被记录！点击<a href="http://localhost:2066/index.php/login">返回</a>
DEBUG - 2014-01-02 10:01:22 --> Config Class Initialized
DEBUG - 2014-01-02 10:01:22 --> Hooks Class Initialized
DEBUG - 2014-01-02 10:01:22 --> Utf8 Class Initialized
DEBUG - 2014-01-02 10:01:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 10:01:22 --> URI Class Initialized
DEBUG - 2014-01-02 10:01:22 --> Router Class Initialized
DEBUG - 2014-01-02 10:01:22 --> No URI present. Default controller set.
DEBUG - 2014-01-02 10:01:22 --> Output Class Initialized
DEBUG - 2014-01-02 10:01:22 --> Security Class Initialized
DEBUG - 2014-01-02 10:01:22 --> Input Class Initialized
DEBUG - 2014-01-02 10:01:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 10:01:22 --> Language Class Initialized
DEBUG - 2014-01-02 10:01:22 --> Loader Class Initialized
DEBUG - 2014-01-02 10:01:22 --> Helper loaded: url_helper
DEBUG - 2014-01-02 10:01:22 --> Helper loaded: common_helper
DEBUG - 2014-01-02 10:01:22 --> Database Driver Class Initialized
DEBUG - 2014-01-02 10:01:22 --> Controller Class Initialized
DEBUG - 2014-01-02 10:01:22 --> Session Class Initialized
DEBUG - 2014-01-02 10:01:22 --> Helper loaded: string_helper
DEBUG - 2014-01-02 10:01:22 --> Encrypt Class Initialized
DEBUG - 2014-01-02 10:01:22 --> Session routines successfully run
DEBUG - 2014-01-02 10:01:22 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 10:01:22 --> Helper loaded: form_helper
DEBUG - 2014-01-02 10:01:22 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 10:01:22 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 10:01:22 --> Model Class Initialized
DEBUG - 2014-01-02 10:01:22 --> Model Class Initialized
DEBUG - 2014-01-02 10:01:22 --> DB Transaction Failure
ERROR - 2014-01-02 10:01:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'UNION
            -- Presale, Wait for auction
            (SELECT id, model, fa' at line 4
DEBUG - 2014-01-02 10:01:22 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-02 10:01:37 --> Config Class Initialized
DEBUG - 2014-01-02 10:01:37 --> Hooks Class Initialized
DEBUG - 2014-01-02 10:01:37 --> Utf8 Class Initialized
DEBUG - 2014-01-02 10:01:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 10:01:37 --> URI Class Initialized
DEBUG - 2014-01-02 10:01:37 --> Router Class Initialized
DEBUG - 2014-01-02 10:01:37 --> Output Class Initialized
DEBUG - 2014-01-02 10:01:37 --> Security Class Initialized
DEBUG - 2014-01-02 10:01:37 --> Input Class Initialized
DEBUG - 2014-01-02 10:01:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 10:01:37 --> Language Class Initialized
DEBUG - 2014-01-02 10:01:37 --> Loader Class Initialized
DEBUG - 2014-01-02 10:01:37 --> Helper loaded: url_helper
DEBUG - 2014-01-02 10:01:37 --> Helper loaded: common_helper
DEBUG - 2014-01-02 10:01:37 --> Database Driver Class Initialized
DEBUG - 2014-01-02 10:01:37 --> Controller Class Initialized
DEBUG - 2014-01-02 10:01:37 --> Session Class Initialized
DEBUG - 2014-01-02 10:01:37 --> Helper loaded: string_helper
DEBUG - 2014-01-02 10:01:37 --> Encrypt Class Initialized
DEBUG - 2014-01-02 10:01:37 --> Session routines successfully run
DEBUG - 2014-01-02 10:01:37 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 10:01:37 --> Final output sent to browser
DEBUG - 2014-01-02 10:01:37 --> Total execution time: 0.0337
DEBUG - 2014-01-02 10:01:46 --> Config Class Initialized
DEBUG - 2014-01-02 10:01:46 --> Hooks Class Initialized
DEBUG - 2014-01-02 10:01:46 --> Utf8 Class Initialized
DEBUG - 2014-01-02 10:01:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 10:01:46 --> URI Class Initialized
DEBUG - 2014-01-02 10:01:46 --> Router Class Initialized
DEBUG - 2014-01-02 10:01:46 --> Output Class Initialized
DEBUG - 2014-01-02 10:01:46 --> Security Class Initialized
DEBUG - 2014-01-02 10:01:46 --> Input Class Initialized
DEBUG - 2014-01-02 10:01:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 10:01:46 --> Language Class Initialized
DEBUG - 2014-01-02 10:01:46 --> Loader Class Initialized
DEBUG - 2014-01-02 10:01:46 --> Helper loaded: url_helper
DEBUG - 2014-01-02 10:01:46 --> Helper loaded: common_helper
DEBUG - 2014-01-02 10:01:46 --> Database Driver Class Initialized
DEBUG - 2014-01-02 10:01:46 --> Controller Class Initialized
DEBUG - 2014-01-02 10:01:46 --> Session Class Initialized
DEBUG - 2014-01-02 10:01:46 --> Helper loaded: string_helper
DEBUG - 2014-01-02 10:01:46 --> Encrypt Class Initialized
DEBUG - 2014-01-02 10:01:46 --> Session routines successfully run
DEBUG - 2014-01-02 10:01:46 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 10:01:46 --> Final output sent to browser
DEBUG - 2014-01-02 10:01:46 --> Total execution time: 0.0347
DEBUG - 2014-01-02 10:06:53 --> Config Class Initialized
DEBUG - 2014-01-02 10:06:53 --> Hooks Class Initialized
DEBUG - 2014-01-02 10:06:53 --> Utf8 Class Initialized
DEBUG - 2014-01-02 10:06:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 10:06:53 --> URI Class Initialized
DEBUG - 2014-01-02 10:06:53 --> Router Class Initialized
DEBUG - 2014-01-02 10:06:53 --> Output Class Initialized
DEBUG - 2014-01-02 10:06:53 --> Security Class Initialized
DEBUG - 2014-01-02 10:06:53 --> Input Class Initialized
DEBUG - 2014-01-02 10:06:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 10:06:53 --> Language Class Initialized
DEBUG - 2014-01-02 10:06:53 --> Loader Class Initialized
DEBUG - 2014-01-02 10:06:53 --> Helper loaded: url_helper
DEBUG - 2014-01-02 10:06:53 --> Helper loaded: common_helper
DEBUG - 2014-01-02 10:06:53 --> Database Driver Class Initialized
DEBUG - 2014-01-02 10:06:53 --> Controller Class Initialized
DEBUG - 2014-01-02 10:06:53 --> Session Class Initialized
DEBUG - 2014-01-02 10:06:53 --> Helper loaded: string_helper
DEBUG - 2014-01-02 10:06:53 --> Encrypt Class Initialized
DEBUG - 2014-01-02 10:06:53 --> Session routines successfully run
DEBUG - 2014-01-02 10:06:53 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 10:06:53 --> Final output sent to browser
DEBUG - 2014-01-02 10:06:53 --> Total execution time: 0.0463
DEBUG - 2014-01-02 10:07:00 --> Config Class Initialized
DEBUG - 2014-01-02 10:07:00 --> Hooks Class Initialized
DEBUG - 2014-01-02 10:07:00 --> Utf8 Class Initialized
DEBUG - 2014-01-02 10:07:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 10:07:00 --> URI Class Initialized
DEBUG - 2014-01-02 10:07:00 --> Router Class Initialized
DEBUG - 2014-01-02 10:07:00 --> Output Class Initialized
DEBUG - 2014-01-02 10:07:00 --> Security Class Initialized
DEBUG - 2014-01-02 10:07:00 --> Input Class Initialized
DEBUG - 2014-01-02 10:07:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 10:07:00 --> Language Class Initialized
DEBUG - 2014-01-02 10:07:00 --> Loader Class Initialized
DEBUG - 2014-01-02 10:07:00 --> Helper loaded: url_helper
DEBUG - 2014-01-02 10:07:00 --> Helper loaded: common_helper
DEBUG - 2014-01-02 10:07:00 --> Database Driver Class Initialized
DEBUG - 2014-01-02 10:07:00 --> Controller Class Initialized
DEBUG - 2014-01-02 10:07:00 --> Session Class Initialized
DEBUG - 2014-01-02 10:07:00 --> Helper loaded: string_helper
DEBUG - 2014-01-02 10:07:00 --> Encrypt Class Initialized
DEBUG - 2014-01-02 10:07:00 --> Session routines successfully run
DEBUG - 2014-01-02 10:07:00 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 10:07:00 --> Final output sent to browser
DEBUG - 2014-01-02 10:07:00 --> Total execution time: 0.0333
DEBUG - 2014-01-02 10:07:07 --> Config Class Initialized
DEBUG - 2014-01-02 10:07:07 --> Hooks Class Initialized
DEBUG - 2014-01-02 10:07:07 --> Utf8 Class Initialized
DEBUG - 2014-01-02 10:07:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 10:07:07 --> URI Class Initialized
DEBUG - 2014-01-02 10:07:07 --> Router Class Initialized
DEBUG - 2014-01-02 10:07:07 --> Output Class Initialized
DEBUG - 2014-01-02 10:07:07 --> Security Class Initialized
DEBUG - 2014-01-02 10:07:07 --> Input Class Initialized
DEBUG - 2014-01-02 10:07:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 10:07:07 --> Language Class Initialized
DEBUG - 2014-01-02 10:07:07 --> Loader Class Initialized
DEBUG - 2014-01-02 10:07:07 --> Helper loaded: url_helper
DEBUG - 2014-01-02 10:07:07 --> Helper loaded: common_helper
DEBUG - 2014-01-02 10:07:07 --> Database Driver Class Initialized
DEBUG - 2014-01-02 10:07:07 --> Controller Class Initialized
DEBUG - 2014-01-02 10:07:07 --> Session Class Initialized
DEBUG - 2014-01-02 10:07:07 --> Helper loaded: string_helper
DEBUG - 2014-01-02 10:07:07 --> Encrypt Class Initialized
DEBUG - 2014-01-02 10:07:07 --> Session routines successfully run
DEBUG - 2014-01-02 10:07:07 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 10:07:07 --> Database Driver Class Initialized
DEBUG - 2014-01-02 10:07:07 --> Controller Class Initialized
DEBUG - 2014-01-02 10:07:07 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-02 10:07:07 --> Twig Autoloader Loaded
DEBUG - 2014-01-02 10:07:07 --> lsession class already loaded. Second attempt ignored.
DEBUG - 2014-01-02 10:07:07 --> Final output sent to browser
DEBUG - 2014-01-02 10:07:07 --> Total execution time: 0.1038
DEBUG - 2014-01-02 10:07:09 --> Config Class Initialized
DEBUG - 2014-01-02 10:07:09 --> Hooks Class Initialized
DEBUG - 2014-01-02 10:07:09 --> Utf8 Class Initialized
DEBUG - 2014-01-02 10:07:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 10:07:09 --> URI Class Initialized
DEBUG - 2014-01-02 10:07:09 --> Router Class Initialized
DEBUG - 2014-01-02 10:07:09 --> Output Class Initialized
DEBUG - 2014-01-02 10:07:09 --> Security Class Initialized
DEBUG - 2014-01-02 10:07:09 --> Input Class Initialized
DEBUG - 2014-01-02 10:07:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 10:07:09 --> Language Class Initialized
DEBUG - 2014-01-02 10:07:09 --> Loader Class Initialized
DEBUG - 2014-01-02 10:07:09 --> Helper loaded: url_helper
DEBUG - 2014-01-02 10:07:09 --> Helper loaded: common_helper
DEBUG - 2014-01-02 10:07:09 --> Database Driver Class Initialized
DEBUG - 2014-01-02 10:07:09 --> Controller Class Initialized
DEBUG - 2014-01-02 10:07:09 --> Session Class Initialized
DEBUG - 2014-01-02 10:07:09 --> Helper loaded: string_helper
DEBUG - 2014-01-02 10:07:09 --> Encrypt Class Initialized
DEBUG - 2014-01-02 10:07:09 --> Session routines successfully run
DEBUG - 2014-01-02 10:07:09 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 10:07:09 --> Final output sent to browser
DEBUG - 2014-01-02 10:07:09 --> Total execution time: 0.0334
DEBUG - 2014-01-02 12:13:08 --> Config Class Initialized
DEBUG - 2014-01-02 12:13:08 --> Hooks Class Initialized
DEBUG - 2014-01-02 12:13:08 --> Utf8 Class Initialized
DEBUG - 2014-01-02 12:13:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 12:13:08 --> URI Class Initialized
DEBUG - 2014-01-02 12:13:08 --> Router Class Initialized
DEBUG - 2014-01-02 12:13:08 --> Output Class Initialized
DEBUG - 2014-01-02 12:13:08 --> Security Class Initialized
DEBUG - 2014-01-02 12:13:08 --> Input Class Initialized
DEBUG - 2014-01-02 12:13:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 12:13:08 --> Language Class Initialized
DEBUG - 2014-01-02 12:13:08 --> Loader Class Initialized
DEBUG - 2014-01-02 12:13:08 --> Helper loaded: url_helper
DEBUG - 2014-01-02 12:13:08 --> Helper loaded: common_helper
DEBUG - 2014-01-02 12:13:08 --> Database Driver Class Initialized
DEBUG - 2014-01-02 12:13:08 --> Controller Class Initialized
DEBUG - 2014-01-02 12:13:08 --> Session Class Initialized
DEBUG - 2014-01-02 12:13:08 --> Helper loaded: string_helper
DEBUG - 2014-01-02 12:13:08 --> Encrypt Class Initialized
DEBUG - 2014-01-02 12:13:08 --> Session routines successfully run
DEBUG - 2014-01-02 12:13:08 --> Config file loaded: application/config/acl.php
ERROR - 2014-01-02 12:13:08 --> Severity: Notice  --> Undefined property: Api::$model /var/www/mustang/application/controllers/api.php 24
DEBUG - 2014-01-02 12:13:53 --> Config Class Initialized
DEBUG - 2014-01-02 12:13:53 --> Hooks Class Initialized
DEBUG - 2014-01-02 12:13:53 --> Utf8 Class Initialized
DEBUG - 2014-01-02 12:13:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 12:13:53 --> URI Class Initialized
DEBUG - 2014-01-02 12:13:53 --> Router Class Initialized
DEBUG - 2014-01-02 12:13:53 --> Output Class Initialized
DEBUG - 2014-01-02 12:13:53 --> Security Class Initialized
DEBUG - 2014-01-02 12:13:53 --> Input Class Initialized
DEBUG - 2014-01-02 12:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 12:13:53 --> Language Class Initialized
DEBUG - 2014-01-02 12:13:53 --> Loader Class Initialized
DEBUG - 2014-01-02 12:13:53 --> Helper loaded: url_helper
DEBUG - 2014-01-02 12:13:53 --> Helper loaded: common_helper
DEBUG - 2014-01-02 12:13:53 --> Database Driver Class Initialized
DEBUG - 2014-01-02 12:13:53 --> Controller Class Initialized
DEBUG - 2014-01-02 12:13:53 --> Session Class Initialized
DEBUG - 2014-01-02 12:13:53 --> Helper loaded: string_helper
DEBUG - 2014-01-02 12:13:53 --> Encrypt Class Initialized
DEBUG - 2014-01-02 12:13:53 --> Session routines successfully run
DEBUG - 2014-01-02 12:13:53 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 12:13:53 --> Model Class Initialized
DEBUG - 2014-01-02 12:13:55 --> Config Class Initialized
DEBUG - 2014-01-02 12:13:55 --> Hooks Class Initialized
DEBUG - 2014-01-02 12:13:55 --> Utf8 Class Initialized
DEBUG - 2014-01-02 12:13:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 12:13:55 --> URI Class Initialized
DEBUG - 2014-01-02 12:13:55 --> Router Class Initialized
DEBUG - 2014-01-02 12:13:55 --> Output Class Initialized
DEBUG - 2014-01-02 12:13:55 --> Security Class Initialized
DEBUG - 2014-01-02 12:13:55 --> Input Class Initialized
DEBUG - 2014-01-02 12:13:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 12:13:55 --> Language Class Initialized
DEBUG - 2014-01-02 12:13:55 --> Loader Class Initialized
DEBUG - 2014-01-02 12:13:55 --> Helper loaded: url_helper
DEBUG - 2014-01-02 12:13:55 --> Helper loaded: common_helper
DEBUG - 2014-01-02 12:13:55 --> Database Driver Class Initialized
DEBUG - 2014-01-02 12:13:55 --> Controller Class Initialized
DEBUG - 2014-01-02 12:13:55 --> Session Class Initialized
DEBUG - 2014-01-02 12:13:55 --> Helper loaded: string_helper
DEBUG - 2014-01-02 12:13:55 --> Encrypt Class Initialized
DEBUG - 2014-01-02 12:13:55 --> Session routines successfully run
DEBUG - 2014-01-02 12:13:55 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 12:13:55 --> Model Class Initialized
DEBUG - 2014-01-02 12:14:03 --> Config Class Initialized
DEBUG - 2014-01-02 12:14:03 --> Hooks Class Initialized
DEBUG - 2014-01-02 12:14:03 --> Utf8 Class Initialized
DEBUG - 2014-01-02 12:14:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 12:14:03 --> URI Class Initialized
DEBUG - 2014-01-02 12:14:03 --> Router Class Initialized
DEBUG - 2014-01-02 12:14:03 --> Output Class Initialized
DEBUG - 2014-01-02 12:14:03 --> Security Class Initialized
DEBUG - 2014-01-02 12:14:03 --> Input Class Initialized
DEBUG - 2014-01-02 12:14:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 12:14:03 --> Language Class Initialized
DEBUG - 2014-01-02 12:14:03 --> Loader Class Initialized
DEBUG - 2014-01-02 12:14:03 --> Helper loaded: url_helper
DEBUG - 2014-01-02 12:14:03 --> Helper loaded: common_helper
DEBUG - 2014-01-02 12:14:03 --> Database Driver Class Initialized
DEBUG - 2014-01-02 12:14:03 --> Controller Class Initialized
DEBUG - 2014-01-02 12:14:03 --> Session Class Initialized
DEBUG - 2014-01-02 12:14:03 --> Helper loaded: string_helper
DEBUG - 2014-01-02 12:14:03 --> Encrypt Class Initialized
DEBUG - 2014-01-02 12:14:03 --> Session routines successfully run
DEBUG - 2014-01-02 12:14:03 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 12:14:03 --> Model Class Initialized
DEBUG - 2014-01-02 12:14:42 --> Config Class Initialized
DEBUG - 2014-01-02 12:14:42 --> Hooks Class Initialized
DEBUG - 2014-01-02 12:14:42 --> Utf8 Class Initialized
DEBUG - 2014-01-02 12:14:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 12:14:42 --> URI Class Initialized
DEBUG - 2014-01-02 12:14:42 --> Router Class Initialized
DEBUG - 2014-01-02 12:14:42 --> Output Class Initialized
DEBUG - 2014-01-02 12:14:42 --> Security Class Initialized
DEBUG - 2014-01-02 12:14:42 --> Input Class Initialized
DEBUG - 2014-01-02 12:14:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 12:14:42 --> Language Class Initialized
DEBUG - 2014-01-02 12:14:42 --> Loader Class Initialized
DEBUG - 2014-01-02 12:14:42 --> Helper loaded: url_helper
DEBUG - 2014-01-02 12:14:42 --> Helper loaded: common_helper
DEBUG - 2014-01-02 12:14:42 --> Database Driver Class Initialized
DEBUG - 2014-01-02 12:14:42 --> Controller Class Initialized
DEBUG - 2014-01-02 12:14:42 --> Session Class Initialized
DEBUG - 2014-01-02 12:14:42 --> Helper loaded: string_helper
DEBUG - 2014-01-02 12:14:42 --> Encrypt Class Initialized
DEBUG - 2014-01-02 12:14:42 --> Session routines successfully run
DEBUG - 2014-01-02 12:14:42 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 12:14:42 --> Model Class Initialized
DEBUG - 2014-01-02 12:14:42 --> Config Class Initialized
DEBUG - 2014-01-02 12:14:42 --> Hooks Class Initialized
DEBUG - 2014-01-02 12:14:42 --> Utf8 Class Initialized
DEBUG - 2014-01-02 12:14:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 12:14:42 --> URI Class Initialized
DEBUG - 2014-01-02 12:14:42 --> Router Class Initialized
DEBUG - 2014-01-02 12:14:42 --> Output Class Initialized
DEBUG - 2014-01-02 12:14:42 --> Security Class Initialized
DEBUG - 2014-01-02 12:14:42 --> Input Class Initialized
DEBUG - 2014-01-02 12:14:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 12:14:42 --> Language Class Initialized
DEBUG - 2014-01-02 12:14:42 --> Loader Class Initialized
DEBUG - 2014-01-02 12:14:42 --> Helper loaded: url_helper
DEBUG - 2014-01-02 12:14:42 --> Helper loaded: common_helper
DEBUG - 2014-01-02 12:14:43 --> Database Driver Class Initialized
DEBUG - 2014-01-02 12:14:43 --> Controller Class Initialized
DEBUG - 2014-01-02 12:14:43 --> Session Class Initialized
DEBUG - 2014-01-02 12:14:43 --> Helper loaded: string_helper
DEBUG - 2014-01-02 12:14:43 --> Encrypt Class Initialized
DEBUG - 2014-01-02 12:14:43 --> Session routines successfully run
DEBUG - 2014-01-02 12:14:43 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 12:14:43 --> Model Class Initialized
DEBUG - 2014-01-02 12:14:57 --> Config Class Initialized
DEBUG - 2014-01-02 12:14:57 --> Hooks Class Initialized
DEBUG - 2014-01-02 12:14:57 --> Utf8 Class Initialized
DEBUG - 2014-01-02 12:14:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 12:14:57 --> URI Class Initialized
DEBUG - 2014-01-02 12:14:57 --> Router Class Initialized
DEBUG - 2014-01-02 12:14:57 --> Output Class Initialized
DEBUG - 2014-01-02 12:14:57 --> Security Class Initialized
DEBUG - 2014-01-02 12:14:57 --> Input Class Initialized
DEBUG - 2014-01-02 12:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 12:14:57 --> Language Class Initialized
DEBUG - 2014-01-02 12:14:57 --> Loader Class Initialized
DEBUG - 2014-01-02 12:14:57 --> Helper loaded: url_helper
DEBUG - 2014-01-02 12:14:57 --> Helper loaded: common_helper
DEBUG - 2014-01-02 12:14:57 --> Database Driver Class Initialized
DEBUG - 2014-01-02 12:14:57 --> Controller Class Initialized
DEBUG - 2014-01-02 12:14:57 --> Session Class Initialized
DEBUG - 2014-01-02 12:14:57 --> Helper loaded: string_helper
DEBUG - 2014-01-02 12:14:57 --> Encrypt Class Initialized
DEBUG - 2014-01-02 12:14:57 --> Session routines successfully run
DEBUG - 2014-01-02 12:14:57 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 12:14:57 --> Model Class Initialized
DEBUG - 2014-01-02 12:14:58 --> Config Class Initialized
DEBUG - 2014-01-02 12:14:58 --> Hooks Class Initialized
DEBUG - 2014-01-02 12:14:58 --> Utf8 Class Initialized
DEBUG - 2014-01-02 12:14:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 12:14:58 --> URI Class Initialized
DEBUG - 2014-01-02 12:14:58 --> Router Class Initialized
DEBUG - 2014-01-02 12:14:58 --> Output Class Initialized
DEBUG - 2014-01-02 12:14:58 --> Security Class Initialized
DEBUG - 2014-01-02 12:14:58 --> Input Class Initialized
DEBUG - 2014-01-02 12:14:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 12:14:58 --> Language Class Initialized
DEBUG - 2014-01-02 12:14:58 --> Loader Class Initialized
DEBUG - 2014-01-02 12:14:58 --> Helper loaded: url_helper
DEBUG - 2014-01-02 12:14:58 --> Helper loaded: common_helper
DEBUG - 2014-01-02 12:14:58 --> Database Driver Class Initialized
DEBUG - 2014-01-02 12:14:58 --> Controller Class Initialized
DEBUG - 2014-01-02 12:14:58 --> Session Class Initialized
DEBUG - 2014-01-02 12:14:58 --> Helper loaded: string_helper
DEBUG - 2014-01-02 12:14:58 --> Encrypt Class Initialized
DEBUG - 2014-01-02 12:14:58 --> Session routines successfully run
DEBUG - 2014-01-02 12:14:58 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 12:14:58 --> Model Class Initialized
DEBUG - 2014-01-02 12:15:32 --> Config Class Initialized
DEBUG - 2014-01-02 12:15:32 --> Hooks Class Initialized
DEBUG - 2014-01-02 12:15:32 --> Utf8 Class Initialized
DEBUG - 2014-01-02 12:15:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 12:15:32 --> URI Class Initialized
DEBUG - 2014-01-02 12:15:32 --> Router Class Initialized
DEBUG - 2014-01-02 12:15:32 --> Output Class Initialized
DEBUG - 2014-01-02 12:15:32 --> Security Class Initialized
DEBUG - 2014-01-02 12:15:32 --> Input Class Initialized
DEBUG - 2014-01-02 12:15:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 12:15:32 --> Language Class Initialized
DEBUG - 2014-01-02 12:15:32 --> Loader Class Initialized
DEBUG - 2014-01-02 12:15:32 --> Helper loaded: url_helper
DEBUG - 2014-01-02 12:15:32 --> Helper loaded: common_helper
DEBUG - 2014-01-02 12:15:32 --> Database Driver Class Initialized
DEBUG - 2014-01-02 12:15:32 --> Controller Class Initialized
DEBUG - 2014-01-02 12:15:32 --> Session Class Initialized
DEBUG - 2014-01-02 12:15:32 --> Helper loaded: string_helper
DEBUG - 2014-01-02 12:15:32 --> Encrypt Class Initialized
DEBUG - 2014-01-02 12:15:32 --> Session routines successfully run
DEBUG - 2014-01-02 12:15:32 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 12:15:32 --> Model Class Initialized
DEBUG - 2014-01-02 12:16:01 --> Config Class Initialized
DEBUG - 2014-01-02 12:16:01 --> Hooks Class Initialized
DEBUG - 2014-01-02 12:16:01 --> Utf8 Class Initialized
DEBUG - 2014-01-02 12:16:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 12:16:01 --> URI Class Initialized
DEBUG - 2014-01-02 12:16:01 --> Router Class Initialized
DEBUG - 2014-01-02 12:16:01 --> Output Class Initialized
DEBUG - 2014-01-02 12:16:01 --> Security Class Initialized
DEBUG - 2014-01-02 12:16:01 --> Input Class Initialized
DEBUG - 2014-01-02 12:16:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 12:16:01 --> Language Class Initialized
DEBUG - 2014-01-02 12:16:01 --> Loader Class Initialized
DEBUG - 2014-01-02 12:16:01 --> Helper loaded: url_helper
DEBUG - 2014-01-02 12:16:01 --> Helper loaded: common_helper
DEBUG - 2014-01-02 12:16:01 --> Database Driver Class Initialized
DEBUG - 2014-01-02 12:16:01 --> Controller Class Initialized
DEBUG - 2014-01-02 12:16:01 --> Session Class Initialized
DEBUG - 2014-01-02 12:16:01 --> Helper loaded: string_helper
DEBUG - 2014-01-02 12:16:01 --> Encrypt Class Initialized
DEBUG - 2014-01-02 12:16:01 --> Session routines successfully run
DEBUG - 2014-01-02 12:16:01 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 12:16:01 --> Model Class Initialized
DEBUG - 2014-01-02 12:16:01 --> Model Class Initialized
DEBUG - 2014-01-02 12:20:37 --> Config Class Initialized
DEBUG - 2014-01-02 12:20:37 --> Hooks Class Initialized
DEBUG - 2014-01-02 12:20:37 --> Utf8 Class Initialized
DEBUG - 2014-01-02 12:20:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 12:20:37 --> URI Class Initialized
DEBUG - 2014-01-02 12:20:37 --> Router Class Initialized
DEBUG - 2014-01-02 12:20:37 --> Output Class Initialized
DEBUG - 2014-01-02 12:20:37 --> Security Class Initialized
DEBUG - 2014-01-02 12:20:37 --> Input Class Initialized
DEBUG - 2014-01-02 12:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 12:20:37 --> Language Class Initialized
DEBUG - 2014-01-02 12:20:37 --> Loader Class Initialized
DEBUG - 2014-01-02 12:20:37 --> Helper loaded: url_helper
DEBUG - 2014-01-02 12:20:37 --> Helper loaded: common_helper
DEBUG - 2014-01-02 12:20:37 --> Database Driver Class Initialized
DEBUG - 2014-01-02 12:20:37 --> Controller Class Initialized
DEBUG - 2014-01-02 12:20:37 --> Session Class Initialized
DEBUG - 2014-01-02 12:20:37 --> Helper loaded: string_helper
DEBUG - 2014-01-02 12:20:37 --> Encrypt Class Initialized
DEBUG - 2014-01-02 12:20:37 --> Session routines successfully run
DEBUG - 2014-01-02 12:20:37 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 12:20:37 --> Model Class Initialized
DEBUG - 2014-01-02 12:20:37 --> Model Class Initialized
ERROR - 2014-01-02 12:20:37 --> Severity: 4096  --> Object of class CI_Output could not be converted to string /var/www/mustang/application/controllers/api.php 34
DEBUG - 2014-01-02 12:20:37 --> Final output sent to browser
DEBUG - 2014-01-02 12:20:37 --> Total execution time: 0.0426
DEBUG - 2014-01-02 12:21:31 --> Config Class Initialized
DEBUG - 2014-01-02 12:21:31 --> Hooks Class Initialized
DEBUG - 2014-01-02 12:21:31 --> Utf8 Class Initialized
DEBUG - 2014-01-02 12:21:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 12:21:31 --> URI Class Initialized
DEBUG - 2014-01-02 12:21:31 --> Router Class Initialized
DEBUG - 2014-01-02 12:21:31 --> Output Class Initialized
DEBUG - 2014-01-02 12:21:31 --> Security Class Initialized
DEBUG - 2014-01-02 12:21:31 --> Input Class Initialized
DEBUG - 2014-01-02 12:21:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 12:21:31 --> Language Class Initialized
DEBUG - 2014-01-02 12:21:31 --> Loader Class Initialized
DEBUG - 2014-01-02 12:21:31 --> Helper loaded: url_helper
DEBUG - 2014-01-02 12:21:31 --> Helper loaded: common_helper
DEBUG - 2014-01-02 12:21:31 --> Database Driver Class Initialized
DEBUG - 2014-01-02 12:21:31 --> Controller Class Initialized
DEBUG - 2014-01-02 12:21:31 --> Session Class Initialized
DEBUG - 2014-01-02 12:21:31 --> Helper loaded: string_helper
DEBUG - 2014-01-02 12:21:31 --> Encrypt Class Initialized
DEBUG - 2014-01-02 12:21:31 --> Session routines successfully run
DEBUG - 2014-01-02 12:21:31 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 12:21:31 --> Model Class Initialized
DEBUG - 2014-01-02 12:21:31 --> Model Class Initialized
DEBUG - 2014-01-02 12:21:31 --> Final output sent to browser
DEBUG - 2014-01-02 12:21:31 --> Total execution time: 0.0399
DEBUG - 2014-01-02 12:21:43 --> Config Class Initialized
DEBUG - 2014-01-02 12:21:43 --> Hooks Class Initialized
DEBUG - 2014-01-02 12:21:43 --> Utf8 Class Initialized
DEBUG - 2014-01-02 12:21:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 12:21:43 --> URI Class Initialized
DEBUG - 2014-01-02 12:21:43 --> Router Class Initialized
DEBUG - 2014-01-02 12:21:43 --> Output Class Initialized
DEBUG - 2014-01-02 12:21:43 --> Security Class Initialized
DEBUG - 2014-01-02 12:21:43 --> Input Class Initialized
DEBUG - 2014-01-02 12:21:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 12:21:43 --> Language Class Initialized
DEBUG - 2014-01-02 12:21:43 --> Loader Class Initialized
DEBUG - 2014-01-02 12:21:43 --> Helper loaded: url_helper
DEBUG - 2014-01-02 12:21:43 --> Helper loaded: common_helper
DEBUG - 2014-01-02 12:21:43 --> Database Driver Class Initialized
DEBUG - 2014-01-02 12:21:43 --> Controller Class Initialized
DEBUG - 2014-01-02 12:21:43 --> Session Class Initialized
DEBUG - 2014-01-02 12:21:43 --> Helper loaded: string_helper
DEBUG - 2014-01-02 12:21:43 --> Encrypt Class Initialized
DEBUG - 2014-01-02 12:21:43 --> Session routines successfully run
DEBUG - 2014-01-02 12:21:43 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 12:21:43 --> Model Class Initialized
DEBUG - 2014-01-02 12:21:43 --> Model Class Initialized
DEBUG - 2014-01-02 12:21:43 --> Final output sent to browser
DEBUG - 2014-01-02 12:21:43 --> Total execution time: 0.0336
DEBUG - 2014-01-02 12:21:56 --> Config Class Initialized
DEBUG - 2014-01-02 12:21:56 --> Hooks Class Initialized
DEBUG - 2014-01-02 12:21:56 --> Utf8 Class Initialized
DEBUG - 2014-01-02 12:21:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 12:21:56 --> URI Class Initialized
DEBUG - 2014-01-02 12:21:56 --> Router Class Initialized
DEBUG - 2014-01-02 12:21:56 --> Output Class Initialized
DEBUG - 2014-01-02 12:21:56 --> Security Class Initialized
DEBUG - 2014-01-02 12:21:56 --> Input Class Initialized
DEBUG - 2014-01-02 12:21:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 12:21:56 --> Language Class Initialized
DEBUG - 2014-01-02 12:21:56 --> Loader Class Initialized
DEBUG - 2014-01-02 12:21:56 --> Helper loaded: url_helper
DEBUG - 2014-01-02 12:21:56 --> Helper loaded: common_helper
DEBUG - 2014-01-02 12:21:56 --> Database Driver Class Initialized
DEBUG - 2014-01-02 12:21:56 --> Controller Class Initialized
DEBUG - 2014-01-02 12:21:56 --> Session Class Initialized
DEBUG - 2014-01-02 12:21:56 --> Helper loaded: string_helper
DEBUG - 2014-01-02 12:21:56 --> Encrypt Class Initialized
DEBUG - 2014-01-02 12:21:56 --> Session routines successfully run
DEBUG - 2014-01-02 12:21:56 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 12:21:56 --> Model Class Initialized
DEBUG - 2014-01-02 12:21:56 --> Model Class Initialized
DEBUG - 2014-01-02 12:21:56 --> Final output sent to browser
DEBUG - 2014-01-02 12:21:56 --> Total execution time: 0.0325
DEBUG - 2014-01-02 12:22:14 --> Config Class Initialized
DEBUG - 2014-01-02 12:22:14 --> Hooks Class Initialized
DEBUG - 2014-01-02 12:22:14 --> Utf8 Class Initialized
DEBUG - 2014-01-02 12:22:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 12:22:14 --> URI Class Initialized
DEBUG - 2014-01-02 12:22:14 --> Router Class Initialized
DEBUG - 2014-01-02 12:22:14 --> Output Class Initialized
DEBUG - 2014-01-02 12:22:14 --> Security Class Initialized
DEBUG - 2014-01-02 12:22:14 --> Input Class Initialized
DEBUG - 2014-01-02 12:22:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 12:22:14 --> Language Class Initialized
DEBUG - 2014-01-02 12:22:14 --> Loader Class Initialized
DEBUG - 2014-01-02 12:22:14 --> Helper loaded: url_helper
DEBUG - 2014-01-02 12:22:14 --> Helper loaded: common_helper
DEBUG - 2014-01-02 12:22:14 --> Database Driver Class Initialized
DEBUG - 2014-01-02 12:22:14 --> Controller Class Initialized
DEBUG - 2014-01-02 12:22:14 --> Session Class Initialized
DEBUG - 2014-01-02 12:22:14 --> Helper loaded: string_helper
DEBUG - 2014-01-02 12:22:14 --> Encrypt Class Initialized
DEBUG - 2014-01-02 12:22:14 --> Session routines successfully run
DEBUG - 2014-01-02 12:22:14 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 12:22:14 --> Model Class Initialized
DEBUG - 2014-01-02 12:22:14 --> Model Class Initialized
DEBUG - 2014-01-02 12:22:14 --> Final output sent to browser
DEBUG - 2014-01-02 12:22:14 --> Total execution time: 0.0340
DEBUG - 2014-01-02 12:38:04 --> Config Class Initialized
DEBUG - 2014-01-02 12:38:04 --> Hooks Class Initialized
DEBUG - 2014-01-02 12:38:04 --> Utf8 Class Initialized
DEBUG - 2014-01-02 12:38:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 12:38:04 --> URI Class Initialized
DEBUG - 2014-01-02 12:38:04 --> Router Class Initialized
DEBUG - 2014-01-02 12:38:04 --> Output Class Initialized
DEBUG - 2014-01-02 12:38:04 --> Security Class Initialized
DEBUG - 2014-01-02 12:38:04 --> Input Class Initialized
DEBUG - 2014-01-02 12:38:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 12:38:04 --> Language Class Initialized
DEBUG - 2014-01-02 12:38:04 --> Loader Class Initialized
DEBUG - 2014-01-02 12:38:04 --> Helper loaded: url_helper
DEBUG - 2014-01-02 12:38:04 --> Helper loaded: common_helper
DEBUG - 2014-01-02 12:38:04 --> Database Driver Class Initialized
DEBUG - 2014-01-02 12:38:04 --> Controller Class Initialized
DEBUG - 2014-01-02 12:38:04 --> Session Class Initialized
DEBUG - 2014-01-02 12:38:04 --> Helper loaded: string_helper
DEBUG - 2014-01-02 12:38:04 --> Encrypt Class Initialized
DEBUG - 2014-01-02 12:38:04 --> A session cookie was not found.
DEBUG - 2014-01-02 12:38:04 --> Session routines successfully run
DEBUG - 2014-01-02 12:38:04 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 12:38:04 --> Model Class Initialized
DEBUG - 2014-01-02 12:38:04 --> Model Class Initialized
ERROR - 2014-01-02 12:38:04 --> Severity: Notice  --> Undefined variable: data /var/www/mustang/application/controllers/api.php 25
ERROR - 2014-01-02 12:38:04 --> Severity: Warning  --> in_array() expects parameter 2 to be array, null given /var/www/mustang/application/controllers/api.php 25
DEBUG - 2014-01-02 12:38:04 --> Final output sent to browser
DEBUG - 2014-01-02 12:38:04 --> Total execution time: 0.0440
DEBUG - 2014-01-02 12:39:54 --> Config Class Initialized
DEBUG - 2014-01-02 12:39:54 --> Hooks Class Initialized
DEBUG - 2014-01-02 12:39:54 --> Utf8 Class Initialized
DEBUG - 2014-01-02 12:39:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 12:39:54 --> URI Class Initialized
DEBUG - 2014-01-02 12:39:54 --> Router Class Initialized
DEBUG - 2014-01-02 12:39:54 --> Output Class Initialized
DEBUG - 2014-01-02 12:39:54 --> Security Class Initialized
DEBUG - 2014-01-02 12:39:54 --> Input Class Initialized
DEBUG - 2014-01-02 12:39:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 12:39:54 --> Language Class Initialized
DEBUG - 2014-01-02 12:39:54 --> Loader Class Initialized
DEBUG - 2014-01-02 12:39:54 --> Helper loaded: url_helper
DEBUG - 2014-01-02 12:39:54 --> Helper loaded: common_helper
DEBUG - 2014-01-02 12:39:54 --> Database Driver Class Initialized
DEBUG - 2014-01-02 12:39:54 --> Controller Class Initialized
DEBUG - 2014-01-02 12:39:54 --> Session Class Initialized
DEBUG - 2014-01-02 12:39:54 --> Helper loaded: string_helper
DEBUG - 2014-01-02 12:39:54 --> Encrypt Class Initialized
DEBUG - 2014-01-02 12:39:54 --> Session routines successfully run
DEBUG - 2014-01-02 12:39:54 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 12:39:54 --> Model Class Initialized
DEBUG - 2014-01-02 12:39:54 --> Model Class Initialized
ERROR - 2014-01-02 12:39:54 --> Severity: Notice  --> Undefined variable: data /var/www/mustang/application/controllers/api.php 25
ERROR - 2014-01-02 12:39:54 --> Severity: Notice  --> Trying to get property of non-object /var/www/mustang/application/controllers/api.php 26
DEBUG - 2014-01-02 12:39:54 --> Final output sent to browser
DEBUG - 2014-01-02 12:39:54 --> Total execution time: 0.0417
DEBUG - 2014-01-02 12:41:46 --> Config Class Initialized
DEBUG - 2014-01-02 12:41:46 --> Hooks Class Initialized
DEBUG - 2014-01-02 12:41:46 --> Utf8 Class Initialized
DEBUG - 2014-01-02 12:41:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 12:41:46 --> URI Class Initialized
DEBUG - 2014-01-02 12:41:46 --> Router Class Initialized
DEBUG - 2014-01-02 12:41:46 --> Output Class Initialized
DEBUG - 2014-01-02 12:41:46 --> Security Class Initialized
DEBUG - 2014-01-02 12:41:46 --> Input Class Initialized
DEBUG - 2014-01-02 12:41:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 12:41:46 --> Language Class Initialized
DEBUG - 2014-01-02 12:41:46 --> Loader Class Initialized
DEBUG - 2014-01-02 12:41:46 --> Helper loaded: url_helper
DEBUG - 2014-01-02 12:41:46 --> Helper loaded: common_helper
DEBUG - 2014-01-02 12:41:46 --> Database Driver Class Initialized
DEBUG - 2014-01-02 12:41:46 --> Controller Class Initialized
DEBUG - 2014-01-02 12:41:46 --> Session Class Initialized
DEBUG - 2014-01-02 12:41:46 --> Helper loaded: string_helper
DEBUG - 2014-01-02 12:41:46 --> Encrypt Class Initialized
DEBUG - 2014-01-02 12:41:46 --> Session routines successfully run
DEBUG - 2014-01-02 12:41:46 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 12:41:46 --> Model Class Initialized
DEBUG - 2014-01-02 12:41:46 --> Model Class Initialized
DEBUG - 2014-01-02 12:41:46 --> Model Class Initialized
DEBUG - 2014-01-02 12:41:46 --> DB Transaction Failure
ERROR - 2014-01-02 12:41:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' D.REMARKS                 Remarks
            , D.UPD_DATE                Updat' at line 10
DEBUG - 2014-01-02 12:41:46 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-02 12:42:35 --> Config Class Initialized
DEBUG - 2014-01-02 12:42:35 --> Hooks Class Initialized
DEBUG - 2014-01-02 12:42:35 --> Utf8 Class Initialized
DEBUG - 2014-01-02 12:42:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 12:42:35 --> URI Class Initialized
DEBUG - 2014-01-02 12:42:35 --> Router Class Initialized
DEBUG - 2014-01-02 12:42:35 --> Output Class Initialized
DEBUG - 2014-01-02 12:42:35 --> Security Class Initialized
DEBUG - 2014-01-02 12:42:35 --> Input Class Initialized
DEBUG - 2014-01-02 12:42:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 12:42:35 --> Language Class Initialized
DEBUG - 2014-01-02 12:42:35 --> Loader Class Initialized
DEBUG - 2014-01-02 12:42:35 --> Helper loaded: url_helper
DEBUG - 2014-01-02 12:42:35 --> Helper loaded: common_helper
DEBUG - 2014-01-02 12:42:35 --> Database Driver Class Initialized
DEBUG - 2014-01-02 12:42:35 --> Controller Class Initialized
DEBUG - 2014-01-02 12:42:35 --> Session Class Initialized
DEBUG - 2014-01-02 12:42:35 --> Helper loaded: string_helper
DEBUG - 2014-01-02 12:42:35 --> Encrypt Class Initialized
DEBUG - 2014-01-02 12:42:35 --> Session routines successfully run
DEBUG - 2014-01-02 12:42:35 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 12:42:35 --> Model Class Initialized
DEBUG - 2014-01-02 12:42:35 --> Model Class Initialized
DEBUG - 2014-01-02 12:42:35 --> Model Class Initialized
ERROR - 2014-01-02 12:42:35 --> Severity: 4096  --> Object of class CI_Output could not be converted to string /var/www/mustang/application/controllers/api.php 61
DEBUG - 2014-01-02 12:42:35 --> Final output sent to browser
DEBUG - 2014-01-02 12:42:35 --> Total execution time: 0.0465
DEBUG - 2014-01-02 12:42:54 --> Config Class Initialized
DEBUG - 2014-01-02 12:42:54 --> Hooks Class Initialized
DEBUG - 2014-01-02 12:42:54 --> Utf8 Class Initialized
DEBUG - 2014-01-02 12:42:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 12:42:54 --> URI Class Initialized
DEBUG - 2014-01-02 12:42:54 --> Router Class Initialized
DEBUG - 2014-01-02 12:42:54 --> Output Class Initialized
DEBUG - 2014-01-02 12:42:54 --> Security Class Initialized
DEBUG - 2014-01-02 12:42:54 --> Input Class Initialized
DEBUG - 2014-01-02 12:42:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 12:42:54 --> Language Class Initialized
DEBUG - 2014-01-02 12:42:54 --> Loader Class Initialized
DEBUG - 2014-01-02 12:42:54 --> Helper loaded: url_helper
DEBUG - 2014-01-02 12:42:54 --> Helper loaded: common_helper
DEBUG - 2014-01-02 12:42:54 --> Database Driver Class Initialized
DEBUG - 2014-01-02 12:42:54 --> Controller Class Initialized
DEBUG - 2014-01-02 12:42:54 --> Session Class Initialized
DEBUG - 2014-01-02 12:42:54 --> Helper loaded: string_helper
DEBUG - 2014-01-02 12:42:54 --> Encrypt Class Initialized
DEBUG - 2014-01-02 12:42:54 --> Session routines successfully run
DEBUG - 2014-01-02 12:42:54 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 12:42:54 --> Model Class Initialized
DEBUG - 2014-01-02 12:42:54 --> Model Class Initialized
DEBUG - 2014-01-02 12:42:54 --> Model Class Initialized
DEBUG - 2014-01-02 12:42:54 --> Final output sent to browser
DEBUG - 2014-01-02 12:42:54 --> Total execution time: 0.0397
DEBUG - 2014-01-02 12:43:30 --> Config Class Initialized
DEBUG - 2014-01-02 12:43:30 --> Hooks Class Initialized
DEBUG - 2014-01-02 12:43:30 --> Utf8 Class Initialized
DEBUG - 2014-01-02 12:43:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 12:43:30 --> URI Class Initialized
DEBUG - 2014-01-02 12:43:30 --> Router Class Initialized
DEBUG - 2014-01-02 12:43:30 --> Output Class Initialized
DEBUG - 2014-01-02 12:43:30 --> Security Class Initialized
DEBUG - 2014-01-02 12:43:30 --> Input Class Initialized
DEBUG - 2014-01-02 12:43:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 12:43:30 --> Language Class Initialized
DEBUG - 2014-01-02 12:43:30 --> Loader Class Initialized
DEBUG - 2014-01-02 12:43:30 --> Helper loaded: url_helper
DEBUG - 2014-01-02 12:43:30 --> Helper loaded: common_helper
DEBUG - 2014-01-02 12:43:30 --> Database Driver Class Initialized
DEBUG - 2014-01-02 12:43:30 --> Controller Class Initialized
DEBUG - 2014-01-02 12:43:30 --> Session Class Initialized
DEBUG - 2014-01-02 12:43:30 --> Helper loaded: string_helper
DEBUG - 2014-01-02 12:43:30 --> Encrypt Class Initialized
DEBUG - 2014-01-02 12:43:30 --> Session routines successfully run
DEBUG - 2014-01-02 12:43:30 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 12:43:30 --> Model Class Initialized
DEBUG - 2014-01-02 12:43:30 --> Model Class Initialized
DEBUG - 2014-01-02 12:43:41 --> Config Class Initialized
DEBUG - 2014-01-02 12:43:41 --> Hooks Class Initialized
DEBUG - 2014-01-02 12:43:41 --> Utf8 Class Initialized
DEBUG - 2014-01-02 12:43:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 12:43:41 --> URI Class Initialized
DEBUG - 2014-01-02 12:43:41 --> Router Class Initialized
DEBUG - 2014-01-02 12:43:41 --> Output Class Initialized
DEBUG - 2014-01-02 12:43:41 --> Security Class Initialized
DEBUG - 2014-01-02 12:43:41 --> Input Class Initialized
DEBUG - 2014-01-02 12:43:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 12:43:41 --> Language Class Initialized
DEBUG - 2014-01-02 12:43:41 --> Loader Class Initialized
DEBUG - 2014-01-02 12:43:41 --> Helper loaded: url_helper
DEBUG - 2014-01-02 12:43:41 --> Helper loaded: common_helper
DEBUG - 2014-01-02 12:43:41 --> Database Driver Class Initialized
DEBUG - 2014-01-02 12:43:41 --> Controller Class Initialized
DEBUG - 2014-01-02 12:43:41 --> Session Class Initialized
DEBUG - 2014-01-02 12:43:41 --> Helper loaded: string_helper
DEBUG - 2014-01-02 12:43:41 --> Encrypt Class Initialized
DEBUG - 2014-01-02 12:43:41 --> Session routines successfully run
DEBUG - 2014-01-02 12:43:41 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 12:43:41 --> Model Class Initialized
DEBUG - 2014-01-02 12:43:41 --> Model Class Initialized
DEBUG - 2014-01-02 12:43:41 --> Model Class Initialized
DEBUG - 2014-01-02 12:43:41 --> Final output sent to browser
DEBUG - 2014-01-02 12:43:41 --> Total execution time: 0.0374
DEBUG - 2014-01-02 12:44:19 --> Config Class Initialized
DEBUG - 2014-01-02 12:44:19 --> Hooks Class Initialized
DEBUG - 2014-01-02 12:44:19 --> Utf8 Class Initialized
DEBUG - 2014-01-02 12:44:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 12:44:19 --> URI Class Initialized
DEBUG - 2014-01-02 12:44:19 --> Router Class Initialized
DEBUG - 2014-01-02 12:44:19 --> Output Class Initialized
DEBUG - 2014-01-02 12:44:19 --> Security Class Initialized
DEBUG - 2014-01-02 12:44:19 --> Input Class Initialized
DEBUG - 2014-01-02 12:44:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 12:44:19 --> Language Class Initialized
DEBUG - 2014-01-02 12:44:19 --> Loader Class Initialized
DEBUG - 2014-01-02 12:44:19 --> Helper loaded: url_helper
DEBUG - 2014-01-02 12:44:19 --> Helper loaded: common_helper
DEBUG - 2014-01-02 12:44:19 --> Database Driver Class Initialized
DEBUG - 2014-01-02 12:44:19 --> Controller Class Initialized
DEBUG - 2014-01-02 12:44:19 --> Session Class Initialized
DEBUG - 2014-01-02 12:44:19 --> Helper loaded: string_helper
DEBUG - 2014-01-02 12:44:20 --> Encrypt Class Initialized
DEBUG - 2014-01-02 12:44:20 --> Session routines successfully run
DEBUG - 2014-01-02 12:44:20 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 12:44:20 --> Model Class Initialized
DEBUG - 2014-01-02 12:44:20 --> Model Class Initialized
DEBUG - 2014-01-02 12:44:20 --> Model Class Initialized
DEBUG - 2014-01-02 12:44:20 --> Final output sent to browser
DEBUG - 2014-01-02 12:44:20 --> Total execution time: 0.0383
DEBUG - 2014-01-02 12:47:23 --> Config Class Initialized
DEBUG - 2014-01-02 12:47:23 --> Hooks Class Initialized
DEBUG - 2014-01-02 12:47:23 --> Utf8 Class Initialized
DEBUG - 2014-01-02 12:47:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 12:47:23 --> URI Class Initialized
DEBUG - 2014-01-02 12:47:23 --> Router Class Initialized
DEBUG - 2014-01-02 12:47:23 --> Output Class Initialized
DEBUG - 2014-01-02 12:47:23 --> Security Class Initialized
DEBUG - 2014-01-02 12:47:23 --> Input Class Initialized
DEBUG - 2014-01-02 12:47:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 12:47:23 --> Language Class Initialized
DEBUG - 2014-01-02 12:47:23 --> Loader Class Initialized
DEBUG - 2014-01-02 12:47:23 --> Helper loaded: url_helper
DEBUG - 2014-01-02 12:47:23 --> Helper loaded: common_helper
DEBUG - 2014-01-02 12:47:23 --> Database Driver Class Initialized
DEBUG - 2014-01-02 12:47:23 --> Controller Class Initialized
DEBUG - 2014-01-02 12:47:23 --> Session Class Initialized
DEBUG - 2014-01-02 12:47:23 --> Helper loaded: string_helper
DEBUG - 2014-01-02 12:47:23 --> Encrypt Class Initialized
DEBUG - 2014-01-02 12:47:23 --> Session routines successfully run
DEBUG - 2014-01-02 12:47:23 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 12:47:23 --> Model Class Initialized
DEBUG - 2014-01-02 12:47:23 --> Model Class Initialized
DEBUG - 2014-01-02 12:47:23 --> Model Class Initialized
DEBUG - 2014-01-02 12:47:23 --> Final output sent to browser
DEBUG - 2014-01-02 12:47:23 --> Total execution time: 0.0418
DEBUG - 2014-01-02 12:47:24 --> Config Class Initialized
DEBUG - 2014-01-02 12:47:24 --> Hooks Class Initialized
DEBUG - 2014-01-02 12:47:24 --> Utf8 Class Initialized
DEBUG - 2014-01-02 12:47:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 12:47:24 --> URI Class Initialized
DEBUG - 2014-01-02 12:47:24 --> Router Class Initialized
DEBUG - 2014-01-02 12:47:24 --> Output Class Initialized
DEBUG - 2014-01-02 12:47:24 --> Security Class Initialized
DEBUG - 2014-01-02 12:47:24 --> Input Class Initialized
DEBUG - 2014-01-02 12:47:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 12:47:24 --> Language Class Initialized
DEBUG - 2014-01-02 12:47:24 --> Loader Class Initialized
DEBUG - 2014-01-02 12:47:24 --> Helper loaded: url_helper
DEBUG - 2014-01-02 12:47:24 --> Helper loaded: common_helper
DEBUG - 2014-01-02 12:47:24 --> Database Driver Class Initialized
DEBUG - 2014-01-02 12:47:24 --> Controller Class Initialized
DEBUG - 2014-01-02 12:47:24 --> Session Class Initialized
DEBUG - 2014-01-02 12:47:24 --> Helper loaded: string_helper
DEBUG - 2014-01-02 12:47:24 --> Encrypt Class Initialized
DEBUG - 2014-01-02 12:47:24 --> Session routines successfully run
DEBUG - 2014-01-02 12:47:24 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 12:47:24 --> Model Class Initialized
DEBUG - 2014-01-02 12:47:24 --> Model Class Initialized
DEBUG - 2014-01-02 12:47:24 --> Model Class Initialized
DEBUG - 2014-01-02 12:47:24 --> Final output sent to browser
DEBUG - 2014-01-02 12:47:24 --> Total execution time: 0.0412
DEBUG - 2014-01-02 12:47:43 --> Config Class Initialized
DEBUG - 2014-01-02 12:47:43 --> Hooks Class Initialized
DEBUG - 2014-01-02 12:47:43 --> Utf8 Class Initialized
DEBUG - 2014-01-02 12:47:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 12:47:43 --> URI Class Initialized
DEBUG - 2014-01-02 12:47:43 --> Router Class Initialized
DEBUG - 2014-01-02 12:47:43 --> Output Class Initialized
DEBUG - 2014-01-02 12:47:43 --> Security Class Initialized
DEBUG - 2014-01-02 12:47:43 --> Input Class Initialized
DEBUG - 2014-01-02 12:47:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 12:47:43 --> Language Class Initialized
DEBUG - 2014-01-02 12:47:43 --> Loader Class Initialized
DEBUG - 2014-01-02 12:47:43 --> Helper loaded: url_helper
DEBUG - 2014-01-02 12:47:43 --> Helper loaded: common_helper
DEBUG - 2014-01-02 12:47:43 --> Database Driver Class Initialized
DEBUG - 2014-01-02 12:47:43 --> Controller Class Initialized
DEBUG - 2014-01-02 12:47:43 --> Session Class Initialized
DEBUG - 2014-01-02 12:47:43 --> Helper loaded: string_helper
DEBUG - 2014-01-02 12:47:43 --> Encrypt Class Initialized
DEBUG - 2014-01-02 12:47:43 --> Session routines successfully run
DEBUG - 2014-01-02 12:47:43 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 12:47:43 --> Model Class Initialized
DEBUG - 2014-01-02 12:47:43 --> Model Class Initialized
DEBUG - 2014-01-02 12:47:43 --> Model Class Initialized
DEBUG - 2014-01-02 12:47:43 --> Final output sent to browser
DEBUG - 2014-01-02 12:47:43 --> Total execution time: 0.0361
DEBUG - 2014-01-02 12:47:45 --> Config Class Initialized
DEBUG - 2014-01-02 12:47:45 --> Hooks Class Initialized
DEBUG - 2014-01-02 12:47:45 --> Utf8 Class Initialized
DEBUG - 2014-01-02 12:47:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 12:47:45 --> URI Class Initialized
DEBUG - 2014-01-02 12:47:45 --> Router Class Initialized
DEBUG - 2014-01-02 12:47:45 --> Output Class Initialized
DEBUG - 2014-01-02 12:47:45 --> Security Class Initialized
DEBUG - 2014-01-02 12:47:45 --> Input Class Initialized
DEBUG - 2014-01-02 12:47:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 12:47:45 --> Language Class Initialized
DEBUG - 2014-01-02 12:47:45 --> Loader Class Initialized
DEBUG - 2014-01-02 12:47:45 --> Helper loaded: url_helper
DEBUG - 2014-01-02 12:47:45 --> Helper loaded: common_helper
DEBUG - 2014-01-02 12:47:45 --> Database Driver Class Initialized
DEBUG - 2014-01-02 12:47:45 --> Controller Class Initialized
DEBUG - 2014-01-02 12:47:45 --> Session Class Initialized
DEBUG - 2014-01-02 12:47:45 --> Helper loaded: string_helper
DEBUG - 2014-01-02 12:47:45 --> Encrypt Class Initialized
DEBUG - 2014-01-02 12:47:45 --> Session routines successfully run
DEBUG - 2014-01-02 12:47:45 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 12:47:45 --> Model Class Initialized
DEBUG - 2014-01-02 12:47:45 --> Model Class Initialized
DEBUG - 2014-01-02 12:47:45 --> Model Class Initialized
DEBUG - 2014-01-02 12:47:45 --> Final output sent to browser
DEBUG - 2014-01-02 12:47:45 --> Total execution time: 0.0386
DEBUG - 2014-01-02 12:48:22 --> Config Class Initialized
DEBUG - 2014-01-02 12:48:22 --> Hooks Class Initialized
DEBUG - 2014-01-02 12:48:22 --> Utf8 Class Initialized
DEBUG - 2014-01-02 12:48:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 12:48:22 --> URI Class Initialized
DEBUG - 2014-01-02 12:48:22 --> Router Class Initialized
DEBUG - 2014-01-02 12:48:22 --> Output Class Initialized
DEBUG - 2014-01-02 12:48:22 --> Security Class Initialized
DEBUG - 2014-01-02 12:48:22 --> Input Class Initialized
DEBUG - 2014-01-02 12:48:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 12:48:22 --> Language Class Initialized
DEBUG - 2014-01-02 12:48:22 --> Loader Class Initialized
DEBUG - 2014-01-02 12:48:22 --> Helper loaded: url_helper
DEBUG - 2014-01-02 12:48:22 --> Helper loaded: common_helper
DEBUG - 2014-01-02 12:48:22 --> Database Driver Class Initialized
DEBUG - 2014-01-02 12:48:22 --> Controller Class Initialized
DEBUG - 2014-01-02 12:48:22 --> Session Class Initialized
DEBUG - 2014-01-02 12:48:22 --> Helper loaded: string_helper
DEBUG - 2014-01-02 12:48:22 --> Encrypt Class Initialized
DEBUG - 2014-01-02 12:48:22 --> Session routines successfully run
DEBUG - 2014-01-02 12:48:22 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 12:48:22 --> Model Class Initialized
DEBUG - 2014-01-02 12:48:22 --> Model Class Initialized
DEBUG - 2014-01-02 12:48:22 --> Model Class Initialized
DEBUG - 2014-01-02 12:48:47 --> Config Class Initialized
DEBUG - 2014-01-02 12:48:47 --> Hooks Class Initialized
DEBUG - 2014-01-02 12:48:47 --> Utf8 Class Initialized
DEBUG - 2014-01-02 12:48:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 12:48:47 --> URI Class Initialized
DEBUG - 2014-01-02 12:48:47 --> Router Class Initialized
DEBUG - 2014-01-02 12:48:47 --> Output Class Initialized
DEBUG - 2014-01-02 12:48:47 --> Security Class Initialized
DEBUG - 2014-01-02 12:48:47 --> Input Class Initialized
DEBUG - 2014-01-02 12:48:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 12:48:47 --> Language Class Initialized
DEBUG - 2014-01-02 12:48:47 --> Loader Class Initialized
DEBUG - 2014-01-02 12:48:47 --> Helper loaded: url_helper
DEBUG - 2014-01-02 12:48:47 --> Helper loaded: common_helper
DEBUG - 2014-01-02 12:48:47 --> Database Driver Class Initialized
DEBUG - 2014-01-02 12:48:47 --> Controller Class Initialized
DEBUG - 2014-01-02 12:48:47 --> Session Class Initialized
DEBUG - 2014-01-02 12:48:47 --> Helper loaded: string_helper
DEBUG - 2014-01-02 12:48:47 --> Encrypt Class Initialized
DEBUG - 2014-01-02 12:48:47 --> Session routines successfully run
DEBUG - 2014-01-02 12:48:47 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 12:48:47 --> Model Class Initialized
DEBUG - 2014-01-02 12:48:47 --> Model Class Initialized
DEBUG - 2014-01-02 12:48:47 --> Model Class Initialized
DEBUG - 2014-01-02 12:48:47 --> Final output sent to browser
DEBUG - 2014-01-02 12:48:47 --> Total execution time: 0.0343
DEBUG - 2014-01-02 16:58:14 --> Config Class Initialized
DEBUG - 2014-01-02 16:58:14 --> Hooks Class Initialized
DEBUG - 2014-01-02 16:58:14 --> Utf8 Class Initialized
DEBUG - 2014-01-02 16:58:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 16:58:14 --> URI Class Initialized
DEBUG - 2014-01-02 16:58:14 --> Router Class Initialized
DEBUG - 2014-01-02 16:58:14 --> Output Class Initialized
DEBUG - 2014-01-02 16:58:14 --> Security Class Initialized
DEBUG - 2014-01-02 16:58:14 --> Input Class Initialized
DEBUG - 2014-01-02 16:58:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 16:58:14 --> Language Class Initialized
DEBUG - 2014-01-02 16:58:14 --> Loader Class Initialized
DEBUG - 2014-01-02 16:58:14 --> Helper loaded: url_helper
DEBUG - 2014-01-02 16:58:14 --> Helper loaded: common_helper
DEBUG - 2014-01-02 16:58:14 --> Database Driver Class Initialized
DEBUG - 2014-01-02 16:58:14 --> Controller Class Initialized
DEBUG - 2014-01-02 16:58:14 --> Session Class Initialized
DEBUG - 2014-01-02 16:58:14 --> Helper loaded: string_helper
DEBUG - 2014-01-02 16:58:14 --> Encrypt Class Initialized
DEBUG - 2014-01-02 16:58:14 --> Session routines successfully run
DEBUG - 2014-01-02 16:58:14 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 16:58:14 --> Model Class Initialized
DEBUG - 2014-01-02 16:58:14 --> Model Class Initialized
DEBUG - 2014-01-02 16:58:14 --> Model Class Initialized
DEBUG - 2014-01-02 16:58:14 --> Final output sent to browser
DEBUG - 2014-01-02 16:58:14 --> Total execution time: 0.0355
DEBUG - 2014-01-02 16:59:09 --> Config Class Initialized
DEBUG - 2014-01-02 16:59:09 --> Hooks Class Initialized
DEBUG - 2014-01-02 16:59:09 --> Utf8 Class Initialized
DEBUG - 2014-01-02 16:59:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 16:59:09 --> URI Class Initialized
DEBUG - 2014-01-02 16:59:09 --> Router Class Initialized
DEBUG - 2014-01-02 16:59:09 --> Output Class Initialized
DEBUG - 2014-01-02 16:59:09 --> Security Class Initialized
DEBUG - 2014-01-02 16:59:09 --> Input Class Initialized
DEBUG - 2014-01-02 16:59:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 16:59:09 --> Language Class Initialized
DEBUG - 2014-01-02 16:59:09 --> Loader Class Initialized
DEBUG - 2014-01-02 16:59:09 --> Helper loaded: url_helper
DEBUG - 2014-01-02 16:59:09 --> Helper loaded: common_helper
DEBUG - 2014-01-02 16:59:09 --> Database Driver Class Initialized
DEBUG - 2014-01-02 16:59:09 --> Controller Class Initialized
DEBUG - 2014-01-02 16:59:09 --> Session Class Initialized
DEBUG - 2014-01-02 16:59:09 --> Helper loaded: string_helper
DEBUG - 2014-01-02 16:59:09 --> Encrypt Class Initialized
DEBUG - 2014-01-02 16:59:09 --> Session routines successfully run
DEBUG - 2014-01-02 16:59:09 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 16:59:09 --> Model Class Initialized
DEBUG - 2014-01-02 16:59:09 --> Model Class Initialized
DEBUG - 2014-01-02 16:59:09 --> Model Class Initialized
DEBUG - 2014-01-02 16:59:09 --> Final output sent to browser
DEBUG - 2014-01-02 16:59:09 --> Total execution time: 0.0351
DEBUG - 2014-01-02 17:19:21 --> Config Class Initialized
DEBUG - 2014-01-02 17:19:21 --> Hooks Class Initialized
DEBUG - 2014-01-02 17:19:21 --> Utf8 Class Initialized
DEBUG - 2014-01-02 17:19:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 17:19:21 --> URI Class Initialized
DEBUG - 2014-01-02 17:19:21 --> Router Class Initialized
DEBUG - 2014-01-02 17:19:21 --> Output Class Initialized
DEBUG - 2014-01-02 17:19:21 --> Security Class Initialized
DEBUG - 2014-01-02 17:19:21 --> Input Class Initialized
DEBUG - 2014-01-02 17:19:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 17:19:21 --> Language Class Initialized
DEBUG - 2014-01-02 17:19:21 --> Loader Class Initialized
DEBUG - 2014-01-02 17:19:21 --> Helper loaded: url_helper
DEBUG - 2014-01-02 17:19:21 --> Helper loaded: common_helper
DEBUG - 2014-01-02 17:19:21 --> Database Driver Class Initialized
DEBUG - 2014-01-02 17:19:21 --> Controller Class Initialized
DEBUG - 2014-01-02 17:19:21 --> Session Class Initialized
DEBUG - 2014-01-02 17:19:21 --> Helper loaded: string_helper
DEBUG - 2014-01-02 17:19:21 --> Encrypt Class Initialized
DEBUG - 2014-01-02 17:19:21 --> Session routines successfully run
DEBUG - 2014-01-02 17:19:21 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 17:19:21 --> Model Class Initialized
DEBUG - 2014-01-02 17:19:21 --> Model Class Initialized
DEBUG - 2014-01-02 17:19:21 --> Model Class Initialized
DEBUG - 2014-01-02 17:19:21 --> DB Transaction Failure
ERROR - 2014-01-02 17:19:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '?
            )' at line 9
DEBUG - 2014-01-02 17:19:21 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-02 17:19:50 --> Config Class Initialized
DEBUG - 2014-01-02 17:19:50 --> Hooks Class Initialized
DEBUG - 2014-01-02 17:19:50 --> Utf8 Class Initialized
DEBUG - 2014-01-02 17:19:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 17:19:50 --> URI Class Initialized
DEBUG - 2014-01-02 17:19:50 --> Router Class Initialized
DEBUG - 2014-01-02 17:19:50 --> Output Class Initialized
DEBUG - 2014-01-02 17:19:50 --> Security Class Initialized
DEBUG - 2014-01-02 17:19:50 --> Input Class Initialized
DEBUG - 2014-01-02 17:19:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 17:19:50 --> Language Class Initialized
DEBUG - 2014-01-02 17:19:50 --> Loader Class Initialized
DEBUG - 2014-01-02 17:19:50 --> Helper loaded: url_helper
DEBUG - 2014-01-02 17:19:50 --> Helper loaded: common_helper
DEBUG - 2014-01-02 17:19:50 --> Database Driver Class Initialized
DEBUG - 2014-01-02 17:19:50 --> Controller Class Initialized
DEBUG - 2014-01-02 17:19:50 --> Session Class Initialized
DEBUG - 2014-01-02 17:19:50 --> Helper loaded: string_helper
DEBUG - 2014-01-02 17:19:50 --> Encrypt Class Initialized
DEBUG - 2014-01-02 17:19:50 --> Session routines successfully run
DEBUG - 2014-01-02 17:19:50 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 17:19:50 --> Model Class Initialized
DEBUG - 2014-01-02 17:19:50 --> Model Class Initialized
DEBUG - 2014-01-02 17:19:50 --> Model Class Initialized
DEBUG - 2014-01-02 17:19:50 --> Final output sent to browser
DEBUG - 2014-01-02 17:19:50 --> Total execution time: 0.0370
DEBUG - 2014-01-02 17:20:59 --> Config Class Initialized
DEBUG - 2014-01-02 17:20:59 --> Hooks Class Initialized
DEBUG - 2014-01-02 17:20:59 --> Utf8 Class Initialized
DEBUG - 2014-01-02 17:20:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 17:20:59 --> URI Class Initialized
DEBUG - 2014-01-02 17:20:59 --> Router Class Initialized
DEBUG - 2014-01-02 17:20:59 --> Output Class Initialized
DEBUG - 2014-01-02 17:20:59 --> Security Class Initialized
DEBUG - 2014-01-02 17:20:59 --> Input Class Initialized
DEBUG - 2014-01-02 17:20:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 17:20:59 --> Language Class Initialized
DEBUG - 2014-01-02 17:20:59 --> Loader Class Initialized
DEBUG - 2014-01-02 17:20:59 --> Helper loaded: url_helper
DEBUG - 2014-01-02 17:20:59 --> Helper loaded: common_helper
DEBUG - 2014-01-02 17:20:59 --> Database Driver Class Initialized
DEBUG - 2014-01-02 17:20:59 --> Controller Class Initialized
DEBUG - 2014-01-02 17:20:59 --> Session Class Initialized
DEBUG - 2014-01-02 17:20:59 --> Helper loaded: string_helper
DEBUG - 2014-01-02 17:20:59 --> Encrypt Class Initialized
DEBUG - 2014-01-02 17:20:59 --> Session routines successfully run
DEBUG - 2014-01-02 17:20:59 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 17:20:59 --> Model Class Initialized
DEBUG - 2014-01-02 17:20:59 --> Model Class Initialized
DEBUG - 2014-01-02 17:20:59 --> Model Class Initialized
DEBUG - 2014-01-02 17:20:59 --> Final output sent to browser
DEBUG - 2014-01-02 17:20:59 --> Total execution time: 0.0418
DEBUG - 2014-01-02 17:22:39 --> Config Class Initialized
DEBUG - 2014-01-02 17:22:39 --> Hooks Class Initialized
DEBUG - 2014-01-02 17:22:39 --> Utf8 Class Initialized
DEBUG - 2014-01-02 17:22:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 17:22:39 --> URI Class Initialized
DEBUG - 2014-01-02 17:22:39 --> Router Class Initialized
DEBUG - 2014-01-02 17:22:39 --> Output Class Initialized
DEBUG - 2014-01-02 17:22:39 --> Security Class Initialized
DEBUG - 2014-01-02 17:22:39 --> Input Class Initialized
DEBUG - 2014-01-02 17:22:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 17:22:39 --> Language Class Initialized
DEBUG - 2014-01-02 17:22:39 --> Loader Class Initialized
DEBUG - 2014-01-02 17:22:39 --> Helper loaded: url_helper
DEBUG - 2014-01-02 17:22:39 --> Helper loaded: common_helper
DEBUG - 2014-01-02 17:22:39 --> Database Driver Class Initialized
DEBUG - 2014-01-02 17:22:39 --> Controller Class Initialized
DEBUG - 2014-01-02 17:22:39 --> Session Class Initialized
DEBUG - 2014-01-02 17:22:39 --> Helper loaded: string_helper
DEBUG - 2014-01-02 17:22:39 --> Encrypt Class Initialized
DEBUG - 2014-01-02 17:22:39 --> Session routines successfully run
DEBUG - 2014-01-02 17:22:39 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 17:25:55 --> Config Class Initialized
DEBUG - 2014-01-02 17:25:55 --> Hooks Class Initialized
DEBUG - 2014-01-02 17:25:55 --> Utf8 Class Initialized
DEBUG - 2014-01-02 17:25:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 17:25:55 --> URI Class Initialized
DEBUG - 2014-01-02 17:25:55 --> Router Class Initialized
DEBUG - 2014-01-02 17:25:55 --> Output Class Initialized
DEBUG - 2014-01-02 17:25:55 --> Security Class Initialized
DEBUG - 2014-01-02 17:25:55 --> Input Class Initialized
DEBUG - 2014-01-02 17:25:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 17:25:55 --> Language Class Initialized
DEBUG - 2014-01-02 17:25:55 --> Loader Class Initialized
DEBUG - 2014-01-02 17:25:55 --> Helper loaded: url_helper
DEBUG - 2014-01-02 17:25:55 --> Helper loaded: common_helper
DEBUG - 2014-01-02 17:25:55 --> Database Driver Class Initialized
DEBUG - 2014-01-02 17:25:55 --> Controller Class Initialized
DEBUG - 2014-01-02 17:25:55 --> Session Class Initialized
DEBUG - 2014-01-02 17:25:55 --> Helper loaded: string_helper
DEBUG - 2014-01-02 17:25:55 --> Encrypt Class Initialized
DEBUG - 2014-01-02 17:25:55 --> Session routines successfully run
DEBUG - 2014-01-02 17:25:55 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 17:25:55 --> Model Class Initialized
DEBUG - 2014-01-02 17:25:55 --> Model Class Initialized
DEBUG - 2014-01-02 17:26:44 --> Config Class Initialized
DEBUG - 2014-01-02 17:26:44 --> Hooks Class Initialized
DEBUG - 2014-01-02 17:26:44 --> Utf8 Class Initialized
DEBUG - 2014-01-02 17:26:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 17:26:44 --> URI Class Initialized
DEBUG - 2014-01-02 17:26:44 --> Router Class Initialized
DEBUG - 2014-01-02 17:26:44 --> Output Class Initialized
DEBUG - 2014-01-02 17:26:44 --> Security Class Initialized
DEBUG - 2014-01-02 17:26:44 --> Input Class Initialized
DEBUG - 2014-01-02 17:26:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 17:26:44 --> Language Class Initialized
DEBUG - 2014-01-02 17:26:44 --> Loader Class Initialized
DEBUG - 2014-01-02 17:26:44 --> Helper loaded: url_helper
DEBUG - 2014-01-02 17:26:44 --> Helper loaded: common_helper
DEBUG - 2014-01-02 17:26:44 --> Database Driver Class Initialized
DEBUG - 2014-01-02 17:26:44 --> Controller Class Initialized
DEBUG - 2014-01-02 17:26:44 --> Session Class Initialized
DEBUG - 2014-01-02 17:26:44 --> Helper loaded: string_helper
DEBUG - 2014-01-02 17:26:44 --> Encrypt Class Initialized
DEBUG - 2014-01-02 17:26:44 --> Session routines successfully run
DEBUG - 2014-01-02 17:26:44 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 17:26:44 --> Model Class Initialized
DEBUG - 2014-01-02 17:26:44 --> Model Class Initialized
DEBUG - 2014-01-02 17:26:44 --> Model Class Initialized
DEBUG - 2014-01-02 17:26:44 --> Final output sent to browser
DEBUG - 2014-01-02 17:26:44 --> Total execution time: 0.0361
DEBUG - 2014-01-02 17:27:19 --> Config Class Initialized
DEBUG - 2014-01-02 17:27:19 --> Hooks Class Initialized
DEBUG - 2014-01-02 17:27:19 --> Utf8 Class Initialized
DEBUG - 2014-01-02 17:27:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 17:27:19 --> URI Class Initialized
DEBUG - 2014-01-02 17:27:19 --> Router Class Initialized
DEBUG - 2014-01-02 17:27:19 --> Output Class Initialized
DEBUG - 2014-01-02 17:27:19 --> Security Class Initialized
DEBUG - 2014-01-02 17:27:19 --> Input Class Initialized
DEBUG - 2014-01-02 17:27:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 17:27:19 --> Language Class Initialized
DEBUG - 2014-01-02 17:27:19 --> Loader Class Initialized
DEBUG - 2014-01-02 17:27:19 --> Helper loaded: url_helper
DEBUG - 2014-01-02 17:27:19 --> Helper loaded: common_helper
DEBUG - 2014-01-02 17:27:19 --> Database Driver Class Initialized
DEBUG - 2014-01-02 17:27:19 --> Controller Class Initialized
DEBUG - 2014-01-02 17:27:19 --> Session Class Initialized
DEBUG - 2014-01-02 17:27:19 --> Helper loaded: string_helper
DEBUG - 2014-01-02 17:27:19 --> Encrypt Class Initialized
DEBUG - 2014-01-02 17:27:19 --> Session routines successfully run
DEBUG - 2014-01-02 17:27:19 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 17:27:19 --> Model Class Initialized
DEBUG - 2014-01-02 17:27:19 --> Model Class Initialized
DEBUG - 2014-01-02 17:27:19 --> Model Class Initialized
DEBUG - 2014-01-02 17:27:19 --> Final output sent to browser
DEBUG - 2014-01-02 17:27:19 --> Total execution time: 0.0388
DEBUG - 2014-01-02 17:27:21 --> Config Class Initialized
DEBUG - 2014-01-02 17:27:21 --> Hooks Class Initialized
DEBUG - 2014-01-02 17:27:21 --> Utf8 Class Initialized
DEBUG - 2014-01-02 17:27:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 17:27:21 --> URI Class Initialized
DEBUG - 2014-01-02 17:27:21 --> Router Class Initialized
DEBUG - 2014-01-02 17:27:21 --> Output Class Initialized
DEBUG - 2014-01-02 17:27:21 --> Security Class Initialized
DEBUG - 2014-01-02 17:27:21 --> Input Class Initialized
DEBUG - 2014-01-02 17:27:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 17:27:21 --> Language Class Initialized
DEBUG - 2014-01-02 17:27:21 --> Loader Class Initialized
DEBUG - 2014-01-02 17:27:21 --> Helper loaded: url_helper
DEBUG - 2014-01-02 17:27:21 --> Helper loaded: common_helper
DEBUG - 2014-01-02 17:27:21 --> Database Driver Class Initialized
DEBUG - 2014-01-02 17:27:21 --> Controller Class Initialized
DEBUG - 2014-01-02 17:27:21 --> Session Class Initialized
DEBUG - 2014-01-02 17:27:21 --> Helper loaded: string_helper
DEBUG - 2014-01-02 17:27:21 --> Encrypt Class Initialized
DEBUG - 2014-01-02 17:27:21 --> Session routines successfully run
DEBUG - 2014-01-02 17:27:21 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 17:27:21 --> Model Class Initialized
DEBUG - 2014-01-02 17:27:21 --> Model Class Initialized
DEBUG - 2014-01-02 17:27:21 --> Model Class Initialized
DEBUG - 2014-01-02 17:27:21 --> Final output sent to browser
DEBUG - 2014-01-02 17:27:21 --> Total execution time: 0.0421
DEBUG - 2014-01-02 17:27:46 --> Config Class Initialized
DEBUG - 2014-01-02 17:27:46 --> Hooks Class Initialized
DEBUG - 2014-01-02 17:27:46 --> Utf8 Class Initialized
DEBUG - 2014-01-02 17:27:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 17:27:46 --> URI Class Initialized
DEBUG - 2014-01-02 17:27:46 --> Router Class Initialized
DEBUG - 2014-01-02 17:27:46 --> Output Class Initialized
DEBUG - 2014-01-02 17:27:46 --> Security Class Initialized
DEBUG - 2014-01-02 17:27:46 --> Input Class Initialized
DEBUG - 2014-01-02 17:27:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 17:27:46 --> Language Class Initialized
DEBUG - 2014-01-02 17:27:46 --> Loader Class Initialized
DEBUG - 2014-01-02 17:27:46 --> Helper loaded: url_helper
DEBUG - 2014-01-02 17:27:46 --> Helper loaded: common_helper
DEBUG - 2014-01-02 17:27:46 --> Database Driver Class Initialized
DEBUG - 2014-01-02 17:27:46 --> Controller Class Initialized
DEBUG - 2014-01-02 17:27:46 --> Session Class Initialized
DEBUG - 2014-01-02 17:27:46 --> Helper loaded: string_helper
DEBUG - 2014-01-02 17:27:46 --> Encrypt Class Initialized
DEBUG - 2014-01-02 17:27:46 --> Session routines successfully run
DEBUG - 2014-01-02 17:27:46 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 17:27:46 --> Model Class Initialized
DEBUG - 2014-01-02 17:27:46 --> Model Class Initialized
DEBUG - 2014-01-02 17:27:46 --> Model Class Initialized
DEBUG - 2014-01-02 17:27:46 --> Final output sent to browser
DEBUG - 2014-01-02 17:27:46 --> Total execution time: 0.0380
DEBUG - 2014-01-02 17:27:51 --> Config Class Initialized
DEBUG - 2014-01-02 17:27:51 --> Hooks Class Initialized
DEBUG - 2014-01-02 17:27:51 --> Utf8 Class Initialized
DEBUG - 2014-01-02 17:27:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 17:27:51 --> URI Class Initialized
DEBUG - 2014-01-02 17:27:51 --> Router Class Initialized
DEBUG - 2014-01-02 17:27:51 --> Output Class Initialized
DEBUG - 2014-01-02 17:27:51 --> Security Class Initialized
DEBUG - 2014-01-02 17:27:51 --> Input Class Initialized
DEBUG - 2014-01-02 17:27:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 17:27:51 --> Language Class Initialized
DEBUG - 2014-01-02 17:27:51 --> Loader Class Initialized
DEBUG - 2014-01-02 17:27:51 --> Helper loaded: url_helper
DEBUG - 2014-01-02 17:27:51 --> Helper loaded: common_helper
DEBUG - 2014-01-02 17:27:51 --> Database Driver Class Initialized
DEBUG - 2014-01-02 17:27:51 --> Controller Class Initialized
DEBUG - 2014-01-02 17:27:51 --> Session Class Initialized
DEBUG - 2014-01-02 17:27:51 --> Helper loaded: string_helper
DEBUG - 2014-01-02 17:27:51 --> Encrypt Class Initialized
DEBUG - 2014-01-02 17:27:51 --> Session routines successfully run
DEBUG - 2014-01-02 17:27:51 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 17:27:51 --> Model Class Initialized
DEBUG - 2014-01-02 17:27:51 --> Model Class Initialized
DEBUG - 2014-01-02 17:29:05 --> Config Class Initialized
DEBUG - 2014-01-02 17:29:05 --> Hooks Class Initialized
DEBUG - 2014-01-02 17:29:05 --> Utf8 Class Initialized
DEBUG - 2014-01-02 17:29:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 17:29:05 --> URI Class Initialized
DEBUG - 2014-01-02 17:29:05 --> Router Class Initialized
DEBUG - 2014-01-02 17:29:05 --> Output Class Initialized
DEBUG - 2014-01-02 17:29:05 --> Security Class Initialized
DEBUG - 2014-01-02 17:29:05 --> Input Class Initialized
DEBUG - 2014-01-02 17:29:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 17:29:05 --> Language Class Initialized
DEBUG - 2014-01-02 17:29:05 --> Loader Class Initialized
DEBUG - 2014-01-02 17:29:05 --> Helper loaded: url_helper
DEBUG - 2014-01-02 17:29:05 --> Helper loaded: common_helper
DEBUG - 2014-01-02 17:29:05 --> Database Driver Class Initialized
DEBUG - 2014-01-02 17:29:05 --> Controller Class Initialized
DEBUG - 2014-01-02 17:29:05 --> Session Class Initialized
DEBUG - 2014-01-02 17:29:05 --> Helper loaded: string_helper
DEBUG - 2014-01-02 17:29:05 --> Encrypt Class Initialized
DEBUG - 2014-01-02 17:29:05 --> Session routines successfully run
DEBUG - 2014-01-02 17:29:05 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 17:29:05 --> Model Class Initialized
DEBUG - 2014-01-02 17:29:05 --> Model Class Initialized
ERROR - 2014-01-02 17:29:05 --> Severity: Notice  --> Undefined property: CI_DB_mysql_driver::$lastsql /var/www/mustang/application/models/mtrmlequip.php 21
DEBUG - 2014-01-02 17:30:36 --> Config Class Initialized
DEBUG - 2014-01-02 17:30:36 --> Hooks Class Initialized
DEBUG - 2014-01-02 17:30:36 --> Utf8 Class Initialized
DEBUG - 2014-01-02 17:30:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 17:30:36 --> URI Class Initialized
DEBUG - 2014-01-02 17:30:36 --> Router Class Initialized
DEBUG - 2014-01-02 17:30:36 --> Output Class Initialized
DEBUG - 2014-01-02 17:30:36 --> Security Class Initialized
DEBUG - 2014-01-02 17:30:36 --> Input Class Initialized
DEBUG - 2014-01-02 17:30:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 17:30:36 --> Language Class Initialized
DEBUG - 2014-01-02 17:30:36 --> Loader Class Initialized
DEBUG - 2014-01-02 17:30:36 --> Helper loaded: url_helper
DEBUG - 2014-01-02 17:30:36 --> Helper loaded: common_helper
DEBUG - 2014-01-02 17:30:36 --> Database Driver Class Initialized
DEBUG - 2014-01-02 17:30:36 --> Controller Class Initialized
DEBUG - 2014-01-02 17:30:36 --> Session Class Initialized
DEBUG - 2014-01-02 17:30:36 --> Helper loaded: string_helper
DEBUG - 2014-01-02 17:30:36 --> Encrypt Class Initialized
DEBUG - 2014-01-02 17:30:36 --> Session routines successfully run
DEBUG - 2014-01-02 17:30:36 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 17:30:36 --> Model Class Initialized
DEBUG - 2014-01-02 17:30:36 --> Model Class Initialized
DEBUG - 2014-01-02 17:31:11 --> Config Class Initialized
DEBUG - 2014-01-02 17:31:11 --> Hooks Class Initialized
DEBUG - 2014-01-02 17:31:11 --> Utf8 Class Initialized
DEBUG - 2014-01-02 17:31:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 17:31:11 --> URI Class Initialized
DEBUG - 2014-01-02 17:31:11 --> Router Class Initialized
DEBUG - 2014-01-02 17:31:11 --> Output Class Initialized
DEBUG - 2014-01-02 17:31:11 --> Security Class Initialized
DEBUG - 2014-01-02 17:31:11 --> Input Class Initialized
DEBUG - 2014-01-02 17:31:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 17:31:11 --> Language Class Initialized
DEBUG - 2014-01-02 17:31:11 --> Loader Class Initialized
DEBUG - 2014-01-02 17:31:11 --> Helper loaded: url_helper
DEBUG - 2014-01-02 17:31:11 --> Helper loaded: common_helper
DEBUG - 2014-01-02 17:31:11 --> Database Driver Class Initialized
DEBUG - 2014-01-02 17:31:11 --> Controller Class Initialized
DEBUG - 2014-01-02 17:31:11 --> Session Class Initialized
DEBUG - 2014-01-02 17:31:11 --> Helper loaded: string_helper
DEBUG - 2014-01-02 17:31:11 --> Encrypt Class Initialized
DEBUG - 2014-01-02 17:31:11 --> Session routines successfully run
DEBUG - 2014-01-02 17:31:11 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 17:31:11 --> Model Class Initialized
DEBUG - 2014-01-02 17:31:11 --> Model Class Initialized
DEBUG - 2014-01-02 17:31:14 --> Config Class Initialized
DEBUG - 2014-01-02 17:31:14 --> Hooks Class Initialized
DEBUG - 2014-01-02 17:31:14 --> Utf8 Class Initialized
DEBUG - 2014-01-02 17:31:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 17:31:14 --> URI Class Initialized
DEBUG - 2014-01-02 17:31:14 --> Router Class Initialized
DEBUG - 2014-01-02 17:31:14 --> Output Class Initialized
DEBUG - 2014-01-02 17:31:14 --> Security Class Initialized
DEBUG - 2014-01-02 17:31:14 --> Input Class Initialized
DEBUG - 2014-01-02 17:31:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 17:31:14 --> Language Class Initialized
DEBUG - 2014-01-02 17:31:14 --> Loader Class Initialized
DEBUG - 2014-01-02 17:31:14 --> Helper loaded: url_helper
DEBUG - 2014-01-02 17:31:14 --> Helper loaded: common_helper
DEBUG - 2014-01-02 17:31:14 --> Database Driver Class Initialized
DEBUG - 2014-01-02 17:31:15 --> Controller Class Initialized
DEBUG - 2014-01-02 17:31:15 --> Session Class Initialized
DEBUG - 2014-01-02 17:31:15 --> Helper loaded: string_helper
DEBUG - 2014-01-02 17:31:15 --> Encrypt Class Initialized
DEBUG - 2014-01-02 17:31:15 --> Session routines successfully run
DEBUG - 2014-01-02 17:31:15 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 17:31:15 --> Model Class Initialized
DEBUG - 2014-01-02 17:31:15 --> Model Class Initialized
DEBUG - 2014-01-02 17:31:15 --> Final output sent to browser
DEBUG - 2014-01-02 17:31:15 --> Total execution time: 0.0196
DEBUG - 2014-01-02 17:31:20 --> Config Class Initialized
DEBUG - 2014-01-02 17:31:20 --> Hooks Class Initialized
DEBUG - 2014-01-02 17:31:20 --> Utf8 Class Initialized
DEBUG - 2014-01-02 17:31:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 17:31:20 --> URI Class Initialized
DEBUG - 2014-01-02 17:31:20 --> Router Class Initialized
DEBUG - 2014-01-02 17:31:20 --> Output Class Initialized
DEBUG - 2014-01-02 17:31:20 --> Security Class Initialized
DEBUG - 2014-01-02 17:31:20 --> Input Class Initialized
DEBUG - 2014-01-02 17:31:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 17:31:20 --> Language Class Initialized
DEBUG - 2014-01-02 17:31:20 --> Loader Class Initialized
DEBUG - 2014-01-02 17:31:20 --> Helper loaded: url_helper
DEBUG - 2014-01-02 17:31:20 --> Helper loaded: common_helper
DEBUG - 2014-01-02 17:31:20 --> Database Driver Class Initialized
DEBUG - 2014-01-02 17:31:20 --> Controller Class Initialized
DEBUG - 2014-01-02 17:31:20 --> Session Class Initialized
DEBUG - 2014-01-02 17:31:20 --> Helper loaded: string_helper
DEBUG - 2014-01-02 17:31:20 --> Encrypt Class Initialized
DEBUG - 2014-01-02 17:31:20 --> Session routines successfully run
DEBUG - 2014-01-02 17:31:20 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 17:31:20 --> Model Class Initialized
DEBUG - 2014-01-02 17:31:20 --> Model Class Initialized
DEBUG - 2014-01-02 17:31:20 --> Model Class Initialized
DEBUG - 2014-01-02 17:31:20 --> Final output sent to browser
DEBUG - 2014-01-02 17:31:20 --> Total execution time: 0.0382
DEBUG - 2014-01-02 17:42:32 --> Config Class Initialized
DEBUG - 2014-01-02 17:42:32 --> Hooks Class Initialized
DEBUG - 2014-01-02 17:42:32 --> Utf8 Class Initialized
DEBUG - 2014-01-02 17:42:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 17:42:32 --> URI Class Initialized
DEBUG - 2014-01-02 17:42:32 --> Router Class Initialized
DEBUG - 2014-01-02 17:42:32 --> Output Class Initialized
DEBUG - 2014-01-02 17:42:32 --> Security Class Initialized
DEBUG - 2014-01-02 17:42:32 --> Input Class Initialized
DEBUG - 2014-01-02 17:42:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 17:42:32 --> Language Class Initialized
DEBUG - 2014-01-02 17:42:32 --> Loader Class Initialized
DEBUG - 2014-01-02 17:42:32 --> Helper loaded: url_helper
DEBUG - 2014-01-02 17:42:32 --> Helper loaded: common_helper
DEBUG - 2014-01-02 17:42:32 --> Database Driver Class Initialized
DEBUG - 2014-01-02 17:42:32 --> Controller Class Initialized
DEBUG - 2014-01-02 17:42:32 --> Session Class Initialized
DEBUG - 2014-01-02 17:42:32 --> Helper loaded: string_helper
DEBUG - 2014-01-02 17:42:32 --> Encrypt Class Initialized
DEBUG - 2014-01-02 17:42:32 --> Session routines successfully run
DEBUG - 2014-01-02 17:42:32 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 17:42:32 --> Model Class Initialized
DEBUG - 2014-01-02 17:42:32 --> Model Class Initialized
DEBUG - 2014-01-02 17:42:32 --> Model Class Initialized
DEBUG - 2014-01-02 17:42:32 --> Final output sent to browser
DEBUG - 2014-01-02 17:42:32 --> Total execution time: 0.0392
DEBUG - 2014-01-02 17:42:40 --> Config Class Initialized
DEBUG - 2014-01-02 17:42:40 --> Hooks Class Initialized
DEBUG - 2014-01-02 17:42:40 --> Utf8 Class Initialized
DEBUG - 2014-01-02 17:42:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 17:42:40 --> URI Class Initialized
DEBUG - 2014-01-02 17:42:40 --> Router Class Initialized
DEBUG - 2014-01-02 17:42:40 --> Output Class Initialized
DEBUG - 2014-01-02 17:42:40 --> Security Class Initialized
DEBUG - 2014-01-02 17:42:40 --> Input Class Initialized
DEBUG - 2014-01-02 17:42:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 17:42:40 --> Language Class Initialized
DEBUG - 2014-01-02 17:42:40 --> Loader Class Initialized
DEBUG - 2014-01-02 17:42:40 --> Helper loaded: url_helper
DEBUG - 2014-01-02 17:42:40 --> Helper loaded: common_helper
DEBUG - 2014-01-02 17:42:40 --> Database Driver Class Initialized
DEBUG - 2014-01-02 17:42:40 --> Controller Class Initialized
DEBUG - 2014-01-02 17:42:40 --> Session Class Initialized
DEBUG - 2014-01-02 17:42:40 --> Helper loaded: string_helper
DEBUG - 2014-01-02 17:42:40 --> Encrypt Class Initialized
DEBUG - 2014-01-02 17:42:40 --> Session routines successfully run
DEBUG - 2014-01-02 17:42:40 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 17:42:40 --> Model Class Initialized
DEBUG - 2014-01-02 17:42:40 --> Model Class Initialized
DEBUG - 2014-01-02 17:42:40 --> Model Class Initialized
DEBUG - 2014-01-02 17:42:40 --> Final output sent to browser
DEBUG - 2014-01-02 17:42:40 --> Total execution time: 0.0360
DEBUG - 2014-01-02 17:43:10 --> Config Class Initialized
DEBUG - 2014-01-02 17:43:10 --> Hooks Class Initialized
DEBUG - 2014-01-02 17:43:10 --> Utf8 Class Initialized
DEBUG - 2014-01-02 17:43:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 17:43:10 --> URI Class Initialized
DEBUG - 2014-01-02 17:43:10 --> Router Class Initialized
DEBUG - 2014-01-02 17:43:10 --> Output Class Initialized
DEBUG - 2014-01-02 17:43:10 --> Security Class Initialized
DEBUG - 2014-01-02 17:43:10 --> Input Class Initialized
DEBUG - 2014-01-02 17:43:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 17:43:10 --> Language Class Initialized
DEBUG - 2014-01-02 17:43:10 --> Loader Class Initialized
DEBUG - 2014-01-02 17:43:10 --> Helper loaded: url_helper
DEBUG - 2014-01-02 17:43:10 --> Helper loaded: common_helper
DEBUG - 2014-01-02 17:43:10 --> Database Driver Class Initialized
DEBUG - 2014-01-02 17:43:10 --> Controller Class Initialized
DEBUG - 2014-01-02 17:43:10 --> Session Class Initialized
DEBUG - 2014-01-02 17:43:10 --> Helper loaded: string_helper
DEBUG - 2014-01-02 17:43:10 --> Encrypt Class Initialized
DEBUG - 2014-01-02 17:43:10 --> Session routines successfully run
DEBUG - 2014-01-02 17:43:10 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 17:43:10 --> Model Class Initialized
DEBUG - 2014-01-02 17:43:10 --> Model Class Initialized
DEBUG - 2014-01-02 17:43:10 --> Model Class Initialized
DEBUG - 2014-01-02 17:43:10 --> Final output sent to browser
DEBUG - 2014-01-02 17:43:10 --> Total execution time: 0.0373
DEBUG - 2014-01-02 17:44:19 --> Config Class Initialized
DEBUG - 2014-01-02 17:44:19 --> Hooks Class Initialized
DEBUG - 2014-01-02 17:44:19 --> Utf8 Class Initialized
DEBUG - 2014-01-02 17:44:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 17:44:19 --> URI Class Initialized
DEBUG - 2014-01-02 17:44:19 --> Router Class Initialized
DEBUG - 2014-01-02 17:44:19 --> Output Class Initialized
DEBUG - 2014-01-02 17:44:19 --> Security Class Initialized
DEBUG - 2014-01-02 17:44:19 --> Input Class Initialized
DEBUG - 2014-01-02 17:44:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 17:44:19 --> Language Class Initialized
DEBUG - 2014-01-02 17:44:19 --> Loader Class Initialized
DEBUG - 2014-01-02 17:44:19 --> Helper loaded: url_helper
DEBUG - 2014-01-02 17:44:19 --> Helper loaded: common_helper
DEBUG - 2014-01-02 17:44:19 --> Database Driver Class Initialized
DEBUG - 2014-01-02 17:44:19 --> Controller Class Initialized
DEBUG - 2014-01-02 17:44:19 --> Session Class Initialized
DEBUG - 2014-01-02 17:44:19 --> Helper loaded: string_helper
DEBUG - 2014-01-02 17:44:19 --> Encrypt Class Initialized
DEBUG - 2014-01-02 17:44:19 --> Session routines successfully run
DEBUG - 2014-01-02 17:44:19 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 17:44:19 --> Model Class Initialized
DEBUG - 2014-01-02 17:44:19 --> Model Class Initialized
ERROR - 2014-01-02 17:44:19 --> Severity: Notice  --> Undefined property: stdClass::$STORE_CODE /var/www/mustang/application/controllers/api.php 26
DEBUG - 2014-01-02 17:44:19 --> Final output sent to browser
DEBUG - 2014-01-02 17:44:19 --> Total execution time: 0.0356
DEBUG - 2014-01-02 17:45:00 --> Config Class Initialized
DEBUG - 2014-01-02 17:45:00 --> Hooks Class Initialized
DEBUG - 2014-01-02 17:45:00 --> Utf8 Class Initialized
DEBUG - 2014-01-02 17:45:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 17:45:00 --> URI Class Initialized
DEBUG - 2014-01-02 17:45:00 --> Router Class Initialized
DEBUG - 2014-01-02 17:45:00 --> Output Class Initialized
DEBUG - 2014-01-02 17:45:00 --> Security Class Initialized
DEBUG - 2014-01-02 17:45:00 --> Input Class Initialized
DEBUG - 2014-01-02 17:45:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 17:45:00 --> Language Class Initialized
DEBUG - 2014-01-02 17:45:00 --> Loader Class Initialized
DEBUG - 2014-01-02 17:45:00 --> Helper loaded: url_helper
DEBUG - 2014-01-02 17:45:00 --> Helper loaded: common_helper
DEBUG - 2014-01-02 17:45:00 --> Database Driver Class Initialized
DEBUG - 2014-01-02 17:45:00 --> Controller Class Initialized
DEBUG - 2014-01-02 17:45:00 --> Session Class Initialized
DEBUG - 2014-01-02 17:45:00 --> Helper loaded: string_helper
DEBUG - 2014-01-02 17:45:00 --> Encrypt Class Initialized
DEBUG - 2014-01-02 17:45:00 --> Session routines successfully run
DEBUG - 2014-01-02 17:45:00 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 17:45:00 --> Model Class Initialized
DEBUG - 2014-01-02 17:45:00 --> Model Class Initialized
DEBUG - 2014-01-02 17:49:20 --> Config Class Initialized
DEBUG - 2014-01-02 17:49:20 --> Hooks Class Initialized
DEBUG - 2014-01-02 17:49:20 --> Utf8 Class Initialized
DEBUG - 2014-01-02 17:49:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 17:49:20 --> URI Class Initialized
DEBUG - 2014-01-02 17:49:20 --> Router Class Initialized
DEBUG - 2014-01-02 17:49:20 --> Output Class Initialized
DEBUG - 2014-01-02 17:49:20 --> Security Class Initialized
DEBUG - 2014-01-02 17:49:20 --> Input Class Initialized
DEBUG - 2014-01-02 17:49:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 17:49:20 --> Language Class Initialized
DEBUG - 2014-01-02 17:49:20 --> Loader Class Initialized
DEBUG - 2014-01-02 17:49:20 --> Helper loaded: url_helper
DEBUG - 2014-01-02 17:49:20 --> Helper loaded: common_helper
DEBUG - 2014-01-02 17:49:20 --> Database Driver Class Initialized
DEBUG - 2014-01-02 17:49:20 --> Controller Class Initialized
DEBUG - 2014-01-02 17:49:20 --> Session Class Initialized
DEBUG - 2014-01-02 17:49:20 --> Helper loaded: string_helper
DEBUG - 2014-01-02 17:49:20 --> Encrypt Class Initialized
DEBUG - 2014-01-02 17:49:20 --> Session routines successfully run
DEBUG - 2014-01-02 17:49:20 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 17:49:20 --> Model Class Initialized
DEBUG - 2014-01-02 17:49:20 --> Model Class Initialized
DEBUG - 2014-01-02 17:49:20 --> Model Class Initialized
DEBUG - 2014-01-02 17:49:20 --> Final output sent to browser
DEBUG - 2014-01-02 17:49:20 --> Total execution time: 0.0358
DEBUG - 2014-01-02 17:49:25 --> Config Class Initialized
DEBUG - 2014-01-02 17:49:25 --> Hooks Class Initialized
DEBUG - 2014-01-02 17:49:25 --> Utf8 Class Initialized
DEBUG - 2014-01-02 17:49:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 17:49:25 --> URI Class Initialized
DEBUG - 2014-01-02 17:49:25 --> Router Class Initialized
DEBUG - 2014-01-02 17:49:25 --> Output Class Initialized
DEBUG - 2014-01-02 17:49:25 --> Security Class Initialized
DEBUG - 2014-01-02 17:49:25 --> Input Class Initialized
DEBUG - 2014-01-02 17:49:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 17:49:25 --> Language Class Initialized
DEBUG - 2014-01-02 17:49:25 --> Loader Class Initialized
DEBUG - 2014-01-02 17:49:25 --> Helper loaded: url_helper
DEBUG - 2014-01-02 17:49:25 --> Helper loaded: common_helper
DEBUG - 2014-01-02 17:49:25 --> Database Driver Class Initialized
DEBUG - 2014-01-02 17:49:25 --> Controller Class Initialized
DEBUG - 2014-01-02 17:49:25 --> Session Class Initialized
DEBUG - 2014-01-02 17:49:25 --> Helper loaded: string_helper
DEBUG - 2014-01-02 17:49:25 --> Encrypt Class Initialized
DEBUG - 2014-01-02 17:49:25 --> Session routines successfully run
DEBUG - 2014-01-02 17:49:25 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 17:49:25 --> Model Class Initialized
DEBUG - 2014-01-02 17:49:25 --> Model Class Initialized
DEBUG - 2014-01-02 17:49:25 --> Final output sent to browser
DEBUG - 2014-01-02 17:49:25 --> Total execution time: 0.0335
DEBUG - 2014-01-02 17:49:28 --> Config Class Initialized
DEBUG - 2014-01-02 17:49:28 --> Hooks Class Initialized
DEBUG - 2014-01-02 17:49:28 --> Utf8 Class Initialized
DEBUG - 2014-01-02 17:49:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 17:49:28 --> URI Class Initialized
DEBUG - 2014-01-02 17:49:28 --> Router Class Initialized
DEBUG - 2014-01-02 17:49:28 --> Output Class Initialized
DEBUG - 2014-01-02 17:49:28 --> Security Class Initialized
DEBUG - 2014-01-02 17:49:28 --> Input Class Initialized
DEBUG - 2014-01-02 17:49:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 17:49:28 --> Language Class Initialized
DEBUG - 2014-01-02 17:49:28 --> Loader Class Initialized
DEBUG - 2014-01-02 17:49:28 --> Helper loaded: url_helper
DEBUG - 2014-01-02 17:49:28 --> Helper loaded: common_helper
DEBUG - 2014-01-02 17:49:28 --> Database Driver Class Initialized
DEBUG - 2014-01-02 17:49:28 --> Controller Class Initialized
DEBUG - 2014-01-02 17:49:28 --> Session Class Initialized
DEBUG - 2014-01-02 17:49:28 --> Helper loaded: string_helper
DEBUG - 2014-01-02 17:49:28 --> Encrypt Class Initialized
DEBUG - 2014-01-02 17:49:28 --> Session routines successfully run
DEBUG - 2014-01-02 17:49:28 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 17:49:28 --> Model Class Initialized
DEBUG - 2014-01-02 17:49:28 --> Model Class Initialized
DEBUG - 2014-01-02 17:49:28 --> Model Class Initialized
DEBUG - 2014-01-02 17:49:28 --> Final output sent to browser
DEBUG - 2014-01-02 17:49:28 --> Total execution time: 0.0402
DEBUG - 2014-01-02 17:57:13 --> Config Class Initialized
DEBUG - 2014-01-02 17:57:13 --> Hooks Class Initialized
DEBUG - 2014-01-02 17:57:13 --> Utf8 Class Initialized
DEBUG - 2014-01-02 17:57:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 17:57:13 --> URI Class Initialized
DEBUG - 2014-01-02 17:57:13 --> Router Class Initialized
DEBUG - 2014-01-02 17:57:13 --> Output Class Initialized
DEBUG - 2014-01-02 17:57:13 --> Security Class Initialized
DEBUG - 2014-01-02 17:57:13 --> Input Class Initialized
DEBUG - 2014-01-02 17:57:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 17:57:13 --> Language Class Initialized
DEBUG - 2014-01-02 17:57:13 --> Loader Class Initialized
DEBUG - 2014-01-02 17:57:13 --> Helper loaded: url_helper
DEBUG - 2014-01-02 17:57:13 --> Helper loaded: common_helper
DEBUG - 2014-01-02 17:57:13 --> Database Driver Class Initialized
DEBUG - 2014-01-02 17:57:13 --> Controller Class Initialized
DEBUG - 2014-01-02 17:57:13 --> Session Class Initialized
DEBUG - 2014-01-02 17:57:13 --> Helper loaded: string_helper
DEBUG - 2014-01-02 17:57:13 --> Encrypt Class Initialized
DEBUG - 2014-01-02 17:57:13 --> Session routines successfully run
DEBUG - 2014-01-02 17:57:13 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 17:57:13 --> Model Class Initialized
DEBUG - 2014-01-02 17:57:13 --> Model Class Initialized
DEBUG - 2014-01-02 17:57:13 --> Model Class Initialized
DEBUG - 2014-01-02 17:57:13 --> DB Transaction Failure
ERROR - 2014-01-02 17:57:13 --> Query error: Unknown column 'S.SEC_OID' in 'field list'
DEBUG - 2014-01-02 17:57:13 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-02 17:57:58 --> Config Class Initialized
DEBUG - 2014-01-02 17:57:58 --> Hooks Class Initialized
DEBUG - 2014-01-02 17:57:58 --> Utf8 Class Initialized
DEBUG - 2014-01-02 17:57:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 17:57:58 --> URI Class Initialized
DEBUG - 2014-01-02 17:57:58 --> Router Class Initialized
DEBUG - 2014-01-02 17:57:58 --> Output Class Initialized
DEBUG - 2014-01-02 17:57:58 --> Security Class Initialized
DEBUG - 2014-01-02 17:57:58 --> Input Class Initialized
DEBUG - 2014-01-02 17:57:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 17:57:58 --> Language Class Initialized
DEBUG - 2014-01-02 17:57:58 --> Loader Class Initialized
DEBUG - 2014-01-02 17:57:58 --> Helper loaded: url_helper
DEBUG - 2014-01-02 17:57:58 --> Helper loaded: common_helper
DEBUG - 2014-01-02 17:57:58 --> Database Driver Class Initialized
DEBUG - 2014-01-02 17:57:58 --> Controller Class Initialized
DEBUG - 2014-01-02 17:57:58 --> Session Class Initialized
DEBUG - 2014-01-02 17:57:58 --> Helper loaded: string_helper
DEBUG - 2014-01-02 17:57:58 --> Encrypt Class Initialized
DEBUG - 2014-01-02 17:57:58 --> Session routines successfully run
DEBUG - 2014-01-02 17:57:58 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 17:57:58 --> Model Class Initialized
DEBUG - 2014-01-02 17:57:58 --> Model Class Initialized
DEBUG - 2014-01-02 17:57:58 --> Model Class Initialized
DEBUG - 2014-01-02 17:57:58 --> DB Transaction Failure
ERROR - 2014-01-02 17:57:58 --> Query error: Unknown column 'SLC.SEC_OID' in 'field list'
DEBUG - 2014-01-02 17:57:58 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-02 17:58:42 --> Config Class Initialized
DEBUG - 2014-01-02 17:58:42 --> Hooks Class Initialized
DEBUG - 2014-01-02 17:58:42 --> Utf8 Class Initialized
DEBUG - 2014-01-02 17:58:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 17:58:42 --> URI Class Initialized
DEBUG - 2014-01-02 17:58:42 --> Router Class Initialized
DEBUG - 2014-01-02 17:58:42 --> Output Class Initialized
DEBUG - 2014-01-02 17:58:42 --> Security Class Initialized
DEBUG - 2014-01-02 17:58:42 --> Input Class Initialized
DEBUG - 2014-01-02 17:58:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 17:58:42 --> Language Class Initialized
DEBUG - 2014-01-02 17:58:42 --> Loader Class Initialized
DEBUG - 2014-01-02 17:58:42 --> Helper loaded: url_helper
DEBUG - 2014-01-02 17:58:42 --> Helper loaded: common_helper
DEBUG - 2014-01-02 17:58:42 --> Database Driver Class Initialized
DEBUG - 2014-01-02 17:58:42 --> Controller Class Initialized
DEBUG - 2014-01-02 17:58:42 --> Session Class Initialized
DEBUG - 2014-01-02 17:58:42 --> Helper loaded: string_helper
DEBUG - 2014-01-02 17:58:42 --> Encrypt Class Initialized
DEBUG - 2014-01-02 17:58:42 --> Session routines successfully run
DEBUG - 2014-01-02 17:58:42 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 17:58:42 --> Model Class Initialized
DEBUG - 2014-01-02 17:58:42 --> Model Class Initialized
DEBUG - 2014-01-02 17:58:42 --> Model Class Initialized
DEBUG - 2014-01-02 17:58:42 --> DB Transaction Failure
ERROR - 2014-01-02 17:58:42 --> Query error: Unknown column 'S.FLC_OID' in 'on clause'
DEBUG - 2014-01-02 17:58:42 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-02 17:59:58 --> Config Class Initialized
DEBUG - 2014-01-02 17:59:58 --> Hooks Class Initialized
DEBUG - 2014-01-02 17:59:58 --> Utf8 Class Initialized
DEBUG - 2014-01-02 17:59:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 17:59:58 --> URI Class Initialized
DEBUG - 2014-01-02 17:59:58 --> Router Class Initialized
DEBUG - 2014-01-02 17:59:58 --> Output Class Initialized
DEBUG - 2014-01-02 17:59:58 --> Security Class Initialized
DEBUG - 2014-01-02 17:59:58 --> Input Class Initialized
DEBUG - 2014-01-02 17:59:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 17:59:58 --> Language Class Initialized
DEBUG - 2014-01-02 17:59:58 --> Loader Class Initialized
DEBUG - 2014-01-02 17:59:58 --> Helper loaded: url_helper
DEBUG - 2014-01-02 17:59:58 --> Helper loaded: common_helper
DEBUG - 2014-01-02 17:59:58 --> Database Driver Class Initialized
DEBUG - 2014-01-02 17:59:58 --> Controller Class Initialized
DEBUG - 2014-01-02 17:59:58 --> Session Class Initialized
DEBUG - 2014-01-02 17:59:58 --> Helper loaded: string_helper
DEBUG - 2014-01-02 17:59:58 --> Encrypt Class Initialized
DEBUG - 2014-01-02 17:59:58 --> Session routines successfully run
DEBUG - 2014-01-02 17:59:58 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 17:59:58 --> Model Class Initialized
DEBUG - 2014-01-02 17:59:58 --> Model Class Initialized
DEBUG - 2014-01-02 17:59:58 --> Model Class Initialized
DEBUG - 2014-01-02 17:59:58 --> DB Transaction Failure
ERROR - 2014-01-02 17:59:58 --> Query error: Unknown column 'F.TORE_OID' in 'on clause'
DEBUG - 2014-01-02 17:59:58 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-02 18:00:10 --> Config Class Initialized
DEBUG - 2014-01-02 18:00:10 --> Hooks Class Initialized
DEBUG - 2014-01-02 18:00:10 --> Utf8 Class Initialized
DEBUG - 2014-01-02 18:00:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 18:00:10 --> URI Class Initialized
DEBUG - 2014-01-02 18:00:10 --> Router Class Initialized
DEBUG - 2014-01-02 18:00:10 --> Output Class Initialized
DEBUG - 2014-01-02 18:00:10 --> Security Class Initialized
DEBUG - 2014-01-02 18:00:10 --> Input Class Initialized
DEBUG - 2014-01-02 18:00:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 18:00:10 --> Language Class Initialized
DEBUG - 2014-01-02 18:00:10 --> Loader Class Initialized
DEBUG - 2014-01-02 18:00:10 --> Helper loaded: url_helper
DEBUG - 2014-01-02 18:00:10 --> Helper loaded: common_helper
DEBUG - 2014-01-02 18:00:10 --> Database Driver Class Initialized
DEBUG - 2014-01-02 18:00:10 --> Controller Class Initialized
DEBUG - 2014-01-02 18:00:10 --> Session Class Initialized
DEBUG - 2014-01-02 18:00:10 --> Helper loaded: string_helper
DEBUG - 2014-01-02 18:00:10 --> Encrypt Class Initialized
DEBUG - 2014-01-02 18:00:10 --> Session routines successfully run
DEBUG - 2014-01-02 18:00:10 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 18:00:10 --> Model Class Initialized
DEBUG - 2014-01-02 18:00:10 --> Model Class Initialized
DEBUG - 2014-01-02 18:00:10 --> Model Class Initialized
DEBUG - 2014-01-02 18:00:10 --> Final output sent to browser
DEBUG - 2014-01-02 18:00:10 --> Total execution time: 0.0384
DEBUG - 2014-01-02 18:12:10 --> Config Class Initialized
DEBUG - 2014-01-02 18:12:10 --> Hooks Class Initialized
DEBUG - 2014-01-02 18:12:10 --> Utf8 Class Initialized
DEBUG - 2014-01-02 18:12:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 18:12:10 --> URI Class Initialized
DEBUG - 2014-01-02 18:12:10 --> Router Class Initialized
DEBUG - 2014-01-02 18:12:10 --> Output Class Initialized
DEBUG - 2014-01-02 18:12:10 --> Security Class Initialized
DEBUG - 2014-01-02 18:12:10 --> Input Class Initialized
DEBUG - 2014-01-02 18:12:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 18:12:10 --> Language Class Initialized
DEBUG - 2014-01-02 18:12:10 --> Loader Class Initialized
DEBUG - 2014-01-02 18:12:10 --> Helper loaded: url_helper
DEBUG - 2014-01-02 18:12:10 --> Helper loaded: common_helper
DEBUG - 2014-01-02 18:12:10 --> Database Driver Class Initialized
DEBUG - 2014-01-02 18:12:10 --> Controller Class Initialized
DEBUG - 2014-01-02 18:12:10 --> Session Class Initialized
DEBUG - 2014-01-02 18:12:10 --> Helper loaded: string_helper
DEBUG - 2014-01-02 18:12:10 --> Encrypt Class Initialized
DEBUG - 2014-01-02 18:12:10 --> Session routines successfully run
DEBUG - 2014-01-02 18:12:10 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 18:12:10 --> Model Class Initialized
DEBUG - 2014-01-02 18:12:10 --> Model Class Initialized
DEBUG - 2014-01-02 18:12:10 --> Model Class Initialized
DEBUG - 2014-01-02 18:12:10 --> Final output sent to browser
DEBUG - 2014-01-02 18:12:10 --> Total execution time: 0.0394
DEBUG - 2014-01-02 18:15:08 --> Config Class Initialized
DEBUG - 2014-01-02 18:15:08 --> Hooks Class Initialized
DEBUG - 2014-01-02 18:15:08 --> Utf8 Class Initialized
DEBUG - 2014-01-02 18:15:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 18:15:08 --> URI Class Initialized
DEBUG - 2014-01-02 18:15:08 --> Router Class Initialized
DEBUG - 2014-01-02 18:15:08 --> Output Class Initialized
DEBUG - 2014-01-02 18:15:08 --> Security Class Initialized
DEBUG - 2014-01-02 18:15:08 --> Input Class Initialized
DEBUG - 2014-01-02 18:15:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 18:15:08 --> Language Class Initialized
DEBUG - 2014-01-02 18:15:08 --> Loader Class Initialized
DEBUG - 2014-01-02 18:15:08 --> Helper loaded: url_helper
DEBUG - 2014-01-02 18:15:08 --> Helper loaded: common_helper
DEBUG - 2014-01-02 18:15:08 --> Database Driver Class Initialized
DEBUG - 2014-01-02 18:15:08 --> Controller Class Initialized
DEBUG - 2014-01-02 18:15:08 --> Session Class Initialized
DEBUG - 2014-01-02 18:15:08 --> Helper loaded: string_helper
DEBUG - 2014-01-02 18:15:08 --> Encrypt Class Initialized
DEBUG - 2014-01-02 18:15:08 --> Session routines successfully run
DEBUG - 2014-01-02 18:15:08 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 18:15:08 --> Model Class Initialized
DEBUG - 2014-01-02 18:15:08 --> Model Class Initialized
DEBUG - 2014-01-02 18:15:08 --> Model Class Initialized
DEBUG - 2014-01-02 18:15:08 --> Final output sent to browser
DEBUG - 2014-01-02 18:15:08 --> Total execution time: 0.0421
DEBUG - 2014-01-02 18:19:43 --> Config Class Initialized
DEBUG - 2014-01-02 18:19:43 --> Hooks Class Initialized
DEBUG - 2014-01-02 18:19:43 --> Utf8 Class Initialized
DEBUG - 2014-01-02 18:19:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 18:19:43 --> URI Class Initialized
DEBUG - 2014-01-02 18:19:43 --> Router Class Initialized
DEBUG - 2014-01-02 18:19:43 --> Output Class Initialized
DEBUG - 2014-01-02 18:19:43 --> Security Class Initialized
DEBUG - 2014-01-02 18:19:43 --> Input Class Initialized
DEBUG - 2014-01-02 18:19:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 18:19:43 --> Language Class Initialized
DEBUG - 2014-01-02 18:19:43 --> Loader Class Initialized
DEBUG - 2014-01-02 18:19:43 --> Helper loaded: url_helper
DEBUG - 2014-01-02 18:19:43 --> Helper loaded: common_helper
DEBUG - 2014-01-02 18:19:43 --> Database Driver Class Initialized
DEBUG - 2014-01-02 18:19:43 --> Controller Class Initialized
DEBUG - 2014-01-02 18:19:43 --> Session Class Initialized
DEBUG - 2014-01-02 18:19:43 --> Helper loaded: string_helper
DEBUG - 2014-01-02 18:19:43 --> Encrypt Class Initialized
DEBUG - 2014-01-02 18:19:43 --> Session routines successfully run
DEBUG - 2014-01-02 18:19:43 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 18:19:43 --> Model Class Initialized
DEBUG - 2014-01-02 18:19:43 --> Model Class Initialized
DEBUG - 2014-01-02 18:19:43 --> Model Class Initialized
DEBUG - 2014-01-02 18:19:43 --> Final output sent to browser
DEBUG - 2014-01-02 18:19:43 --> Total execution time: 0.0389
DEBUG - 2014-01-02 18:19:58 --> Config Class Initialized
DEBUG - 2014-01-02 18:19:58 --> Hooks Class Initialized
DEBUG - 2014-01-02 18:19:58 --> Utf8 Class Initialized
DEBUG - 2014-01-02 18:19:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 18:19:58 --> URI Class Initialized
DEBUG - 2014-01-02 18:19:58 --> Router Class Initialized
DEBUG - 2014-01-02 18:19:58 --> Output Class Initialized
DEBUG - 2014-01-02 18:19:58 --> Security Class Initialized
DEBUG - 2014-01-02 18:19:58 --> Input Class Initialized
DEBUG - 2014-01-02 18:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 18:19:58 --> Language Class Initialized
DEBUG - 2014-01-02 18:19:58 --> Loader Class Initialized
DEBUG - 2014-01-02 18:19:58 --> Helper loaded: url_helper
DEBUG - 2014-01-02 18:19:58 --> Helper loaded: common_helper
DEBUG - 2014-01-02 18:19:58 --> Database Driver Class Initialized
DEBUG - 2014-01-02 18:19:58 --> Controller Class Initialized
DEBUG - 2014-01-02 18:19:59 --> Session Class Initialized
DEBUG - 2014-01-02 18:19:59 --> Helper loaded: string_helper
DEBUG - 2014-01-02 18:19:59 --> Encrypt Class Initialized
DEBUG - 2014-01-02 18:19:59 --> Session routines successfully run
DEBUG - 2014-01-02 18:19:59 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 18:19:59 --> Model Class Initialized
DEBUG - 2014-01-02 18:19:59 --> Model Class Initialized
DEBUG - 2014-01-02 18:19:59 --> Model Class Initialized
DEBUG - 2014-01-02 18:19:59 --> DB Transaction Failure
ERROR - 2014-01-02 18:19:59 --> Query error: Unknown column 'STORE_LOGO' in 'field list'
DEBUG - 2014-01-02 18:19:59 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-02 18:20:21 --> Config Class Initialized
DEBUG - 2014-01-02 18:20:21 --> Hooks Class Initialized
DEBUG - 2014-01-02 18:20:21 --> Utf8 Class Initialized
DEBUG - 2014-01-02 18:20:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 18:20:21 --> URI Class Initialized
DEBUG - 2014-01-02 18:20:21 --> Router Class Initialized
DEBUG - 2014-01-02 18:20:21 --> Output Class Initialized
DEBUG - 2014-01-02 18:20:21 --> Security Class Initialized
DEBUG - 2014-01-02 18:20:21 --> Input Class Initialized
DEBUG - 2014-01-02 18:20:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 18:20:21 --> Language Class Initialized
DEBUG - 2014-01-02 18:20:21 --> Loader Class Initialized
DEBUG - 2014-01-02 18:20:21 --> Helper loaded: url_helper
DEBUG - 2014-01-02 18:20:21 --> Helper loaded: common_helper
DEBUG - 2014-01-02 18:20:21 --> Database Driver Class Initialized
DEBUG - 2014-01-02 18:20:21 --> Controller Class Initialized
DEBUG - 2014-01-02 18:20:21 --> Session Class Initialized
DEBUG - 2014-01-02 18:20:21 --> Helper loaded: string_helper
DEBUG - 2014-01-02 18:20:21 --> Encrypt Class Initialized
DEBUG - 2014-01-02 18:20:21 --> Session routines successfully run
DEBUG - 2014-01-02 18:20:21 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 18:20:21 --> Model Class Initialized
DEBUG - 2014-01-02 18:20:21 --> Model Class Initialized
DEBUG - 2014-01-02 18:20:21 --> Model Class Initialized
DEBUG - 2014-01-02 18:20:21 --> DB Transaction Failure
ERROR - 2014-01-02 18:20:21 --> Query error: Unknown column 'CTCT_TEL' in 'field list'
DEBUG - 2014-01-02 18:20:21 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-02 18:20:55 --> Config Class Initialized
DEBUG - 2014-01-02 18:20:55 --> Hooks Class Initialized
DEBUG - 2014-01-02 18:20:55 --> Utf8 Class Initialized
DEBUG - 2014-01-02 18:20:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 18:20:55 --> URI Class Initialized
DEBUG - 2014-01-02 18:20:55 --> Router Class Initialized
DEBUG - 2014-01-02 18:20:55 --> Output Class Initialized
DEBUG - 2014-01-02 18:20:55 --> Security Class Initialized
DEBUG - 2014-01-02 18:20:55 --> Input Class Initialized
DEBUG - 2014-01-02 18:20:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 18:20:55 --> Language Class Initialized
DEBUG - 2014-01-02 18:20:55 --> Loader Class Initialized
DEBUG - 2014-01-02 18:20:55 --> Helper loaded: url_helper
DEBUG - 2014-01-02 18:20:55 --> Helper loaded: common_helper
DEBUG - 2014-01-02 18:20:55 --> Database Driver Class Initialized
DEBUG - 2014-01-02 18:20:55 --> Controller Class Initialized
DEBUG - 2014-01-02 18:20:55 --> Session Class Initialized
DEBUG - 2014-01-02 18:20:55 --> Helper loaded: string_helper
DEBUG - 2014-01-02 18:20:55 --> Encrypt Class Initialized
DEBUG - 2014-01-02 18:20:55 --> Session routines successfully run
DEBUG - 2014-01-02 18:20:55 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 18:20:55 --> Model Class Initialized
DEBUG - 2014-01-02 18:20:55 --> Model Class Initialized
DEBUG - 2014-01-02 18:20:55 --> Model Class Initialized
DEBUG - 2014-01-02 18:20:55 --> Final output sent to browser
DEBUG - 2014-01-02 18:20:55 --> Total execution time: 0.0416
DEBUG - 2014-01-02 18:32:40 --> Config Class Initialized
DEBUG - 2014-01-02 18:32:40 --> Hooks Class Initialized
DEBUG - 2014-01-02 18:32:40 --> Utf8 Class Initialized
DEBUG - 2014-01-02 18:32:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 18:32:40 --> URI Class Initialized
DEBUG - 2014-01-02 18:32:40 --> Router Class Initialized
DEBUG - 2014-01-02 18:32:40 --> Output Class Initialized
DEBUG - 2014-01-02 18:32:40 --> Security Class Initialized
DEBUG - 2014-01-02 18:32:40 --> Input Class Initialized
DEBUG - 2014-01-02 18:32:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 18:32:40 --> Language Class Initialized
DEBUG - 2014-01-02 18:32:40 --> Loader Class Initialized
DEBUG - 2014-01-02 18:32:40 --> Helper loaded: url_helper
DEBUG - 2014-01-02 18:32:40 --> Helper loaded: common_helper
DEBUG - 2014-01-02 18:32:40 --> Database Driver Class Initialized
DEBUG - 2014-01-02 18:32:40 --> Controller Class Initialized
DEBUG - 2014-01-02 18:32:40 --> Session Class Initialized
DEBUG - 2014-01-02 18:32:40 --> Helper loaded: string_helper
DEBUG - 2014-01-02 18:32:40 --> Encrypt Class Initialized
DEBUG - 2014-01-02 18:32:40 --> Session routines successfully run
DEBUG - 2014-01-02 18:32:40 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 18:32:40 --> Model Class Initialized
DEBUG - 2014-01-02 18:32:40 --> Model Class Initialized
DEBUG - 2014-01-02 18:32:40 --> Model Class Initialized
DEBUG - 2014-01-02 18:32:40 --> Final output sent to browser
DEBUG - 2014-01-02 18:32:40 --> Total execution time: 0.0392
DEBUG - 2014-01-02 18:33:00 --> Config Class Initialized
DEBUG - 2014-01-02 18:33:00 --> Hooks Class Initialized
DEBUG - 2014-01-02 18:33:00 --> Utf8 Class Initialized
DEBUG - 2014-01-02 18:33:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 18:33:00 --> URI Class Initialized
DEBUG - 2014-01-02 18:33:00 --> Router Class Initialized
DEBUG - 2014-01-02 18:33:00 --> Output Class Initialized
DEBUG - 2014-01-02 18:33:00 --> Security Class Initialized
DEBUG - 2014-01-02 18:33:00 --> Input Class Initialized
DEBUG - 2014-01-02 18:33:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 18:33:00 --> Language Class Initialized
DEBUG - 2014-01-02 18:33:00 --> Loader Class Initialized
DEBUG - 2014-01-02 18:33:00 --> Helper loaded: url_helper
DEBUG - 2014-01-02 18:33:00 --> Helper loaded: common_helper
DEBUG - 2014-01-02 18:33:00 --> Database Driver Class Initialized
DEBUG - 2014-01-02 18:33:00 --> Controller Class Initialized
DEBUG - 2014-01-02 18:33:00 --> Session Class Initialized
DEBUG - 2014-01-02 18:33:00 --> Helper loaded: string_helper
DEBUG - 2014-01-02 18:33:00 --> Encrypt Class Initialized
DEBUG - 2014-01-02 18:33:00 --> Session routines successfully run
DEBUG - 2014-01-02 18:33:00 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 18:33:00 --> Model Class Initialized
DEBUG - 2014-01-02 18:33:00 --> Model Class Initialized
DEBUG - 2014-01-02 18:33:00 --> Model Class Initialized
DEBUG - 2014-01-02 18:33:00 --> Final output sent to browser
DEBUG - 2014-01-02 18:33:00 --> Total execution time: 0.0371
DEBUG - 2014-01-02 18:33:25 --> Config Class Initialized
DEBUG - 2014-01-02 18:33:25 --> Hooks Class Initialized
DEBUG - 2014-01-02 18:33:25 --> Utf8 Class Initialized
DEBUG - 2014-01-02 18:33:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 18:33:25 --> URI Class Initialized
DEBUG - 2014-01-02 18:33:25 --> Router Class Initialized
DEBUG - 2014-01-02 18:33:25 --> Output Class Initialized
DEBUG - 2014-01-02 18:33:25 --> Security Class Initialized
DEBUG - 2014-01-02 18:33:25 --> Input Class Initialized
DEBUG - 2014-01-02 18:33:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 18:33:25 --> Language Class Initialized
DEBUG - 2014-01-02 18:33:25 --> Loader Class Initialized
DEBUG - 2014-01-02 18:33:25 --> Helper loaded: url_helper
DEBUG - 2014-01-02 18:33:25 --> Helper loaded: common_helper
DEBUG - 2014-01-02 18:33:25 --> Database Driver Class Initialized
DEBUG - 2014-01-02 18:33:25 --> Controller Class Initialized
DEBUG - 2014-01-02 18:33:25 --> Session Class Initialized
DEBUG - 2014-01-02 18:33:25 --> Helper loaded: string_helper
DEBUG - 2014-01-02 18:33:25 --> Encrypt Class Initialized
DEBUG - 2014-01-02 18:33:25 --> Session routines successfully run
DEBUG - 2014-01-02 18:33:25 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 18:33:25 --> Model Class Initialized
DEBUG - 2014-01-02 18:33:25 --> Model Class Initialized
DEBUG - 2014-01-02 18:33:25 --> Model Class Initialized
DEBUG - 2014-01-02 18:33:25 --> Final output sent to browser
DEBUG - 2014-01-02 18:33:25 --> Total execution time: 0.0449
DEBUG - 2014-01-02 18:35:42 --> Config Class Initialized
DEBUG - 2014-01-02 18:35:42 --> Hooks Class Initialized
DEBUG - 2014-01-02 18:35:42 --> Utf8 Class Initialized
DEBUG - 2014-01-02 18:35:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 18:35:42 --> URI Class Initialized
DEBUG - 2014-01-02 18:35:42 --> Router Class Initialized
DEBUG - 2014-01-02 18:35:42 --> Output Class Initialized
DEBUG - 2014-01-02 18:35:42 --> Security Class Initialized
DEBUG - 2014-01-02 18:35:42 --> Input Class Initialized
DEBUG - 2014-01-02 18:35:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 18:35:42 --> Language Class Initialized
DEBUG - 2014-01-02 18:35:42 --> Loader Class Initialized
DEBUG - 2014-01-02 18:35:42 --> Helper loaded: url_helper
DEBUG - 2014-01-02 18:35:42 --> Helper loaded: common_helper
DEBUG - 2014-01-02 18:35:42 --> Database Driver Class Initialized
DEBUG - 2014-01-02 18:35:42 --> Controller Class Initialized
DEBUG - 2014-01-02 18:35:42 --> Session Class Initialized
DEBUG - 2014-01-02 18:35:42 --> Helper loaded: string_helper
DEBUG - 2014-01-02 18:35:42 --> Encrypt Class Initialized
DEBUG - 2014-01-02 18:35:42 --> Session routines successfully run
DEBUG - 2014-01-02 18:35:42 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 18:35:42 --> Model Class Initialized
DEBUG - 2014-01-02 18:35:42 --> Model Class Initialized
DEBUG - 2014-01-02 18:35:42 --> Model Class Initialized
DEBUG - 2014-01-02 18:35:42 --> DB Transaction Failure
ERROR - 2014-01-02 18:35:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ON SLD.DISH_OID=D.DISH_OID
            INNER JOIN STORE_DISHES SD ON SD.DISH_OID' at line 4
DEBUG - 2014-01-02 18:35:43 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-02 18:37:18 --> Config Class Initialized
DEBUG - 2014-01-02 18:37:18 --> Hooks Class Initialized
DEBUG - 2014-01-02 18:37:18 --> Utf8 Class Initialized
DEBUG - 2014-01-02 18:37:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 18:37:18 --> URI Class Initialized
DEBUG - 2014-01-02 18:37:18 --> Router Class Initialized
DEBUG - 2014-01-02 18:37:18 --> Output Class Initialized
DEBUG - 2014-01-02 18:37:18 --> Security Class Initialized
DEBUG - 2014-01-02 18:37:18 --> Input Class Initialized
DEBUG - 2014-01-02 18:37:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 18:37:18 --> Language Class Initialized
DEBUG - 2014-01-02 18:37:18 --> Loader Class Initialized
DEBUG - 2014-01-02 18:37:18 --> Helper loaded: url_helper
DEBUG - 2014-01-02 18:37:18 --> Helper loaded: common_helper
DEBUG - 2014-01-02 18:37:18 --> Database Driver Class Initialized
DEBUG - 2014-01-02 18:37:18 --> Controller Class Initialized
DEBUG - 2014-01-02 18:37:18 --> Session Class Initialized
DEBUG - 2014-01-02 18:37:18 --> Helper loaded: string_helper
DEBUG - 2014-01-02 18:37:18 --> Encrypt Class Initialized
DEBUG - 2014-01-02 18:37:18 --> Session routines successfully run
DEBUG - 2014-01-02 18:37:18 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 18:37:18 --> Model Class Initialized
DEBUG - 2014-01-02 18:37:18 --> Model Class Initialized
DEBUG - 2014-01-02 18:37:18 --> Model Class Initialized
DEBUG - 2014-01-02 18:37:18 --> Final output sent to browser
DEBUG - 2014-01-02 18:37:18 --> Total execution time: 0.0377
DEBUG - 2014-01-02 18:44:15 --> Config Class Initialized
DEBUG - 2014-01-02 18:44:15 --> Hooks Class Initialized
DEBUG - 2014-01-02 18:44:15 --> Utf8 Class Initialized
DEBUG - 2014-01-02 18:44:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 18:44:15 --> URI Class Initialized
DEBUG - 2014-01-02 18:44:15 --> Router Class Initialized
DEBUG - 2014-01-02 18:44:15 --> Output Class Initialized
DEBUG - 2014-01-02 18:44:15 --> Security Class Initialized
DEBUG - 2014-01-02 18:44:15 --> Input Class Initialized
DEBUG - 2014-01-02 18:44:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 18:44:15 --> Language Class Initialized
DEBUG - 2014-01-02 18:44:15 --> Loader Class Initialized
DEBUG - 2014-01-02 18:44:15 --> Helper loaded: url_helper
DEBUG - 2014-01-02 18:44:15 --> Helper loaded: common_helper
DEBUG - 2014-01-02 18:44:15 --> Database Driver Class Initialized
DEBUG - 2014-01-02 18:44:15 --> Controller Class Initialized
DEBUG - 2014-01-02 18:44:15 --> Session Class Initialized
DEBUG - 2014-01-02 18:44:15 --> Helper loaded: string_helper
DEBUG - 2014-01-02 18:44:15 --> Encrypt Class Initialized
DEBUG - 2014-01-02 18:44:15 --> Session routines successfully run
DEBUG - 2014-01-02 18:44:15 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 18:44:15 --> Model Class Initialized
DEBUG - 2014-01-02 18:44:15 --> Model Class Initialized
DEBUG - 2014-01-02 18:44:15 --> Model Class Initialized
DEBUG - 2014-01-02 18:44:15 --> DB Transaction Failure
ERROR - 2014-01-02 18:44:15 --> Query error: Unknown column 'SD.STORE_ID' in 'where clause'
DEBUG - 2014-01-02 18:44:15 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-02 18:44:41 --> Config Class Initialized
DEBUG - 2014-01-02 18:44:41 --> Hooks Class Initialized
DEBUG - 2014-01-02 18:44:41 --> Utf8 Class Initialized
DEBUG - 2014-01-02 18:44:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 18:44:41 --> URI Class Initialized
DEBUG - 2014-01-02 18:44:41 --> Router Class Initialized
DEBUG - 2014-01-02 18:44:41 --> Output Class Initialized
DEBUG - 2014-01-02 18:44:41 --> Security Class Initialized
DEBUG - 2014-01-02 18:44:41 --> Input Class Initialized
DEBUG - 2014-01-02 18:44:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 18:44:41 --> Language Class Initialized
DEBUG - 2014-01-02 18:44:41 --> Loader Class Initialized
DEBUG - 2014-01-02 18:44:41 --> Helper loaded: url_helper
DEBUG - 2014-01-02 18:44:41 --> Helper loaded: common_helper
DEBUG - 2014-01-02 18:44:41 --> Database Driver Class Initialized
DEBUG - 2014-01-02 18:44:41 --> Controller Class Initialized
DEBUG - 2014-01-02 18:44:41 --> Session Class Initialized
DEBUG - 2014-01-02 18:44:41 --> Helper loaded: string_helper
DEBUG - 2014-01-02 18:44:41 --> Encrypt Class Initialized
DEBUG - 2014-01-02 18:44:41 --> Session routines successfully run
DEBUG - 2014-01-02 18:44:41 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 18:44:41 --> Model Class Initialized
DEBUG - 2014-01-02 18:44:41 --> Model Class Initialized
DEBUG - 2014-01-02 18:44:41 --> Model Class Initialized
DEBUG - 2014-01-02 18:44:41 --> Final output sent to browser
DEBUG - 2014-01-02 18:44:41 --> Total execution time: 0.0337
DEBUG - 2014-01-02 18:44:56 --> Config Class Initialized
DEBUG - 2014-01-02 18:44:56 --> Hooks Class Initialized
DEBUG - 2014-01-02 18:44:56 --> Utf8 Class Initialized
DEBUG - 2014-01-02 18:44:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-02 18:44:56 --> URI Class Initialized
DEBUG - 2014-01-02 18:44:56 --> Router Class Initialized
DEBUG - 2014-01-02 18:44:56 --> Output Class Initialized
DEBUG - 2014-01-02 18:44:56 --> Security Class Initialized
DEBUG - 2014-01-02 18:44:56 --> Input Class Initialized
DEBUG - 2014-01-02 18:44:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-02 18:44:56 --> Language Class Initialized
DEBUG - 2014-01-02 18:44:56 --> Loader Class Initialized
DEBUG - 2014-01-02 18:44:56 --> Helper loaded: url_helper
DEBUG - 2014-01-02 18:44:56 --> Helper loaded: common_helper
DEBUG - 2014-01-02 18:44:56 --> Database Driver Class Initialized
DEBUG - 2014-01-02 18:44:56 --> Controller Class Initialized
DEBUG - 2014-01-02 18:44:56 --> Session Class Initialized
DEBUG - 2014-01-02 18:44:56 --> Helper loaded: string_helper
DEBUG - 2014-01-02 18:44:56 --> Encrypt Class Initialized
DEBUG - 2014-01-02 18:44:56 --> Session routines successfully run
DEBUG - 2014-01-02 18:44:56 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-02 18:44:56 --> Model Class Initialized
DEBUG - 2014-01-02 18:44:56 --> Model Class Initialized
DEBUG - 2014-01-02 18:44:56 --> Model Class Initialized
DEBUG - 2014-01-02 18:44:56 --> Final output sent to browser
DEBUG - 2014-01-02 18:44:56 --> Total execution time: 0.0447
