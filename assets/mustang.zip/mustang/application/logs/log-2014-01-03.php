<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-01-03 04:34:56 --> Config Class Initialized
DEBUG - 2014-01-03 04:34:56 --> Hooks Class Initialized
DEBUG - 2014-01-03 04:34:56 --> Utf8 Class Initialized
DEBUG - 2014-01-03 04:34:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-03 04:34:56 --> URI Class Initialized
DEBUG - 2014-01-03 04:34:56 --> Router Class Initialized
DEBUG - 2014-01-03 04:34:56 --> No URI present. Default controller set.
DEBUG - 2014-01-03 04:34:56 --> Output Class Initialized
DEBUG - 2014-01-03 04:34:56 --> Security Class Initialized
DEBUG - 2014-01-03 04:34:56 --> Input Class Initialized
DEBUG - 2014-01-03 04:34:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-03 04:34:56 --> Language Class Initialized
DEBUG - 2014-01-03 04:34:56 --> Loader Class Initialized
DEBUG - 2014-01-03 04:34:56 --> Helper loaded: url_helper
DEBUG - 2014-01-03 04:34:56 --> Helper loaded: common_helper
DEBUG - 2014-01-03 04:34:56 --> Database Driver Class Initialized
DEBUG - 2014-01-03 04:34:56 --> Controller Class Initialized
DEBUG - 2014-01-03 04:34:56 --> Session Class Initialized
DEBUG - 2014-01-03 04:34:56 --> Helper loaded: string_helper
DEBUG - 2014-01-03 04:34:56 --> Encrypt Class Initialized
DEBUG - 2014-01-03 04:34:56 --> Session routines successfully run
DEBUG - 2014-01-03 04:34:56 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-03 04:34:56 --> Helper loaded: form_helper
DEBUG - 2014-01-03 04:34:56 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-03 04:34:56 --> Twig Autoloader Loaded
DEBUG - 2014-01-03 04:35:06 --> Config Class Initialized
DEBUG - 2014-01-03 04:35:06 --> Hooks Class Initialized
DEBUG - 2014-01-03 04:35:06 --> Utf8 Class Initialized
DEBUG - 2014-01-03 04:35:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-03 04:35:06 --> URI Class Initialized
DEBUG - 2014-01-03 04:35:06 --> Router Class Initialized
DEBUG - 2014-01-03 04:35:06 --> Output Class Initialized
DEBUG - 2014-01-03 04:35:06 --> Security Class Initialized
DEBUG - 2014-01-03 04:35:06 --> Input Class Initialized
DEBUG - 2014-01-03 04:35:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-03 04:35:06 --> Language Class Initialized
DEBUG - 2014-01-03 04:35:06 --> Loader Class Initialized
DEBUG - 2014-01-03 04:35:06 --> Helper loaded: url_helper
DEBUG - 2014-01-03 04:35:06 --> Helper loaded: common_helper
DEBUG - 2014-01-03 04:35:06 --> Database Driver Class Initialized
DEBUG - 2014-01-03 04:35:06 --> Controller Class Initialized
DEBUG - 2014-01-03 04:35:06 --> Session Class Initialized
DEBUG - 2014-01-03 04:35:06 --> Helper loaded: string_helper
DEBUG - 2014-01-03 04:35:06 --> Encrypt Class Initialized
DEBUG - 2014-01-03 04:35:06 --> Session routines successfully run
DEBUG - 2014-01-03 04:35:06 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-03 04:35:06 --> Helper loaded: form_helper
DEBUG - 2014-01-03 04:35:06 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-03 04:35:06 --> Twig Autoloader Loaded
DEBUG - 2014-01-03 04:35:06 --> lsession class already loaded. Second attempt ignored.
DEBUG - 2014-01-03 04:35:06 --> Final output sent to browser
DEBUG - 2014-01-03 04:35:06 --> Total execution time: 0.0768
DEBUG - 2014-01-03 04:35:59 --> Config Class Initialized
DEBUG - 2014-01-03 04:35:59 --> Hooks Class Initialized
DEBUG - 2014-01-03 04:35:59 --> Utf8 Class Initialized
DEBUG - 2014-01-03 04:35:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-03 04:35:59 --> URI Class Initialized
DEBUG - 2014-01-03 04:35:59 --> Router Class Initialized
DEBUG - 2014-01-03 04:35:59 --> Output Class Initialized
DEBUG - 2014-01-03 04:35:59 --> Security Class Initialized
DEBUG - 2014-01-03 04:35:59 --> Input Class Initialized
DEBUG - 2014-01-03 04:35:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-03 04:35:59 --> Language Class Initialized
DEBUG - 2014-01-03 04:35:59 --> Loader Class Initialized
DEBUG - 2014-01-03 04:35:59 --> Helper loaded: url_helper
DEBUG - 2014-01-03 04:35:59 --> Helper loaded: common_helper
DEBUG - 2014-01-03 04:35:59 --> Database Driver Class Initialized
DEBUG - 2014-01-03 04:35:59 --> Controller Class Initialized
DEBUG - 2014-01-03 04:35:59 --> Session Class Initialized
DEBUG - 2014-01-03 04:35:59 --> Helper loaded: string_helper
DEBUG - 2014-01-03 04:35:59 --> Encrypt Class Initialized
DEBUG - 2014-01-03 04:35:59 --> Session routines successfully run
DEBUG - 2014-01-03 04:35:59 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-03 04:35:59 --> Helper loaded: form_helper
DEBUG - 2014-01-03 04:35:59 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-03 04:35:59 --> Twig Autoloader Loaded
DEBUG - 2014-01-03 04:35:59 --> lsession class already loaded. Second attempt ignored.
DEBUG - 2014-01-03 04:35:59 --> Final output sent to browser
DEBUG - 2014-01-03 04:35:59 --> Total execution time: 0.0733
DEBUG - 2014-01-03 04:36:25 --> Config Class Initialized
DEBUG - 2014-01-03 04:36:25 --> Hooks Class Initialized
DEBUG - 2014-01-03 04:36:25 --> Utf8 Class Initialized
DEBUG - 2014-01-03 04:36:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-03 04:36:25 --> URI Class Initialized
DEBUG - 2014-01-03 04:36:25 --> Router Class Initialized
DEBUG - 2014-01-03 04:36:25 --> Output Class Initialized
DEBUG - 2014-01-03 04:36:25 --> Security Class Initialized
DEBUG - 2014-01-03 04:36:25 --> Input Class Initialized
DEBUG - 2014-01-03 04:36:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-03 04:36:25 --> Language Class Initialized
DEBUG - 2014-01-03 04:36:25 --> Loader Class Initialized
DEBUG - 2014-01-03 04:36:25 --> Helper loaded: url_helper
DEBUG - 2014-01-03 04:36:25 --> Helper loaded: common_helper
DEBUG - 2014-01-03 04:36:25 --> Database Driver Class Initialized
DEBUG - 2014-01-03 04:36:25 --> Controller Class Initialized
DEBUG - 2014-01-03 04:36:25 --> Session Class Initialized
DEBUG - 2014-01-03 04:36:25 --> Helper loaded: string_helper
DEBUG - 2014-01-03 04:36:25 --> Encrypt Class Initialized
DEBUG - 2014-01-03 04:36:25 --> Session routines successfully run
DEBUG - 2014-01-03 04:36:25 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-03 04:36:25 --> Model Class Initialized
DEBUG - 2014-01-03 04:36:25 --> Model Class Initialized
DEBUG - 2014-01-03 04:36:25 --> Final output sent to browser
DEBUG - 2014-01-03 04:36:25 --> Total execution time: 0.0459
DEBUG - 2014-01-03 04:36:25 --> Config Class Initialized
DEBUG - 2014-01-03 04:36:25 --> Hooks Class Initialized
DEBUG - 2014-01-03 04:36:25 --> Utf8 Class Initialized
DEBUG - 2014-01-03 04:36:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-03 04:36:25 --> URI Class Initialized
DEBUG - 2014-01-03 04:36:25 --> Router Class Initialized
DEBUG - 2014-01-03 04:36:25 --> Output Class Initialized
DEBUG - 2014-01-03 04:36:25 --> Security Class Initialized
DEBUG - 2014-01-03 04:36:25 --> Input Class Initialized
DEBUG - 2014-01-03 04:36:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-03 04:36:25 --> Language Class Initialized
DEBUG - 2014-01-03 04:36:25 --> Loader Class Initialized
DEBUG - 2014-01-03 04:36:25 --> Helper loaded: url_helper
DEBUG - 2014-01-03 04:36:25 --> Helper loaded: common_helper
DEBUG - 2014-01-03 04:36:25 --> Database Driver Class Initialized
DEBUG - 2014-01-03 04:36:25 --> Controller Class Initialized
DEBUG - 2014-01-03 04:36:25 --> Session Class Initialized
DEBUG - 2014-01-03 04:36:25 --> Helper loaded: string_helper
DEBUG - 2014-01-03 04:36:25 --> Encrypt Class Initialized
DEBUG - 2014-01-03 04:36:25 --> Session routines successfully run
DEBUG - 2014-01-03 04:36:25 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-03 04:36:25 --> Final output sent to browser
DEBUG - 2014-01-03 04:36:25 --> Total execution time: 0.0476
DEBUG - 2014-01-03 04:36:40 --> Config Class Initialized
DEBUG - 2014-01-03 04:36:40 --> Hooks Class Initialized
DEBUG - 2014-01-03 04:36:40 --> Utf8 Class Initialized
DEBUG - 2014-01-03 04:36:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-03 04:36:40 --> URI Class Initialized
DEBUG - 2014-01-03 04:36:40 --> Router Class Initialized
DEBUG - 2014-01-03 04:36:40 --> Output Class Initialized
DEBUG - 2014-01-03 04:36:40 --> Security Class Initialized
DEBUG - 2014-01-03 04:36:40 --> Input Class Initialized
DEBUG - 2014-01-03 04:36:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-03 04:36:40 --> Language Class Initialized
DEBUG - 2014-01-03 04:36:40 --> Loader Class Initialized
DEBUG - 2014-01-03 04:36:40 --> Helper loaded: url_helper
DEBUG - 2014-01-03 04:36:40 --> Helper loaded: common_helper
DEBUG - 2014-01-03 04:36:40 --> Database Driver Class Initialized
DEBUG - 2014-01-03 04:36:40 --> Controller Class Initialized
DEBUG - 2014-01-03 04:36:40 --> Session Class Initialized
DEBUG - 2014-01-03 04:36:40 --> Helper loaded: string_helper
DEBUG - 2014-01-03 04:36:40 --> Encrypt Class Initialized
DEBUG - 2014-01-03 04:36:40 --> Session routines successfully run
DEBUG - 2014-01-03 04:36:40 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-03 04:36:40 --> Model Class Initialized
DEBUG - 2014-01-03 04:36:40 --> Model Class Initialized
DEBUG - 2014-01-03 04:36:40 --> Final output sent to browser
DEBUG - 2014-01-03 04:36:40 --> Total execution time: 0.0456
DEBUG - 2014-01-03 04:36:40 --> Config Class Initialized
DEBUG - 2014-01-03 04:36:40 --> Hooks Class Initialized
DEBUG - 2014-01-03 04:36:40 --> Utf8 Class Initialized
DEBUG - 2014-01-03 04:36:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-03 04:36:40 --> URI Class Initialized
DEBUG - 2014-01-03 04:36:40 --> Router Class Initialized
DEBUG - 2014-01-03 04:36:40 --> Output Class Initialized
DEBUG - 2014-01-03 04:36:40 --> Security Class Initialized
DEBUG - 2014-01-03 04:36:40 --> Input Class Initialized
DEBUG - 2014-01-03 04:36:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-03 04:36:40 --> Language Class Initialized
DEBUG - 2014-01-03 04:36:40 --> Loader Class Initialized
DEBUG - 2014-01-03 04:36:40 --> Helper loaded: url_helper
DEBUG - 2014-01-03 04:36:40 --> Helper loaded: common_helper
DEBUG - 2014-01-03 04:36:40 --> Database Driver Class Initialized
DEBUG - 2014-01-03 04:36:40 --> Controller Class Initialized
DEBUG - 2014-01-03 04:36:40 --> Session Class Initialized
DEBUG - 2014-01-03 04:36:40 --> Helper loaded: string_helper
DEBUG - 2014-01-03 04:36:40 --> Encrypt Class Initialized
DEBUG - 2014-01-03 04:36:40 --> Session routines successfully run
DEBUG - 2014-01-03 04:36:40 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-03 04:36:40 --> Final output sent to browser
DEBUG - 2014-01-03 04:36:40 --> Total execution time: 0.0450
DEBUG - 2014-01-03 04:36:51 --> Config Class Initialized
DEBUG - 2014-01-03 04:36:51 --> Hooks Class Initialized
DEBUG - 2014-01-03 04:36:51 --> Utf8 Class Initialized
DEBUG - 2014-01-03 04:36:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-03 04:36:51 --> URI Class Initialized
DEBUG - 2014-01-03 04:36:51 --> Router Class Initialized
DEBUG - 2014-01-03 04:36:51 --> Output Class Initialized
DEBUG - 2014-01-03 04:36:51 --> Security Class Initialized
DEBUG - 2014-01-03 04:36:51 --> Input Class Initialized
DEBUG - 2014-01-03 04:36:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-03 04:36:51 --> Language Class Initialized
DEBUG - 2014-01-03 04:36:51 --> Loader Class Initialized
DEBUG - 2014-01-03 04:36:51 --> Helper loaded: url_helper
DEBUG - 2014-01-03 04:36:51 --> Helper loaded: common_helper
DEBUG - 2014-01-03 04:36:51 --> Database Driver Class Initialized
DEBUG - 2014-01-03 04:36:51 --> Controller Class Initialized
DEBUG - 2014-01-03 04:36:51 --> Session Class Initialized
DEBUG - 2014-01-03 04:36:51 --> Helper loaded: string_helper
DEBUG - 2014-01-03 04:36:51 --> Encrypt Class Initialized
DEBUG - 2014-01-03 04:36:51 --> Session routines successfully run
DEBUG - 2014-01-03 04:36:51 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-03 04:36:51 --> Model Class Initialized
DEBUG - 2014-01-03 04:36:51 --> Model Class Initialized
DEBUG - 2014-01-03 04:36:51 --> Final output sent to browser
DEBUG - 2014-01-03 04:36:51 --> Total execution time: 0.0452
DEBUG - 2014-01-03 04:36:51 --> Config Class Initialized
DEBUG - 2014-01-03 04:36:51 --> Hooks Class Initialized
DEBUG - 2014-01-03 04:36:51 --> Utf8 Class Initialized
DEBUG - 2014-01-03 04:36:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-03 04:36:51 --> URI Class Initialized
DEBUG - 2014-01-03 04:36:51 --> Router Class Initialized
DEBUG - 2014-01-03 04:36:51 --> No URI present. Default controller set.
DEBUG - 2014-01-03 04:36:51 --> Output Class Initialized
DEBUG - 2014-01-03 04:36:51 --> Security Class Initialized
DEBUG - 2014-01-03 04:36:51 --> Input Class Initialized
DEBUG - 2014-01-03 04:36:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-03 04:36:51 --> Language Class Initialized
DEBUG - 2014-01-03 04:36:51 --> Loader Class Initialized
DEBUG - 2014-01-03 04:36:51 --> Helper loaded: url_helper
DEBUG - 2014-01-03 04:36:51 --> Helper loaded: common_helper
DEBUG - 2014-01-03 04:36:51 --> Database Driver Class Initialized
DEBUG - 2014-01-03 04:36:51 --> Controller Class Initialized
DEBUG - 2014-01-03 04:36:51 --> Session Class Initialized
DEBUG - 2014-01-03 04:36:51 --> Helper loaded: string_helper
DEBUG - 2014-01-03 04:36:51 --> Encrypt Class Initialized
DEBUG - 2014-01-03 04:36:51 --> Session routines successfully run
DEBUG - 2014-01-03 04:36:51 --> Config file loaded: application/config/acl.php
ERROR - 2014-01-03 04:36:51 --> Severity: Notice  --> Undefined property: stdClass::$role /var/www/mustang/application/hooks/acl.php 37
ERROR - 2014-01-03 04:36:51 --> 404 Page Not Found --> 错误的用户类型，该错误已经被记录！点击<a href="http://localhost:2066/index.php/login">返回</a>
DEBUG - 2014-01-03 04:39:08 --> Config Class Initialized
DEBUG - 2014-01-03 04:39:08 --> Hooks Class Initialized
DEBUG - 2014-01-03 04:39:08 --> Utf8 Class Initialized
DEBUG - 2014-01-03 04:39:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-03 04:39:08 --> URI Class Initialized
DEBUG - 2014-01-03 04:39:08 --> Router Class Initialized
DEBUG - 2014-01-03 04:39:08 --> No URI present. Default controller set.
DEBUG - 2014-01-03 04:39:08 --> Output Class Initialized
DEBUG - 2014-01-03 04:39:08 --> Security Class Initialized
DEBUG - 2014-01-03 04:39:08 --> Input Class Initialized
DEBUG - 2014-01-03 04:39:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-03 04:39:08 --> Language Class Initialized
DEBUG - 2014-01-03 04:39:08 --> Loader Class Initialized
DEBUG - 2014-01-03 04:39:08 --> Helper loaded: url_helper
DEBUG - 2014-01-03 04:39:08 --> Helper loaded: common_helper
DEBUG - 2014-01-03 04:39:08 --> Database Driver Class Initialized
DEBUG - 2014-01-03 04:39:08 --> Controller Class Initialized
DEBUG - 2014-01-03 04:39:08 --> Session Class Initialized
DEBUG - 2014-01-03 04:39:08 --> Helper loaded: string_helper
DEBUG - 2014-01-03 04:39:08 --> Encrypt Class Initialized
DEBUG - 2014-01-03 04:39:08 --> Session routines successfully run
DEBUG - 2014-01-03 04:39:08 --> Config file loaded: application/config/acl.php
ERROR - 2014-01-03 04:39:08 --> Severity: Notice  --> Undefined property: stdClass::$role /var/www/mustang/application/hooks/acl.php 37
ERROR - 2014-01-03 04:39:08 --> 404 Page Not Found --> 错误的用户类型，该错误已经被记录！点击<a href="http://localhost:2066/index.php/login">返回</a>
DEBUG - 2014-01-03 04:39:29 --> Config Class Initialized
DEBUG - 2014-01-03 04:39:29 --> Hooks Class Initialized
DEBUG - 2014-01-03 04:39:29 --> Utf8 Class Initialized
DEBUG - 2014-01-03 04:39:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-03 04:39:29 --> URI Class Initialized
DEBUG - 2014-01-03 04:39:29 --> Router Class Initialized
DEBUG - 2014-01-03 04:39:29 --> No URI present. Default controller set.
DEBUG - 2014-01-03 04:39:29 --> Output Class Initialized
DEBUG - 2014-01-03 04:39:29 --> Security Class Initialized
DEBUG - 2014-01-03 04:39:29 --> Input Class Initialized
DEBUG - 2014-01-03 04:39:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-03 04:39:29 --> Language Class Initialized
DEBUG - 2014-01-03 04:39:29 --> Loader Class Initialized
DEBUG - 2014-01-03 04:39:29 --> Helper loaded: url_helper
DEBUG - 2014-01-03 04:39:29 --> Helper loaded: common_helper
DEBUG - 2014-01-03 04:39:29 --> Database Driver Class Initialized
DEBUG - 2014-01-03 04:39:29 --> Controller Class Initialized
DEBUG - 2014-01-03 04:39:29 --> Session Class Initialized
DEBUG - 2014-01-03 04:39:29 --> Helper loaded: string_helper
DEBUG - 2014-01-03 04:39:29 --> Encrypt Class Initialized
DEBUG - 2014-01-03 04:39:29 --> Session routines successfully run
DEBUG - 2014-01-03 04:39:29 --> Config file loaded: application/config/acl.php
ERROR - 2014-01-03 04:39:29 --> Severity: Notice  --> Undefined property: stdClass::$role /var/www/mustang/application/hooks/acl.php 37
ERROR - 2014-01-03 04:39:29 --> 404 Page Not Found --> 错误的用户类型，该错误已经被记录！点击<a href="http://localhost:2066/index.php/login">返回</a>
DEBUG - 2014-01-03 04:39:44 --> Config Class Initialized
DEBUG - 2014-01-03 04:39:44 --> Hooks Class Initialized
DEBUG - 2014-01-03 04:39:44 --> Utf8 Class Initialized
DEBUG - 2014-01-03 04:39:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-03 04:39:44 --> URI Class Initialized
DEBUG - 2014-01-03 04:39:44 --> Router Class Initialized
DEBUG - 2014-01-03 04:39:44 --> No URI present. Default controller set.
DEBUG - 2014-01-03 04:39:44 --> Output Class Initialized
DEBUG - 2014-01-03 04:39:44 --> Security Class Initialized
DEBUG - 2014-01-03 04:39:44 --> Input Class Initialized
DEBUG - 2014-01-03 04:39:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-03 04:39:44 --> Language Class Initialized
DEBUG - 2014-01-03 04:39:44 --> Loader Class Initialized
DEBUG - 2014-01-03 04:39:44 --> Helper loaded: url_helper
DEBUG - 2014-01-03 04:39:44 --> Helper loaded: common_helper
DEBUG - 2014-01-03 04:39:44 --> Database Driver Class Initialized
DEBUG - 2014-01-03 04:39:44 --> Controller Class Initialized
DEBUG - 2014-01-03 04:39:44 --> Session Class Initialized
DEBUG - 2014-01-03 04:39:44 --> Helper loaded: string_helper
DEBUG - 2014-01-03 04:39:44 --> Encrypt Class Initialized
DEBUG - 2014-01-03 04:39:44 --> Session routines successfully run
DEBUG - 2014-01-03 04:39:44 --> Config file loaded: application/config/acl.php
ERROR - 2014-01-03 04:39:44 --> Severity: Notice  --> Undefined property: stdClass::$role /var/www/mustang/application/hooks/acl.php 37
ERROR - 2014-01-03 04:39:44 --> 404 Page Not Found --> 错误的用户类型，该错误已经被记录！点击<a href="http://localhost:2066/index.php/login">返回</a>
DEBUG - 2014-01-03 05:37:28 --> Config Class Initialized
DEBUG - 2014-01-03 05:37:28 --> Hooks Class Initialized
DEBUG - 2014-01-03 05:37:28 --> Utf8 Class Initialized
DEBUG - 2014-01-03 05:37:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-03 05:37:28 --> URI Class Initialized
DEBUG - 2014-01-03 05:37:28 --> Router Class Initialized
DEBUG - 2014-01-03 05:37:28 --> No URI present. Default controller set.
DEBUG - 2014-01-03 05:37:28 --> Output Class Initialized
DEBUG - 2014-01-03 05:37:28 --> Security Class Initialized
DEBUG - 2014-01-03 05:37:28 --> Input Class Initialized
DEBUG - 2014-01-03 05:37:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-03 05:37:28 --> Language Class Initialized
DEBUG - 2014-01-03 05:37:28 --> Loader Class Initialized
DEBUG - 2014-01-03 05:37:28 --> Helper loaded: url_helper
DEBUG - 2014-01-03 05:37:28 --> Helper loaded: common_helper
DEBUG - 2014-01-03 05:37:28 --> Database Driver Class Initialized
DEBUG - 2014-01-03 05:37:28 --> Controller Class Initialized
DEBUG - 2014-01-03 05:37:28 --> Session Class Initialized
DEBUG - 2014-01-03 05:37:28 --> Helper loaded: string_helper
DEBUG - 2014-01-03 05:37:28 --> Encrypt Class Initialized
DEBUG - 2014-01-03 05:37:28 --> Session routines successfully run
DEBUG - 2014-01-03 05:37:28 --> Config file loaded: application/config/acl.php
DEBUG - 2014-01-03 05:37:28 --> Helper loaded: form_helper
DEBUG - 2014-01-03 05:37:28 --> Config file loaded: application/config/twig.php
DEBUG - 2014-01-03 05:37:28 --> Twig Autoloader Loaded
